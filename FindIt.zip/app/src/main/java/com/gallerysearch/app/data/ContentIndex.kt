package com.gallerysearch.app.data

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONObject

/**
 * Document content index: extracted text for plain-text files and PDFs, plus
 * OCR for document-like images. Query tokens match file content, not just names.
 * Persisted as JSON; per-file cap keeps memory sane on huge libraries.
 */
object ContentIndex {
    private const val FILE = "content_index.json"
    private const val TEXT_CAP_BYTES = 200 * 1024
    private const val PDF_MAX_PAGES = 20
    private const val SNIPPET_LEN = 120

    private val TEXT_EXTS = setOf("txt", "md", "csv", "json", "log", "xml", "html", "srt")

    @Volatile
    var content: Map<String, String> = emptyMap() // uri -> lowercase searchable text
        private set

    fun load(ctx: Context) = runCatching {
        val f = ctx.getFileStreamPath(FILE) ?: return@runCatching
        if (!f.exists()) return@runCatching
        ctx.openFileInput(FILE).bufferedReader().use { reader ->
            val o = JSONObject(reader.readText())
            content = o.keys().asSequence().associateWith { o.getString(it) }
        }
    }

    @Synchronized
    fun save(ctx: Context) = runCatching {
        val o = JSONObject()
        content.forEach { (k, v) -> o.put(k, v) }
        ctx.openFileOutput(FILE, Context.MODE_PRIVATE).writer().use { it.write(o.toString()) }
    }

    /** Uris whose extracted content contains every query token. */
    fun search(queryTokens: List<String>): Set<String> {
        if (queryTokens.isEmpty()) return emptySet()
        return content.filter { (_, text) ->
            queryTokens.all { text.contains(it, ignoreCase = true) }
        }.keys
    }

    fun snippet(uri: Uri, tokens: List<String>): String {
        val text = content[uri.toString()] ?: return ""
        val idx = tokens.firstNotNullOfOrNull { text.indexOf(it, ignoreCase = true) }?.coerceAtLeast(0) ?: 0
        return text.substring(idx, minOf(idx + SNIPPET_LEN, text.length)).trim()
    }

    suspend fun indexDocument(ctx: Context, m: MediaItem): Unit = withContext(Dispatchers.IO) {
        val text = when {
            m.extension in TEXT_EXTS -> readText(ctx, m)
            m.extension == "pdf" -> extractPdf(ctx, m)
            else -> return@withContext
        }
        if (text.isNotBlank()) put(m.uri.toString(), text)
    }

    /** OCR for an image (used for scanned documents / receipts). */
    suspend fun ocrImage(ctx: Context, m: MediaItem): Unit = withContext(Dispatchers.IO) {
        runCatching {
            ctx.contentResolver.openInputStream(m.uri)?.use { input ->
                val bmp = BitmapFactory.decodeStream(input) ?: return@use
                val image = InputImage.fromBitmap(bmp, 0)
                val result = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                    .process(image).await()
                bmp.recycle()
                if (result.text.isNotBlank()) put(m.uri.toString(), result.text)
            }
        }
    }

    @Synchronized
    private fun put(uri: String, raw: String) {
        content = content + (uri to raw.lowercase().take(TEXT_CAP_BYTES))
    }

    private fun readText(ctx: Context, m: MediaItem): String = runCatching {
        ctx.contentResolver.openInputStream(m.uri)?.use {
            String(it.readBytes().take(TEXT_CAP_BYTES).toByteArray(), Charsets.UTF_8)
        }
    }.getOrNull().orEmpty()

    private fun extractPdf(ctx: Context, m: MediaItem): String = runCatching {
        PDFBoxResourceLoader.init(ctx)
        ctx.contentResolver.openInputStream(m.uri)?.use { input ->
            PDDocument.load(input).use { doc ->
                val stripper = PDFTextStripper().apply {
                    endPage = PDF_MAX_PAGES.coerceAtMost(doc.numberOfPages)
                }
                stripper.getText(doc)
            }
        }
    }.getOrNull().orEmpty()
}
