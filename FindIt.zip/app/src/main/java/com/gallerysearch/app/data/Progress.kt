package com.gallerysearch.app.data

import androidx.annotation.StringRes
import kotlinx.coroutines.flow.MutableStateFlow

enum class TaskStatus { IDLE, RUNNING, PAUSED, DONE, CANCELLED }

/**
 * Live progress of a long operation (scan / index). Exposed via [ProgressBus]
 * so both the UI and the foreground service read the same truth.
 */
data class TaskProgress(
    val status: TaskStatus = TaskStatus.IDLE,
    @StringRes val stageRes: Int = 0,
    val processed: Int = 0,
    val total: Int = 0,
    val currentName: String = "",
    val found: Int = 0,
    val startedAtMs: Long = 0L,
    val dupGroups: List<List<MediaItem>> = emptyList(),
    val similarGroups: List<List<MediaItem>> = emptyList(),
    val corrupt: List<MediaItem> = emptyList(),
) {
    val percent: Int get() = ProgressEngine.percent(processed, total)
    fun etaSeconds(nowMs: Long = System.currentTimeMillis()): Long? =
        ProgressEngine.etaSeconds(processed, total, ProgressEngine.elapsedSeconds(startedAtMs, nowMs))
}

/** Progress/ETA math — pure and unit-testable. Percent is always within 0..100. */
object ProgressEngine {
    fun percent(processed: Int, total: Int): Int =
        if (total <= 0 || processed <= 0) 0
        else ((processed.toLong() * 100L) / total).toInt().coerceIn(0, 100)

    /** Remaining seconds estimate, or null when there is nothing to estimate. */
    fun etaSeconds(processed: Int, total: Int, elapsedSec: Long): Long? {
        if (processed <= 0 || total <= 0 || processed >= total) return null
        return (elapsedSec * (total - processed).toLong() / processed).coerceAtLeast(0)
    }

    fun elapsedSeconds(startedAtMs: Long, nowMs: Long): Long =
        ((nowMs - startedAtMs) / 1000L).coerceAtLeast(0)
}

/** Process-wide progress channel between [com.gallerysearch.app.scan.ScanService] and the UI. */
object ProgressBus {
    val progress = MutableStateFlow(TaskProgress())
    fun reset() { progress.value = TaskProgress() }
}
