package com.gallerysearch.app.billing

import android.app.Activity
import android.content.Context
import com.android.billingclient.api.BillingClient
import com.android.billingclient.api.BillingClientStateListener
import com.android.billingclient.api.BillingFlowParams
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.ProductDetails
import com.android.billingclient.api.Purchase
import com.android.billingclient.api.PurchasesUpdatedListener
import com.android.billingclient.api.QueryProductDetailsParams
import com.android.billingclient.api.QueryPurchasesParams
import com.gallerysearch.app.settings.SettingsStore
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * Google Play Billing for the premium subscription (monthly / yearly).
 * Entitlements land in [SettingsStore.isPremium]; [restore] re-checks past
 * purchases. Everything no-ops gracefully where Play is unavailable.
 */
class BillingController(private val ctx: Context) {
    private val listener = PurchasesUpdatedListener { result, purchases ->
        if (result.responseCode == BillingClient.BillingResponseCode.OK && purchases != null) {
            if (purchases.any { it.products.contains(MONTHLY) || it.products.contains(YEARLY) }) {
                SettingsStore.setPremium(true)
            }
        }
    }

    private val client = BillingClient.newBuilder(ctx)
        .enablePendingPurchases()
        .setListener(listener)
        .build()

    private suspend fun ensureConnected(): Boolean = suspendCancellableCoroutine { cont ->
        if (client.isReady) {
            cont.resume(true)
            return@suspendCancellableCoroutine
        }
        client.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(result: BillingResult) {
                if (cont.isActive) {
                    cont.resume(result.responseCode == BillingClient.BillingResponseCode.OK)
                }
            }

            override fun onBillingServiceDisconnected() {
                if (cont.isActive) cont.resume(false)
            }
        })
    }

    suspend fun loadOffers(): List<ProductDetails> {
        if (!ensureConnected()) return emptyList()
        val params = QueryProductDetailsParams.newBuilder()
            .setProductList(
                listOf(MONTHLY, YEARLY).map {
                    QueryProductDetailsParams.Product.newBuilder()
                        .setProductId(it)
                        .setProductType(BillingClient.ProductType.SUBS)
                        .build()
                },
            )
            .build()
        val res = client.queryProductDetails(params)
        if (res.billingResult.responseCode != BillingClient.BillingResponseCode.OK) return emptyList()
        return res.productDetailsList.orEmpty()
    }

    fun launch(activity: Activity, details: ProductDetails) {
        val offer = details.subscriptionOfferDetails?.firstOrNull() ?: return
        val flow = BillingFlowParams.newBuilder()
            .setProductDetailsParamsList(
                listOf(
                    BillingFlowParams.ProductDetailsParams.newBuilder()
                        .setProductDetails(details)
                        .setOfferToken(offer.offerToken)
                        .build(),
                ),
            )
            .build()
        client.launchBillingFlow(activity, flow)
    }

    suspend fun restore(): Boolean {
        if (!ensureConnected()) return false
        val res = client.queryPurchasesAsync(
            QueryPurchasesParams.newBuilder()
                .setProductType(BillingClient.ProductType.SUBS)
                .build(),
        )
        val entitled = res.purchasesList.any {
            it.purchaseState == Purchase.PurchaseState.PURCHASED &&
                (it.products.contains(MONTHLY) || it.products.contains(YEARLY))
        }
        SettingsStore.setPremium(entitled)
        return entitled
    }

    fun end() {
        runCatching { if (client.isReady) client.endConnection() }
    }

    companion object {
        const val MONTHLY = "findit_premium_monthly"
        const val YEARLY = "findit_premium_yearly"
    }
}
