package com.gallerysearch.app.voice

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/**
 * Offline speech engine (bundled Vosk — no Google services). The small model
 * (~40 MB per language) downloads once on demand with progress, extracts into
 * app files, and is reused forever. Every failure logs with the VoiceSearch tag
 * and surfaces a state the UI can present.
 */
object VoskEngine {
    const val TAG = "VoiceSearch"
    private const val SAMPLE_RATE = 16000

    sealed interface State {
        data object Missing : State
        data class Downloading(val percent: Int, val lang: String) : State
        data class Extracting(val lang: String) : State
        data class Ready(val lang: String) : State
        data class Failed(val reason: String) : State
    }

    val state = kotlinx.coroutines.flow.MutableStateFlow<State>(State.Missing)
    private val models = mutableMapOf<String, Model>()

    private fun modelDir(ctx: Context, lang: String) = File(ctx.filesDir, "vosk/$lang")

    private fun urlFor(lang: String) = if (lang == "ar") {
        "https://alphacephei.com/vosk/models/vosk-model-small-ar-0.4.zip"
    } else {
        "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip"
    }

    fun hasReadyModel(lang: String): Boolean = models.containsKey(lang)

    /** Returns true when a usable model is present (downloads if needed). */
    suspend fun ensure(ctx: Context, lang: String): Boolean {
        if (models.containsKey(lang)) return true
        val dir = modelDir(ctx, lang)
        if (File(dir, "am/final.mdl").exists()) return loadModel(lang, dir)
        return download(ctx, lang)
    }

    private fun loadModel(lang: String, dir: File): Boolean = try {
        models[lang] = Model(dir.absolutePath)
        state.value = State.Ready(lang)
        Log.i(TAG, "model ready: $lang at ${dir.absolutePath}")
        true
    } catch (t: Throwable) {
        Log.e(TAG, "model load failed: ${t.message}")
        state.value = State.Failed(t.message ?: "load")
        false
    }

    private suspend fun download(ctx: Context, lang: String): Boolean = withContext(Dispatchers.IO) {
        val dir = modelDir(ctx, lang)
        dir.mkdirs()
        val zip = File(dir, "model.zip")
        try {
            Log.i(TAG, "downloading model for $lang")
            val conn = URL(urlFor(lang)).openConnection() as HttpURLConnection
            conn.connectTimeout = 30_000
            conn.readTimeout = 120_000
            conn.inputStream.use { input ->
                zip.outputStream().use { out ->
                    val buf = ByteArray(64 * 1024)
                    val total = conn.contentLengthLong.takeIf { it > 0 } ?: -1L
                    var read = input.read(buf)
                    var done = 0L
                    while (read != -1) {
                        out.write(buf, 0, read)
                        done += read
                        if (total > 0) {
                            state.value = State.Downloading(((done * 100) / total).toInt(), lang)
                        }
                        read = input.read(buf)
                    }
                }
            }
            state.value = State.Extracting(lang)
            extract(zip, dir)
            zip.delete()
            loadModel(lang, dir)
        } catch (t: Throwable) {
            Log.e(TAG, "download failed: ${t.message}")
            state.value = State.Failed(t.message ?: "download")
            false
        }
    }

    /** Extract a Vosk zip, stripping its single top-level folder. */
    private fun extract(zip: File, target: File) {
        ZipInputStream(zip.inputStream()).use { zin ->
            var entry = zin.nextEntry
            while (entry != null) {
                if (!entry.isDirectory) {
                    val parts = entry.name.split("/")
                    val rel = if (parts.size > 1) parts.drop(1).joinToString("/") else entry.name
                    if (rel.isNotEmpty() && !rel.contains("..")) {
                        val out = File(target, rel)
                        out.parentFile?.mkdirs()
                        out.outputStream().use { zin.copyTo(it) }
                    }
                }
                zin.closeEntry()
                entry = zin.nextEntry
            }
        }
    }

    /**
     * Listen until final result, silence after speech, or a 20s cap.
     * [onPartial] streams live partial text. Returns the final text or null.
     */
    suspend fun listen(lang: String, onPartial: (String) -> Unit): String? =
        withContext(Dispatchers.IO) {
            val model = models[lang] ?: return@withContext null
            val minBuf = AudioRecord.getMinBufferSize(
                SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
            )
            val rec = AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION,
                SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                maxOf(minBuf, 4096) * 2,
            )
            val recognizer = Recognizer(model, SAMPLE_RATE.toFloat())
            try {
                rec.startRecording()
                val buf = ShortArray(1600) // 100 ms chunks
                var lastText = ""
                var lastChange = System.currentTimeMillis()
                var speechStarted = false
                val deadline = System.currentTimeMillis() + 20_000
                while (isActive && System.currentTimeMillis() < deadline) {
                    val n = rec.read(buf, 0, buf.size)
                    if (n < 0) break
                    if (n == 0) continue
                    val spoken = recognizer.acceptWaveForm(buf, n)
                    if (spoken) {
                        val text = runCatching { JSONObject(recognizer.result).getString("text") }
                            .getOrDefault("")
                        if (text.isNotBlank()) return@withContext text
                    } else {
                        val partial = runCatching {
                            JSONObject(recognizer.partialResult).getString("partial")
                        }.getOrDefault("")
                        if (partial != lastText) {
                            lastText = partial
                            lastChange = System.currentTimeMillis()
                            speechStarted = speechStarted || partial.isNotBlank()
                            onPartial(partial)
                        }
                    }
                    // Auto-stop after 1.5s of silence once speech has started.
                    if (speechStarted && System.currentTimeMillis() - lastChange > 1500) {
                        return@withContext runCatching {
                            JSONObject(recognizer.result).getString("text")
                        }.getOrNull()
                    }
                }
                runCatching { JSONObject(recognizer.result).getString("text") }.getOrNull()
            } catch (t: Throwable) {
                Log.e(TAG, "listen failed: ${t.message}")
                null
            } finally {
                runCatching { rec.stop() }
                rec.release()
                recognizer.close()
            }
        }
}
