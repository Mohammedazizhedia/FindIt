package com.gallerysearch.app.debug

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CopyOnWriteArrayList

/**
 * Central app log: ring buffer (latest 500) mirrored to a file, so a report
 * can be copied or shared from Settings for analysis. Also mirrors to Logcat.
 */
object AppLog {
    enum class Level { D, I, W, E }

    data class Entry(
        val time: Long,
        val level: Level,
        val tag: String,
        val message: String,
    )

    private const val MAX_ENTRIES = 500
    private const val MAX_FILE_BYTES = 256 * 1024

    private val buffer = CopyOnWriteArrayList<Entry>()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var file: File
    private val fmt = SimpleDateFormat("MM-dd HH:mm:ss.SSS", Locale.US)

    val entries = MutableStateFlow<List<Entry>>(emptyList())
    val entryCount = MutableStateFlow(0)

    fun init(ctx: Context) {
        file = File(ctx.filesDir, "logs/app.log")
        file.parentFile?.mkdirs()
        runCatching {
            if (file.exists()) {
                file.readLines().takeLast(MAX_ENTRIES).forEach { line -> parse(line)?.let(buffer::add) }
            }
        }
        entries.value = buffer.toList()
        entryCount.value = buffer.size
    }

    private fun parse(line: String): Entry? = runCatching {
        // "MM-dd HH:mm:ss.SSS LEVEL/TAG message"
        val level = when (line.substring(19, 20)) {
            "D" -> Level.D
            "I" -> Level.I
            "W" -> Level.W
            else -> Level.E
        }
        val rest = line.substring(22)
        val sep = rest.indexOf(' ')
        Entry(System.currentTimeMillis(), level, rest.substring(0, sep), rest.substring(sep + 1))
    }.getOrNull()

    @Synchronized
    fun log(level: Level, tag: String, message: String, t: Throwable? = null) {
        val text = if (t != null) "$message | ${t.javaClass.simpleName}: ${t.message}" else message
        val entry = Entry(System.currentTimeMillis(), level, tag, text)
        buffer.add(entry)
        if (buffer.size > MAX_ENTRIES) buffer.removeAt(0)
        entries.value = buffer.toList()
        entryCount.value = buffer.size
        val line = "${fmt.format(Date(entry.time))} ${level.name}/$tag $text"
        scope.launch {
            runCatching {
                file.parentFile?.mkdirs()
                file.appendText(line + "\n")
                if (file.length() > MAX_FILE_BYTES) {
                    val keep = file.readLines().takeLast(MAX_ENTRIES)
                    file.writeText(keep.joinToString("\n") + "\n")
                }
            }
        }
        val p = when (level) {
            Level.D -> android.util.Log.DEBUG
            Level.I -> android.util.Log.INFO
            Level.W -> android.util.Log.WARN
            Level.E -> android.util.Log.ERROR
        }
        android.util.Log.println(p, tag, text)
    }

    fun d(tag: String, msg: String) = log(Level.D, tag, msg)
    fun i(tag: String, msg: String) = log(Level.I, tag, msg)
    fun w(tag: String, msg: String, t: Throwable? = null) = log(Level.W, tag, msg, t)
    fun e(tag: String, msg: String, t: Throwable? = null) = log(Level.E, tag, msg, t)

    /** Full report text ready to copy/share. */
    fun exportText(ctx: Context): String = buildString {
        val version = runCatching {
            ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName
        }.getOrDefault("?")
        appendLine("Find It log report")
        appendLine("version: $version | entries: ${buffer.size} | time: ${fmt.format(Date())}")
        appendLine("----------------------------------------")
        buffer.forEach { appendLine("${fmt.format(Date(it.time))} ${it.level.name}/${it.tag} ${it.message}") }
    }

    fun clear() {
        buffer.clear()
        entries.value = emptyList()
        entryCount.value = 0
        runCatching { file.delete() }
    }
}
