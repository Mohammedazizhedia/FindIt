package com.gallerysearch.app

import android.app.Activity
import android.os.Bundle
import android.widget.ScrollView
import android.widget.TextView

/** Debug helper: shows the fatal error on screen instead of a silent exit. */
class CrashActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val trace = intent.getStringExtra("trace") ?: "Unknown error"
        val text = TextView(this).apply {
            this.text = "Find It crashed:\n\n$trace"
            textSize = 12f
            setPadding(48, 48, 48, 48)
            setTextIsSelectable(true)
        }
        setContentView(ScrollView(this).apply { addView(text) })
    }
}
