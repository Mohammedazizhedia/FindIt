package com.gallerysearch.app.ui

import com.gallerysearch.app.voice.VoiceCommand
import kotlinx.coroutines.flow.MutableSharedFlow

/** One-shot UI commands (e.g. from voice) that the activity root must handle. */
object UiBus {
    val commands = MutableSharedFlow<VoiceCommand>(extraBufferCapacity = 4)
    suspend fun send(c: VoiceCommand) { commands.tryEmit(c) }
}
