package com.gallerysearch.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.GridView
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.SmartToy
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.gallerysearch.app.settings.LocaleHelper
import com.gallerysearch.app.settings.SettingsStore
import com.gallerysearch.app.ui.UiBus
import com.gallerysearch.app.ui.ai.AiScreen
import com.gallerysearch.app.ui.clean.CleanScreen
import com.gallerysearch.app.ui.components.LineIcon
import com.gallerysearch.app.ui.components.LineIconView
import com.gallerysearch.app.ui.home.HomeScreen
import com.gallerysearch.app.ui.settings.SettingsScreen
import com.gallerysearch.app.ui.theme.AppTheme
import com.gallerysearch.app.ui.theme.LocalTints
import com.gallerysearch.app.ui.theme.ThemeMode
import com.gallerysearch.app.voice.VoiceCommand

class MainActivity : ComponentActivity() {
    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(
            LocaleHelper.wrap(newBase, SettingsStore.persistedLanguage(newBase)),
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val mode = SettingsStore.themeMode.collectAsStateWithLifecycle().value
            val accent = SettingsStore.accent.collectAsStateWithLifecycle().value
            AppTheme(mode = mode, accent = accent) { App() }
        }
    }
}

@Composable
fun App(vm: GalleryViewModel = viewModel()) {
    val ctx = LocalContext.current
    val perms = remember {
        if (Build.VERSION.SDK_INT >= 33) {
            arrayOf(
                Manifest.permission.READ_MEDIA_IMAGES,
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.READ_MEDIA_AUDIO,
                Manifest.permission.POST_NOTIFICATIONS,
                Manifest.permission.RECORD_AUDIO,
            )
        } else {
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
    }
    var granted by remember {
        mutableStateOf(perms.all { ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED })
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        granted = r.values.all { it }
    }

    var tab by rememberSaveable {
        mutableIntStateOf(
            when ((ctx as? Activity)?.intent?.getStringExtra("tab")) {
                "clean" -> 1
                "widgets" -> 2
                "ai" -> 4
                "settings" -> 3
                else -> 0
            },
        )
    }
    val activity = ctx as? Activity

    LaunchedEffect(granted) { if (granted) vm.load() }

    // Voice commands routed from the voice sheet (and later widgets).
    LaunchedEffect(Unit) {
        UiBus.commands.collect { cmd ->
            when (cmd) {
                is VoiceCommand.Search -> { vm.query.value = cmd.query; tab = 0 }
                VoiceCommand.OpenDuplicates -> { vm.startScan(); tab = 1 }
                VoiceCommand.OpenCorrupt -> { vm.startScan(); tab = 1 }
                VoiceCommand.OpenTrash -> tab = 1
                VoiceCommand.OpenSettings -> tab = 3
                VoiceCommand.StartScan -> { vm.startScan(); tab = 1 }
                is VoiceCommand.SetTheme -> SettingsStore.setThemeMode(
                    if (cmd.dark) ThemeMode.DARK else ThemeMode.LIGHT,
                )
                VoiceCommand.Stop -> Unit
            }
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar {
                NavigationBarItem(tab == 0, { tab = 0 }, { Icon(Icons.Outlined.Search, null) },
                    label = { Text(stringResource(R.string.tab_search)) })
                NavigationBarItem(tab == 1, { tab = 1 }, { Icon(Icons.Outlined.AutoAwesome, null) },
                    label = { Text(stringResource(R.string.tab_clean)) })
                NavigationBarItem(tab == 2, { tab = 2 }, { Icon(Icons.Outlined.GridView, null) },
                    label = { Text(stringResource(R.string.tab_widgets)) })
                NavigationBarItem(tab == 3, { tab = 3 }, { Icon(Icons.Outlined.Settings, null) },
                    label = { Text(stringResource(R.string.tab_settings)) })
                NavigationBarItem(tab == 4, { tab = 4 }, { Icon(Icons.Outlined.SmartToy, null) },
                    label = { Text(stringResource(R.string.tab_ai)) })
            }
        },
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when {
                !granted -> PermissionScreen { launcher.launch(perms) }
                tab == 0 -> HomeScreen(vm)
                tab == 1 -> CleanScreen(vm)
                tab == 2 -> WidgetsScreen()
                tab == 4 -> AiScreen()
                else -> SettingsScreen(onLanguageChanged = { activity?.recreate() })
            }
        }
    }
}

@Composable
private fun PermissionScreen(onGrant: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        LineIconView(LineIcon.Scenery, LocalTints.current.accent.fg, 72.dp)
        Spacer(Modifier.height(16.dp))
        Text(stringResource(R.string.perm_title), style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center)
        Spacer(Modifier.height(8.dp))
        Text(stringResource(R.string.perm_body), style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center)
        Spacer(Modifier.height(16.dp))
        Button(onClick = onGrant) { Text(stringResource(R.string.perm_grant)) }
    }
}

@Composable
private fun WidgetsScreen() {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        LineIconView(LineIcon.Dup, LocalTints.current.pro.fg, 72.dp)
        Spacer(Modifier.height(16.dp))
        Text(stringResource(R.string.widgets_title), style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp))
        Text(stringResource(R.string.widgets_soon), style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center)
    }
}
