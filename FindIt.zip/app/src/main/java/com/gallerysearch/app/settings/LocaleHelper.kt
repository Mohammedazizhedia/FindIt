package com.gallerysearch.app.settings

import android.content.Context
import android.content.res.Configuration
import java.util.Locale

object LocaleHelper {
    /**
     * Returns a context bound to [lang]. Empty string means "follow the system",
     * in which case the base context is returned untouched (system locale applies).
     */
    fun wrap(base: Context, lang: String): Context {
        if (lang.isEmpty()) return base
        val locale = Locale(lang)
        Locale.setDefault(locale)
        val config = Configuration(base.resources.configuration)
        config.setLocale(locale)
        config.setLayoutDirection(locale)
        return base.createConfigurationContext(config)
    }
}
