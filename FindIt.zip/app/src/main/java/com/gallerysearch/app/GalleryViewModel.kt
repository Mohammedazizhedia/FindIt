package com.gallerysearch.app

import android.app.Application
import android.content.Intent
import android.content.IntentSender
import android.net.Uri
import android.provider.MediaStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.gallerysearch.app.data.Analyzer
import com.gallerysearch.app.data.Category
import com.gallerysearch.app.data.ProgressBus
import com.gallerysearch.app.data.TaskStatus
import com.gallerysearch.app.data.FilterMatcher
import com.gallerysearch.app.data.MediaItem
import com.gallerysearch.app.data.MediaRepository
import com.gallerysearch.app.data.Pager
import com.gallerysearch.app.data.SearchFilters
import com.gallerysearch.app.data.ContentIndex
import com.gallerysearch.app.data.RestoreReport
import com.gallerysearch.app.data.VisualIndex
import com.gallerysearch.app.data.TrashEntry
import com.gallerysearch.app.data.TrashRepository
import com.gallerysearch.app.scan.ScanService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class ScanState(
    val running: Boolean = false,
    val paused: Boolean = false,
    val done: Boolean = false,
    val progress: Int = 0,
    val total: Int = 0,
    val startedAtMs: Long = 0L,
    val dupGroups: List<List<MediaItem>> = emptyList(),
    val similarGroups: List<List<MediaItem>> = emptyList(),
    val corrupt: List<MediaItem> = emptyList(),
) {
    val dupExtra: Int get() = (dupGroups + similarGroups).sumOf { it.size - 1 }
    val dupBytes: Long get() = (dupGroups + similarGroups).sumOf { it.first().size * (it.size - 1) }
}

/** One emission of the search pipeline (all items + query + filters + visible count). */
private data class SearchTick(
    val all: List<MediaItem>,
    val query: String,
    val filters: SearchFilters,
    val visible: Int,
)

class GalleryViewModel(app: Application) : AndroidViewModel(app) {
    val items = MutableStateFlow<List<MediaItem>>(emptyList())
    val query = MutableStateFlow("")

    /** Active filters (extension / size / date / folder). See [setFilters]. */
    val filters = MutableStateFlow(SearchFilters.DEFAULT)

    /** Paged search results — the only list the home grid renders. */
    val results = MutableStateFlow<List<MediaItem>>(emptyList())

    /** Total matches for the current query + filters, before paging. */
    val resultCount = MutableStateFlow(0)

    /** Live per-category counts over the whole library (not affected by search). */
    val categoryCounts = MutableStateFlow<Map<Category, Int>>(emptyMap())

    /** Folder name -> file count, for the folder filter (not affected by search). */
    val folderCounts = MutableStateFlow<Map<String, Int>>(emptyMap())

    val scan = MutableStateFlow(ScanState())
    val trash = MutableStateFlow<List<TrashEntry>>(emptyList())
    val busy = MutableStateFlow(false)
    val notice = MutableStateFlow<String?>(null)
    /** Per-file outcome of the last restore operation (for the trash screen). */
    val restoreReport = MutableStateFlow<RestoreReport?>(null)
    private val trashRepo = TrashRepository(app)

    private val visibleCount = MutableStateFlow(Pager.DEFAULT_PAGE_SIZE)
    private var lastItemsRef: List<MediaItem>? = null
    private var lastSearchKey: Pair<String, SearchFilters>? = null

    init {
        viewModelScope.launch(Dispatchers.IO) {
            trashRepo.maintenance()
            trash.value = trashRepo.list()
        }
        // Mirror the foreground service progress into the legacy ScanState so the
        // clean screens keep working unchanged.
        viewModelScope.launch {
            ProgressBus.progress.collect { p ->
                scan.value = ScanState(
                    running = p.status == TaskStatus.RUNNING || p.status == TaskStatus.PAUSED,
                    paused = p.status == TaskStatus.PAUSED,
                    done = p.status == TaskStatus.DONE,
                    progress = p.processed,
                    total = p.total,
                    startedAtMs = p.startedAtMs,
                    dupGroups = p.dupGroups,
                    similarGroups = p.similarGroups,
                    corrupt = p.corrupt,
                )
            }
        }
        viewModelScope.launch {
            combine(items, query, filters, visibleCount) { list, q, f, vis ->
                SearchTick(list, q, f, vis)
            }.collect { tick ->
                val key = tick.query to tick.filters
                if (key != lastSearchKey) {
                    // Query/filters changed: restart paging from the first page.
                    lastSearchKey = key
                    if (tick.visible != Pager.DEFAULT_PAGE_SIZE) {
                        visibleCount.value = Pager.DEFAULT_PAGE_SIZE
                        return@collect
                    }
                }
                if (tick.all !== lastItemsRef) {
                    lastItemsRef = tick.all
                    categoryCounts.value = tick.all.groupingBy { it.category }.eachCount()
                    folderCounts.value = tick.all
                        .filter { it.folder.isNotEmpty() }
                        .groupingBy { it.folder }
                        .eachCount()
                }
                var filtered = FilterMatcher.apply(tick.all, tick.filters, tick.query)
                // Expand with visual-label and document-content hits (name hits first).
                val tokens = tick.query.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
                if (tokens.isNotEmpty() && tick.filters == SearchFilters.DEFAULT) {
                    val known = filtered.map { it.uri.toString() }.toHashSet()
                    val byUri = tick.all.associateBy { it.uri.toString() }
                    val extra = (VisualIndex.search(tokens) + ContentIndex.search(tokens))
                        .mapNotNull { byUri[it] }
                        .filter { it.uri.toString() !in known }
                    if (extra.isNotEmpty()) filtered = filtered + extra
                }
                resultCount.value = filtered.size
                results.value = filtered.take(tick.visible.coerceAtLeast(Pager.DEFAULT_PAGE_SIZE))
            }
        }
    }

    fun load() {
        viewModelScope.launch {
            val ctx = getApplication<Application>()
            VisualIndex.load(ctx)
            ContentIndex.load(ctx)
            items.value = MediaRepository.load(ctx)
        }
    }

    /** Find photos visually similar to the picked one (perceptual hash distance). */
    fun searchSimilarTo(item: MediaItem) {
        viewModelScope.launch {
            val ctx = getApplication<Application>()
            VisualIndex.load(ctx)
            val h = Analyzer.perceptualHash(ctx, item) ?: return@launch
            val uris = VisualIndex.similarTo(h).toSet() + item.uri.toString()
            val hits = items.value
                .filter { it.uri.toString() in uris }
                .sortedBy { if (it.uri == item.uri) 0 else 1 }
            resultCount.value = hits.size
            results.value = hits
        }
    }

    /** Grow the visible window by one page when the grid approaches the end. */
    fun loadMore() {
        visibleCount.update { it + Pager.DEFAULT_PAGE_SIZE }
    }

    fun setFilters(value: SearchFilters) {
        filters.value = value
    }

    private fun scanIntent(action: String): Intent =
        Intent(getApplication(), ScanService::class.java).setAction(action)

    /** Start the scan in the foreground service (survives the app being closed). */
    fun startScan() {
        getApplication<Application>().startService(scanIntent(ScanService.ACTION_START))
    }

    fun pauseScan() {
        getApplication<Application>().startService(scanIntent(ScanService.ACTION_PAUSE))
    }

    fun resumeScan() {
        getApplication<Application>().startService(scanIntent(ScanService.ACTION_RESUME))
    }

    fun cancelScan() {
        getApplication<Application>().startService(scanIntent(ScanService.ACTION_CANCEL))
    }

    /** Step 1: store a verified copy in the app trash. Returns null when nothing could be backed up. */
    suspend fun prepareTrash(list: List<MediaItem>): List<TrashEntry>? {
        busy.value = true
        notice.value = null
        val (entries, failed) = withContext(Dispatchers.IO) { trashRepo.copyIn(list) }
        busy.value = false
        if (failed > 0) {
            notice.value = getApplication<Application>().getString(R.string.notice_copy_failed, failed)
        }
        return if (entries.isEmpty()) null else entries
    }

    /** Step 2: the system dialog that deletes the originals (only those that were backed up). */
    fun deleteIntent(entries: List<TrashEntry>): IntentSender =
        MediaStore.createDeleteRequest(
            getApplication<Application>().contentResolver,
            entries.map { Uri.parse(it.originalUri) },
        ).intentSender

    fun commitTrash(entries: List<TrashEntry>, removed: Set<Uri>) {
        viewModelScope.launch(Dispatchers.IO) {
            trashRepo.commit(entries.map { it.id }.toSet())
            trash.value = trashRepo.list()
        }
        onTrashed(removed)
    }

    fun discardTrash(entries: List<TrashEntry>) {
        viewModelScope.launch(Dispatchers.IO) { trashRepo.discard(entries) }
    }

    fun restore(sel: List<TrashEntry>) {
        viewModelScope.launch {
            busy.value = true
            notice.value = null
            val report = withContext(Dispatchers.IO) { trashRepo.restore(sel) }
            trash.value = withContext(Dispatchers.IO) { trashRepo.list() }
            busy.value = false
            restoreReport.value = report
            if (report.failedCount > 0) {
                notice.value = getApplication<Application>()
                    .getString(R.string.notice_restore_failed, report.failedCount)
            }
            load()
        }
    }

    fun purge(sel: List<TrashEntry>) {
        viewModelScope.launch(Dispatchers.IO) {
            trashRepo.purge(sel)
            trash.value = trashRepo.list()
        }
    }

    fun onTrashed(removed: Set<Uri>) {
        items.update { l -> l.filter { it.uri !in removed } }
        scan.update { s ->
            s.copy(
                dupGroups = s.dupGroups.map { g -> g.filter { it.uri !in removed } }.filter { it.size > 1 },
                corrupt = s.corrupt.filter { it.uri !in removed },
            )
        }
    }
}
