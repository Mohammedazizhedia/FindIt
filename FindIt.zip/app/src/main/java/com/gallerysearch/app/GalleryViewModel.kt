package com.gallerysearch.app

import android.app.Application
import android.content.Intent
import android.content.IntentSender
import android.net.Uri
import android.provider.MediaStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.gallerysearch.app.data.Analyzer
import com.gallerysearch.app.data.Category
import com.gallerysearch.app.data.ContentIndex
import com.gallerysearch.app.data.FilterMatcher
import com.gallerysearch.app.data.MediaItem
import com.gallerysearch.app.data.MediaRepository
import com.gallerysearch.app.data.Pager
import com.gallerysearch.app.data.ProgressBus
import com.gallerysearch.app.data.RestoreReport
import com.gallerysearch.app.data.SearchFilters
import com.gallerysearch.app.data.TaskStatus
import com.gallerysearch.app.data.TrashEntry
import com.gallerysearch.app.data.TrashRepository
import com.gallerysearch.app.data.VisualIndex
import com.gallerysearch.app.scan.ScanService
import com.gallerysearch.app.debug.AppLog
import com.gallerysearch.app.settings.SettingsStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class ScanState(
    val running: Boolean = false,
    val paused: Boolean = false,
    val done: Boolean = false,
    val progress: Int = 0,
    val total: Int = 0,
    val startedAtMs: Long = 0L,
    val dupGroups: List<List<MediaItem>> = emptyList(),
    val similarGroups: List<List<MediaItem>> = emptyList(),
    val corrupt: List<MediaItem> = emptyList(),
) {
    val dupExtra: Int get() = (dupGroups + similarGroups).sumOf { it.size - 1 }
    val dupBytes: Long get() = (dupGroups + similarGroups).sumOf { it.first().size * (it.size - 1) }
}

class GalleryViewModel(app: Application) : AndroidViewModel(app) {
    val items = MutableStateFlow<List<MediaItem>>(emptyList())
    val query = MutableStateFlow("")
    val filters = MutableStateFlow(SearchFilters.DEFAULT)
    val results = MutableStateFlow<List<MediaItem>>(emptyList())
    val resultCount = MutableStateFlow(0)
    val categoryCounts = MutableStateFlow<Map<Category, Int>>(emptyMap())
    val folderCounts = MutableStateFlow<Map<String, Int>>(emptyMap())
    /** Indexed images vs total images (label/aHash index coverage). */
    val indexStats = MutableStateFlow(0 to 0)
    val scan = MutableStateFlow(ScanState())
    val trash = MutableStateFlow<List<TrashEntry>>(emptyList())
    val busy = MutableStateFlow(false)
    val notice = MutableStateFlow<String?>(null)
    val restoreReport = MutableStateFlow<RestoreReport?>(null)
    private val trashRepo = TrashRepository(app)

    private val visibleCount = MutableStateFlow(Pager.DEFAULT_PAGE_SIZE)

    init {
        viewModelScope.launch(Dispatchers.IO) {
            trashRepo.maintenance()
            trash.value = trashRepo.list()
        }
        viewModelScope.launch {
            ProgressBus.progress.collect { p ->
                scan.value = ScanState(
                    running = p.status == TaskStatus.RUNNING || p.status == TaskStatus.PAUSED,
                    paused = p.status == TaskStatus.PAUSED,
                    done = p.status == TaskStatus.DONE || p.status == TaskStatus.CANCELLED,
                    progress = p.processed,
                    total = p.total,
                    startedAtMs = p.startedAtMs,
                    dupGroups = p.dupGroups,
                    similarGroups = p.similarGroups,
                    corrupt = p.corrupt,
                )
            }
        }
    }

    fun load() {
        viewModelScope.launch {
            try {
            val ctx = getApplication<Application>()
            VisualIndex.load(ctx)
            ContentIndex.load(ctx)
            items.value = MediaRepository.load(ctx)
            AppLog.i("Search", "loaded ${items.value.size} files (${SettingsStore.safFolders.value.size} SAF folders)")
            recompute()
        } catch (t: Throwable) {
            AppLog.e("Search", "load failed", t)
        }
        }
    }

    /** Single source of truth: recompute counts + filtered results. Called on every change. */
    private fun recompute() {
        try {
            recomputeInner()
        } catch (t: Throwable) {
            AppLog.e("Search", "recompute failed", t)
        }
    }

    private fun recomputeInner() {
        val all = items.value
        categoryCounts.value = all.groupingBy { it.category }.eachCount()
        folderCounts.value = all.filter { it.folder.isNotEmpty() }.groupingBy { it.folder }.eachCount()
        var filtered = FilterMatcher.apply(all, filters.value, query.value)
        val rawTokens = query.value.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        // Arabic queries expand through the offline lexicon so "سيارة" matches the
        // English label index too.
        val tokens = (rawTokens + rawTokens.mapNotNull { ArEnLexicon.toEnglish(it.lowercase()) }).distinct()
        if (tokens.isNotEmpty() && filters.value == SearchFilters.DEFAULT) {
            val known = filtered.map { it.uri.toString() }.toHashSet()
            val byUri = all.associateBy { it.uri.toString() }
            val extra = (VisualIndex.search(tokens) + ContentIndex.search(tokens))
                .mapNotNull { byUri[it] }
                .filter { it.uri.toString() !in known }
            if (extra.isNotEmpty()) filtered = filtered + extra
        }
        indexStats.value = VisualIndex.hashes.size to all.count { it.category == Category.IMAGE }
        resultCount.value = filtered.size
        results.value = filtered.take(visibleCount.value.coerceAtLeast(Pager.DEFAULT_PAGE_SIZE))
    }

    fun setQuery(q: String) {
        visibleCount.value = Pager.DEFAULT_PAGE_SIZE
        query.value = q
        recompute()
    }

    fun setFilters(f: SearchFilters) {
        visibleCount.value = Pager.DEFAULT_PAGE_SIZE
        filters.value = f
        recompute()
    }

    fun loadMore() {
        visibleCount.value += Pager.DEFAULT_PAGE_SIZE
        recompute()
    }

    fun searchSimilarTo(item: MediaItem) {
        viewModelScope.launch {
            val ctx = getApplication<Application>()
            VisualIndex.load(ctx)
            val h = Analyzer.perceptualHash(ctx, item) ?: return@launch
            val uris = VisualIndex.similarTo(h).toSet() + item.uri.toString()
            val hits = items.value
                .filter { it.uri.toString() in uris }
                .sortedBy { if (it.uri == item.uri) 0 else 1 }
            query.value = ""
            resultCount.value = hits.size
            results.value = hits
        }
    }

    private fun scanIntent(action: String): Intent =
        Intent(getApplication(), ScanService::class.java).setAction(action)

    fun startScan() {
        getApplication<Application>().startService(scanIntent(ScanService.ACTION_START))
    }

    fun pauseScan() {
        getApplication<Application>().startService(scanIntent(ScanService.ACTION_PAUSE))
    }

    fun resumeScan() {
        getApplication<Application>().startService(scanIntent(ScanService.ACTION_RESUME))
    }

    fun cancelScan() {
        getApplication<Application>().startService(scanIntent(ScanService.ACTION_CANCEL))
    }

    /** Full reset: clear partial results after a cancelled scan. */
    fun resetScan() {
        ProgressBus.reset()
    }

    /** Grant a SAF folder and reload the library so its files become searchable. */
    fun addSafFolder(treeUri: Uri) {
        runCatching {
            getApplication<Application>().contentResolver.takePersistableUriPermission(
                treeUri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION,
            )
        }
        SettingsStore.addSafFolder(treeUri.toString())
        load()
    }

    suspend fun prepareTrash(list: List<MediaItem>): List<TrashEntry>? {
        busy.value = true
        notice.value = null
        val (entries, failed) = withContext(Dispatchers.IO) { trashRepo.copyIn(list) }
        busy.value = false
        if (failed > 0) {
            notice.value = getApplication<Application>().getString(R.string.notice_copy_failed, failed)
        }
        return if (entries.isEmpty()) null else entries
    }

    fun deleteIntent(entries: List<TrashEntry>): IntentSender =
        MediaStore.createDeleteRequest(
            getApplication<Application>().contentResolver,
            entries.map { Uri.parse(it.originalUri) },
        ).intentSender

    fun commitTrash(entries: List<TrashEntry>, removed: Set<Uri>) {
        viewModelScope.launch(Dispatchers.IO) {
            trashRepo.commit(entries.map { it.id }.toSet())
            trash.value = trashRepo.list()
        }
        onTrashed(removed)
    }

    fun discardTrash(entries: List<TrashEntry>) {
        viewModelScope.launch(Dispatchers.IO) { trashRepo.discard(entries) }
    }

    fun restore(sel: List<TrashEntry>) {
        viewModelScope.launch {
            busy.value = true
            notice.value = null
            val report = withContext(Dispatchers.IO) { trashRepo.restore(sel) }
            trash.value = withContext(Dispatchers.IO) { trashRepo.list() }
            busy.value = false
            restoreReport.value = report
            if (report.failedCount > 0) {
                notice.value = getApplication<Application>()
                    .getString(R.string.notice_restore_failed, report.failedCount)
            }
            load()
        }
    }

    fun purge(sel: List<TrashEntry>) {
        viewModelScope.launch(Dispatchers.IO) {
            trashRepo.purge(sel)
            trash.value = trashRepo.list()
        }
    }

    fun onTrashed(removed: Set<Uri>) {
        items.update { l -> l.filter { it.uri !in removed } }
        recompute()
        scan.update { s ->
            s.copy(
                dupGroups = s.dupGroups.map { g -> g.filter { it.uri !in removed } }.filter { it.size > 1 },
                corrupt = s.corrupt.filter { it.uri !in removed },
            )
        }
    }
}
