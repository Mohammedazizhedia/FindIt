package com.gallerysearch.app.data

import java.time.LocalDate
import java.time.ZoneId

/**
 * Filters for the universal search. Default/empty fields mean "no restriction".
 * Dates are epoch seconds (MediaStore DATE_ADDED), sizes in bytes.
 */
data class SearchFilters(
    val extensions: Set<String> = emptySet(),
    val minBytes: Long = 0L,
    val maxBytes: Long = Long.MAX_VALUE,
    val dateFromSec: Long = 0L,
    val dateToSec: Long = Long.MAX_VALUE,
    val folders: Set<String> = emptySet(),
) {
    companion object {
        val DEFAULT = SearchFilters()
    }
}

/** Pure matching logic — no Android dependencies, fully unit-testable. */
object FilterMatcher {
    fun matches(item: MediaItem, filters: SearchFilters, query: String = ""): Boolean {
        if (item.size < filters.minBytes || item.size > filters.maxBytes) return false
        if (item.dateAdded < filters.dateFromSec || item.dateAdded > filters.dateToSec) return false
        if (filters.extensions.isNotEmpty() &&
            filters.extensions.none { it.equals(item.extension, ignoreCase = true) }
        ) return false
        if (filters.folders.isNotEmpty() && item.folder !in filters.folders) return false
        val q = query.trim()
        if (q.isEmpty()) return true
        return q.split(Regex("\\s+")).all { token ->
            item.name.contains(token, ignoreCase = true)
        }
    }

    fun apply(items: List<MediaItem>, filters: SearchFilters, query: String = ""): List<MediaItem> =
        items.filter { matches(it, filters, query) }
}

/** Date presets for the filters sheet. Pure and unit-testable via [nowSec]. */
object DatePresets {
    const val ALL = 0
    const val TODAY = 1
    const val WEEK = 2
    const val MONTH = 3
    const val YEAR = 4

    private const val DAY = 24L * 60 * 60

    /** Returns (fromSec, toSec) inclusive. */
    fun range(id: Int, nowSec: Long = System.currentTimeMillis() / 1000): Pair<Long, Long> = when (id) {
        TODAY -> dayStart(nowSec) to Long.MAX_VALUE
        WEEK -> nowSec - 7 * DAY to Long.MAX_VALUE
        MONTH -> nowSec - 30 * DAY to Long.MAX_VALUE
        YEAR -> nowSec - 365 * DAY to Long.MAX_VALUE
        else -> 0L to Long.MAX_VALUE
    }

    private fun dayStart(nowSec: Long): Long {
        val zone = ZoneId.systemDefault()
        return LocalDate.now(zone).atStartOfDay(zone).toEpochSecond()
    }
}
