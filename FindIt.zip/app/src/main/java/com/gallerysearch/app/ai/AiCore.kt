package com.gallerysearch.app.ai

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.KeyStore
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

data class ChatMessage(val role: String, val text: String, val at: Long = System.currentTimeMillis())

sealed class AiError(message: String) : Exception(message) {
    class QuotaExhausted : AiError("quota")
    class RateLimited : AiError("rate limited")
    class Http(val code: Int, msg: String) : AiError("$code: $msg")
}

/** Rough token counting (≈4 chars/token) — pure and unit-testable. */
object TokenCounter {
    fun count(text: String): Int = maxOf(1, text.length / 4)
    fun fits(text: String, limit: Int): Boolean = count(text) <= limit
}

interface AiProvider {
    val id: String
    val label: String
    val freeTier: Boolean
    val freeDailyLimit: Int
    val models: List<String>
    fun hasKey(ctx: Context): Boolean
    suspend fun chat(ctx: Context, model: String, messages: List<ChatMessage>): String
}

private fun httpJson(
    url: String,
    headers: Map<String, String>,
    body: JSONObject,
    timeoutMs: Int = 30_000,
): JSONObject {
    val conn = URL(url).openConnection() as HttpURLConnection
    try {
        conn.requestMethod = "POST"
        conn.connectTimeout = timeoutMs
        conn.readTimeout = timeoutMs
        conn.doOutput = true
        headers.forEach { (k, v) -> conn.setRequestProperty(k, v) }
        conn.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = conn.responseCode
        val payload = (if (code in 200..299) conn.inputStream else conn.errorStream)
            ?.bufferedReader()?.use { it.readText() }.orEmpty()
        if (code == 429) throw AiError.RateLimited()
        if (code == 400 && payload.contains("quota", true)) throw AiError.QuotaExhausted()
        if (code !in 200..299) throw AiError.Http(code, payload.take(200))
        return JSONObject(payload)
    } finally {
        conn.disconnect()
    }
}

class GeminiProvider : AiProvider {
    override val id = "gemini"
    override val label = "Gemini"
    override val freeTier = true
    override val freeDailyLimit = 1500
    override val models = listOf("gemini-3.8-flash", "gemini-3.8-flash-lite")
    override fun hasKey(ctx: Context) = !KeystoreVault.get(ctx, id).isNullOrBlank()
    override suspend fun chat(ctx: Context, model: String, messages: List<ChatMessage>): String =
        withContext(Dispatchers.IO) {
            val key = KeystoreVault.get(ctx, id) ?: throw AiError.Http(401, "no key")
            val contents = JSONArray()
            messages.forEach { m ->
                contents.put(
                    JSONObject().put(
                        "parts",
                        JSONArray().put(JSONObject().put("text", m.text)),
                    ).put(
                        "role",
                        if (m.role == "assistant") "model" else "user",
                    ),
                )
            }
            val body = JSONObject().put("contents", contents)
            val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$key"
            val res = httpJson(url, mapOf("Content-Type" to "application/json"), body)
            res.getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0)
                .getString("text")
        }
}

class OpenAiProvider : AiProvider {
    override val id = "openai"
    override val label = "ChatGPT"
    override val freeTier = false
    override val freeDailyLimit = 0
    override val models = listOf("gpt-5-mini", "gpt-5")
    override fun hasKey(ctx: Context) = !KeystoreVault.get(ctx, id).isNullOrBlank()
    override suspend fun chat(ctx: Context, model: String, messages: List<ChatMessage>): String =
        withContext(Dispatchers.IO) {
            val key = KeystoreVault.get(ctx, id) ?: throw AiError.Http(401, "no key")
            val arr = JSONArray()
            messages.forEach { m ->
                arr.put(JSONObject().put("role", if (m.role == "assistant") "assistant" else "user").put("content", m.text))
            }
            val body = JSONObject().put("model", model).put("messages", arr)
            val res = httpJson(
                "https://api.openai.com/v1/chat/completions",
                mapOf("Content-Type" to "application/json", "Authorization" to "Bearer $key"),
                body,
            )
            res.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
        }
}

class ClaudeProvider : AiProvider {
    override val id = "claude"
    override val label = "Claude"
    override val freeTier = false
    override val freeDailyLimit = 0
    override val models = listOf("claude-3-5-haiku-latest", "claude-sonnet-4-5")
    override fun hasKey(ctx: Context) = !KeystoreVault.get(ctx, id).isNullOrBlank()
    override suspend fun chat(ctx: Context, model: String, messages: List<ChatMessage>): String =
        withContext(Dispatchers.IO) {
            val key = KeystoreVault.get(ctx, id) ?: throw AiError.Http(401, "no key")
            val system = messages.lastOrNull { it.role == "system" }?.text ?: "You are a helpful assistant."
            val arr = JSONArray()
            messages.filter { it.role != "system" }.forEach { m ->
                arr.put(
                    JSONObject().put("role", if (m.role == "assistant") "assistant" else "user")
                        .put("content", m.text),
                )
            }
            val body = JSONObject().put("model", model).put("max_tokens", 1024)
                .put("system", system).put("messages", arr)
            val res = httpJson(
                "https://api.anthropic.com/v1/messages",
                mapOf(
                    "Content-Type" to "application/json",
                    "x-api-key" to key,
                    "anthropic-version" to "2023-06-01",
                ),
                body,
            )
            res.getJSONArray("content").getJSONObject(0).getString("text")
        }
}

/** API keys encrypted with a Keystore-backed AES/GCM key. */
object KeystoreVault {
    private const val KEYSTORE = "AndroidKeyStore"
    private const val ALIAS = "findit_ai_keys"
    private const val PREFS = "ai_keys"

    private fun secretKey(): SecretKey {
        val ks = KeyStore.getInstance(KEYSTORE).apply { load(null) }
        (ks.getEntry(ALIAS, null) as? KeyStore.SecretKeyEntry)?.let { return it.secretKey }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KEYSTORE)
        gen.init(
            KeyGenParameterSpec.Builder(
                ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT,
            ).setKeySize(256)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .build(),
        )
        return gen.generateKey()
    }

    fun put(ctx: Context, providerId: String, value: String) {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, secretKey())
        val iv = cipher.iv
        val enc = cipher.doFinal(value.toByteArray())
        val blob = Base64.encodeToString(iv + enc, Base64.NO_WRAP)
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(providerId, blob).apply()
    }

    fun get(ctx: Context, providerId: String): String? = runCatching {
        val blob = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(providerId, null) ?: return null
        val raw = Base64.decode(blob, Base64.NO_WRAP)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(128, raw, 0, 12))
        String(cipher.doFinal(raw, 12, raw.size - 12))
    }.getOrNull()

    fun clear(ctx: Context, providerId: String) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(providerId).apply()
    }
}

/** Per-provider per-day call counts (JSON). Free tiers enforce daily limits. */
object UsageStore {
    private const val FILE = "ai_usage.json"
    private val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    @Volatile
    private var data: JSONObject = JSONObject()

    fun load(ctx: Context) = runCatching {
        val f = ctx.getFileStreamPath(FILE) ?: return@runCatching
        if (f.exists()) ctx.openFileInput(FILE).bufferedReader().use {
            data = JSONObject(it.readText())
        }
    }

    @Synchronized
    fun save(ctx: Context) = runCatching {
        ctx.openFileOutput(FILE, Context.MODE_PRIVATE).writer().use { it.write(data.toString()) }
    }

    fun usedToday(ctx: Context, providerId: String): Int {
        val p = data.optJSONObject(providerId) ?: return 0
        return if (p.optString("day") == fmt.format(Date())) p.optInt("count") else 0
    }

    @Synchronized
    fun record(ctx: Context, providerId: String) {
        val today = fmt.format(Date())
        val p = data.optJSONObject(providerId)
        val count = if (p != null && p.optString("day") == today) p.optInt("count") + 1 else 1
        data.put(providerId, JSONObject().put("day", today).put("count", count))
        save(ctx)
    }

    fun remaining(provider: AiProvider, usedToday: Int): Int =
        if (provider.freeTier) maxOf(0, provider.freeDailyLimit - usedToday) else Int.MAX_VALUE
}

/** Local chat history with rolling summarization to save tokens. */
object ChatRepo {
    private const val FILE = "chat_history.json"
    private const val KEEP_LAST = 10

    @Volatile
    private var summary = ""
    @Volatile
    private var messages = listOf<ChatMessage>()

    fun load(ctx: Context) = runCatching {
        val f = ctx.getFileStreamPath(FILE) ?: return@runCatching
        if (!f.exists()) return@runCatching
        ctx.openFileInput(FILE).bufferedReader().use { reader ->
            val o = JSONObject(reader.readText())
            summary = o.optString("summary")
            val arr = o.optJSONArray("messages")
            messages = (0 until (arr?.length() ?: 0)).map {
                val m = arr!!.getJSONObject(it)
                ChatMessage(m.getString("role"), m.getString("text"), m.optLong("at"))
            }
        }
    }

    @Synchronized
    fun save(ctx: Context) = runCatching {
        val arr = JSONArray()
        messages.forEach { m ->
            arr.put(JSONObject().put("role", m.role).put("text", m.text).put("at", m.at))
        }
        val o = JSONObject().put("summary", summary).put("messages", arr)
        ctx.openFileOutput(FILE, Context.MODE_PRIVATE).writer().use { it.write(o.toString()) }
    }

    fun history(): List<ChatMessage> = messages

    /** Compact context: summary line (when provider switches) + recent messages. */
    fun contextForPrompt(carrySummary: Boolean): List<ChatMessage> {
        val out = ArrayList<ChatMessage>()
        if (carrySummary && summary.isNotBlank()) {
            out += ChatMessage("system", "Summary of the conversation so far: $summary")
        }
        out += messages.takeLast(KEEP_LAST)
        return out
    }

    @Synchronized
    fun append(ctx: Context, user: String, assistant: String) {
        messages = messages + ChatMessage("user", user) + ChatMessage("assistant", assistant)
        if (messages.size > KEEP_LAST * 2) {
            // Lightweight local summarization: keep frequent keywords from older turns.
            val older = messages.dropLast(KEEP_LAST)
            val words = older.flatMap { it.text.lowercase().split(Regex("\\s+")) }
                .filter { it.length > 4 && it.all(Char::isLetter) }
            summary = (summary + " " + words.groupingBy { it }.eachCount()
                .entries.sortedByDescending { it.value }.take(12).joinToString(" ") { it.key })
                .trim().take(400)
            messages = messages.takeLast(KEEP_LAST)
        }
        save(ctx)
    }

    @Synchronized
    fun clear(ctx: Context) {
        summary = ""
        messages = emptyList()
        save(ctx)
    }
}

data class AiReply(
    val text: String,
    val providerId: String,
    val carriedContext: Boolean,
    val attempts: List<String>,
)

/**
 * Free tiers first, then paid API tiers; on quota/rate-limit/failure the next
 * provider is tried and the compact context is carried over transparently.
 */
class AiOrchestrator(private val ctx: Context) {
    private val providers = listOf(GeminiProvider(), OpenAiProvider(), ClaudeProvider())
    private val selectedModels = HashMap<String, String>()

    fun available(): List<AiProvider> = providers

    fun setModel(providerId: String, model: String) {
        selectedModels[providerId] = model
    }

    fun modelFor(p: AiProvider): String =
        selectedModels[p.id]?.takeIf { it in p.models } ?: p.models.first()

    suspend fun ask(prompt: String, filesContext: String? = null): AiReply {
        val full = prompt.trim()
        require(full.isNotEmpty())
        val budgetTokens = 3500
        val attempts = ArrayList<String>()
        var switched = false
        for (p in providers) {
            if (!p.hasKey(ctx)) continue
            if (p.freeTier && UsageStore.usedToday(ctx, p.id) >= p.freeDailyLimit) {
                attempts += "${p.label}: free quota ended"
                continue
            }
            val context = ChatRepo.contextForPrompt(carrySummary = switched)
            val messages = buildList {
                filesContext?.let { add(ChatMessage("system", it)) }
                addAll(context)
                add(ChatMessage("user", full))
            }
            val estimated = messages.sumOf { TokenCounter.count(it.text) }
            return try {
                val model = modelFor(p)
                val text = if (estimated <= budgetTokens) {
                    p.chat(ctx, model, messages)
                } else {
                    // Too big: ask the provider to compact, then send the compacted form.
                    val compact = p.chat(
                        ctx, model,
                        listOf(
                            ChatMessage(
                                "user",
                                "Summarize the following in at most 120 words, keeping all facts: " +
                                    context.joinToString("\n") { "${it.role}: ${it.text}" },
                            ),
                        ),
                    )
                    switched = true
                    p.chat(ctx, model, listOf(ChatMessage("user", "$compact\n\n$full")))
                }
                UsageStore.record(ctx, p.id)
                ChatRepo.append(ctx, full, text)
                AiReply(text, p.id, switched, attempts + "${p.label}: ok")
            } catch (e: AiError.QuotaExhausted) {
                attempts += "${p.label}: quota ended"
                UsageStore.record(ctx, p.id)
                switched = true
                continue
            } catch (e: AiError.RateLimited) {
                attempts += "${p.label}: rate limited"
                switched = true
                continue
            } catch (e: Exception) {
                attempts += "${p.label}: ${e.message ?: "failed"}"
                switched = true
                continue
            }
        }
        throw AiError.Http(-1, attempts.joinToString(" | ").ifEmpty { "no provider configured" })
    }
}
