package com.gallerysearch.app.data

/** Pure hash helpers — unit-testable. */
object Hashes {
    /** Hamming distance between two 64-bit perceptual hashes. */
    fun hamming(a: Long, b: Long): Int = java.lang.Long.bitCount(a xor b)

    /** Average hash (aHash) over an 8x8 grayscale plane (row-major, 64 values). */
    fun aHash(gray64: IntArray): Long? {
        if (gray64.size != 64) return null
        val avg = gray64.average()
        var bits = 0L
        for (i in 0 until 64) {
            if (gray64[i] >= avg) bits = bits or (1L shl (63 - i))
        }
        return bits
    }
}
