package com.gallerysearch.app.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.gallerysearch.app.MainActivity
import com.gallerysearch.app.R

/**
 * Universal home-screen widget (classic RemoteViews — works on every launcher
 * including HarmonyOS). Search bar + duplicates + cleanup shortcuts.
 */
class SearchWidgetReceiver : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { id -> manager.updateAppWidget(id, buildViews(context)) }
    }

    private fun buildViews(context: Context): RemoteViews {
        val views = RemoteViews(context.packageName, R.layout.widget_layout)
        views.setOnClickPendingIntent(R.id.widget_search_btn, pending(context, "home"))
        views.setOnClickPendingIntent(R.id.widget_dup_btn, pending(context, "clean"))
        views.setOnClickPendingIntent(R.id.widget_clean_btn, pending(context, "clean"))
        return views
    }

    private fun pending(context: Context, tab: String): PendingIntent {
        val intent = Intent(context, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .putExtra("tab", tab)
        return PendingIntent.getActivity(
            context,
            tab.hashCode(),
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
    }
}
