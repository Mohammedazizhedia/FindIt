package com.gallerysearch.app.widget

import android.content.Context
import android.content.Intent
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.Button
import androidx.glance.button.ButtonDefaults
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.action.actionStartActivity
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.width
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import com.gallerysearch.app.MainActivity
import com.gallerysearch.app.R

private fun tabIntent(ctx: Context, tab: String) =
    Intent(ctx, MainActivity::class.java)
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        .putExtra("tab", tab)

private val white = ColorProvider(android.graphics.Color.WHITE)

private val buttonColors = ButtonDefaults.buttonColors(
    backgroundColor = ColorProvider(androidx.compose.ui.graphics.Color(0xFF0B3B36)),
    contentColor = white,
)
private val widgetText = TextStyle(color = white)
private val widgetTextSmall = TextStyle(color = white, fontSize = 12.sp)

/**
 * One universal home-screen widget: a search bar that opens the app, plus
 * shortcuts to duplicates and cleanup.
 */
class UniversalWidget : GlanceAppWidget() {
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        provideContent {
            Column(
                GlanceModifier
                    .fillMaxSize()
                    .background(R.color.widget_bg)
                    .padding(10.dp),
                verticalAlignment = Alignment.Vertical.CenterVertically,
            ) {
                Button(
                    text = context.getString(R.string.widget_search_hint),
                    onClick = actionStartActivity(tabIntent(context, "home")),
                    modifier = GlanceModifier.fillMaxWidth(),
                    style = widgetText,
                    colors = buttonColors,
                )
                Spacer(GlanceModifier.height(6.dp))
                Row(modifier = GlanceModifier.fillMaxWidth()) {
                    Button(
                        text = context.getString(R.string.widget_dup_short),
                        onClick = actionStartActivity(tabIntent(context, "clean")),
                        modifier = GlanceModifier.defaultWeight(),
                        style = widgetTextSmall,
                        colors = buttonColors,
                    )
                    Spacer(GlanceModifier.width(6.dp))
                    Button(
                        text = context.getString(R.string.widget_clean_short),
                        onClick = actionStartActivity(tabIntent(context, "clean")),
                        modifier = GlanceModifier.defaultWeight(),
                        style = widgetTextSmall,
                        colors = buttonColors,
                    )
                }
            }
        }
    }
}

class SearchWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget = UniversalWidget()
}
