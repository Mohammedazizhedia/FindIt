package com.gallerysearch.app.ai

import android.content.Context
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest
import java.security.SecureRandom

/** Redirect codes delivered back to the app from the browser OAuth flow. */
object OAuthBus {
    val codes = MutableSharedFlow<String>(extraBufferCapacity = 2)
}

/**
 * Sign in with the user's OpenRouter account (browser-based OAuth PKCE — works
 * without Google services). The app receives an API key automatically; the user
 * never copies anything. Free ":free" models are available right after login.
 */
object OpenRouterOAuth {
    private const val CALLBACK = "findit://oauth"

    fun newVerifier(): String {
        val bytes = ByteArray(32)
        SecureRandom().nextBytes(bytes)
        return b64url(bytes)
    }

    fun authUrl(verifier: String): String {
        val challenge = b64url(sha256(verifier.toByteArray()))
        return "https://openrouter.ai/auth?callback_url=" +
            URLEncoder.encode(CALLBACK, "UTF-8") +
            "&code_challenge=$challenge&code_challenge_method=S256"
    }

    /** Exchanges the redirect code for an API key, or null on failure. */
    suspend fun exchange(code: String, verifier: String): String? = withContext(Dispatchers.IO) {
        runCatching {
            val conn = URL("https://openrouter.ai/api/v1/auth/keys").openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.connectTimeout = 30_000
            conn.readTimeout = 30_000
            conn.setRequestProperty("Content-Type", "application/json")
            val body = JSONObject()
                .put("code", code)
                .put("code_verifier", verifier)
                .put("code_challenge", b64url(sha256(verifier.toByteArray())))
                .put("callback_url", CALLBACK)
            conn.outputStream.use { it.write(body.toString().toByteArray()) }
            val res = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
            conn.disconnect()
            res.optString("key").takeIf { it.isNotBlank() }
        }.getOrNull()
    }

    private fun sha256(bytes: ByteArray): ByteArray =
        MessageDigest.getInstance("SHA-256").digest(bytes)

    private fun b64url(bytes: ByteArray): String =
        Base64.encodeToString(bytes, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
}
