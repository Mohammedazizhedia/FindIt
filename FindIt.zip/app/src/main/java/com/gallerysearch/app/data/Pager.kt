package com.gallerysearch.app.data

/** Paging math — pure and unit-testable. */
object Pager {
    const val DEFAULT_PAGE_SIZE = 120

    fun pageCount(total: Int, pageSize: Int): Int =
        if (total <= 0 || pageSize <= 0) 0 else (total + pageSize - 1) / pageSize

    fun <T> page(list: List<T>, pageIndex: Int, pageSize: Int): List<T> {
        if (pageSize <= 0 || pageIndex < 0) return emptyList()
        val from = pageIndex * pageSize
        if (from >= list.size) return emptyList()
        return list.subList(from, minOf(from + pageSize, list.size))
    }
}
