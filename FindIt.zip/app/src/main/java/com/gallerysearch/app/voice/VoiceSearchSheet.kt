package com.gallerysearch.app.voice

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.gallerysearch.app.R
import com.gallerysearch.app.ui.UiBus
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * Offline voice input. Primary: bundled Vosk (small AR/EN models, downloaded
 * once with progress). Fallback: the system SpeechRecognizer only when it is
 * actually available. Nothing fails silently — every case shows a message and a
 * Logcat entry (tag VoiceSearch). Live partial text, auto-stop on silence,
 * AR/EN toggle, mic-permission flow.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VoiceSearchSheet(
    initialQuery: String,
    onSearch: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val voskState by VoskEngine.state.collectAsStateWithLifecycle()

    var lang by remember {
        mutableStateOf(if (Locale.getDefault().language == "ar") "ar" else "en")
    }
    var heard by remember { mutableStateOf(initialQuery) }
    var listening by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<Int?>(null) }

    // Legacy system recognizer, created up-front and only used as a fallback.
    val legacyRecognizer = remember {
        if (SpeechRecognizer.isRecognitionAvailable(ctx)) {
            SpeechRecognizer.createSpeechRecognizer(ctx)
        } else {
            null
        }
    }
    DisposableEffect(Unit) {
        onDispose { legacyRecognizer?.destroy() }
    }

    fun runCommand(text: String) {
        when (val c = VoiceCommands.parse(text)) {
            is VoiceCommand.Search -> {
                if (c.query.isNotEmpty()) onSearch(c.query) else onDismiss()
            }
            else -> {
                UiBus.commands.tryEmit(c)
                onDismiss()
            }
        }
    }

    fun onFinalText(text: String?) {
        listening = false
        if (text.isNullOrBlank()) {
            error = R.string.voice_error_no_match
            Log.w(VoskEngine.TAG, "no speech recognized (lang=$lang)")
        } else {
            heard = text
            runCommand(text)
        }
    }

    fun startLegacy() {
        val rec = legacyRecognizer ?: run {
            error = R.string.voice_error_model
            Log.e(VoskEngine.TAG, "no recognizer service on this device")
            return
        }
        error = null
        heard = ""
        listening = true
        val localeLang = if (lang == "ar") "ar-EG" else "en-US"
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, localeLang)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        }
        rec.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) = Unit
            override fun onBeginningOfSpeech() = Unit
            override fun onRmsChanged(rmsdB: Float) = Unit
            override fun onBufferReceived(buffer: ByteArray?) = Unit
            override fun onEndOfSpeech() {
                listening = false
            }
            override fun onError(e: Int) {
                listening = false
                error = when (e) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                        R.string.voice_error_no_match
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                        R.string.voice_error_offline
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                        R.string.voice_error_permission
                    else -> R.string.voice_error_generic
                }
                Log.w(VoskEngine.TAG, "legacy recognizer error=$e")
            }
            override fun onResults(results: Bundle) {
                val matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                onFinalText(matches?.firstOrNull())
            }
            override fun onPartialResults(partial: Bundle) {
                val m = partial.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (!m.isNullOrEmpty()) heard = m.first()
            }
            override fun onEvent(eventType: Int, params: Bundle?) = Unit
        })
        rec.startListening(intent)
    }

    var permissionGranted by remember { mutableStateOf(false) }
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { granted ->
        if (granted) {
            permissionGranted = true
        } else {
            error = R.string.voice_error_permission
            Log.w(VoskEngine.TAG, "RECORD_AUDIO denied")
        }
    }

    fun startVoskOrLegacy() {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            return
        }
        error = null
        scope.launch {
            if (VoskEngine.ensure(ctx, lang)) {
                listening = true
                heard = ""
                onFinalText(VoskEngine.listen(lang) { partial -> heard = partial })
            } else if (legacyRecognizer != null) {
                Log.w(VoskEngine.TAG, "vosk unavailable, using system recognizer")
                startLegacy()
            } else {
                error = R.string.voice_error_model
                Log.e(VoskEngine.TAG, "no offline recognizer available")
            }
        }
    }



    // Resume listening right after the user grants the microphone permission.
    LaunchedEffect(permissionGranted) {
        if (permissionGranted) {
            permissionGranted = false
            startVoskOrLegacy()
        }
    }

    // Auto-download the selected model as soon as the sheet opens.
    DisposableEffect(lang) {
        scope.launch { VoskEngine.ensure(ctx, lang) }
        onDispose { }
    }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 24.dp).padding(bottom = 30.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(stringResource(R.string.voice), style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = lang == "ar",
                    onClick = { lang = "ar" },
                    label = { Text(stringResource(R.string.voice_lang_ar)) },
                )
                FilterChip(
                    selected = lang == "en",
                    onClick = { lang = "en" },
                    label = { Text(stringResource(R.string.voice_lang_en)) },
                )
            }
            Spacer(Modifier.height(12.dp))

            when (val st = voskState) {
                is VoskEngine.State.Downloading -> if (st.lang == lang) {
                    CircularProgressIndicator(progress = { st.percent / 100f })
                    Spacer(Modifier.height(8.dp))
                    Text(
                        stringResource(R.string.voice_downloading, st.percent),
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
                is VoskEngine.State.Extracting -> if (st.lang == lang) {
                    CircularProgressIndicator()
                    Spacer(Modifier.height(8.dp))
                    Text(
                        stringResource(R.string.voice_extracting),
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
                else -> Unit
            }
            if (voskState is VoskEngine.State.Missing || voskState is VoskEngine.State.Failed) {
                Text(
                    stringResource(R.string.voice_model_missing),
                    style = MaterialTheme.typography.bodyMedium,
                    textAlign = TextAlign.Center,
                )
            }

            Spacer(Modifier.height(8.dp))
            if (listening) Waveform()
            Text(
                heard.ifEmpty { stringResource(R.string.voice_listening) },
                style = MaterialTheme.typography.bodyLarge,
                textAlign = TextAlign.Center,
                color = if (listening) MaterialTheme.colorScheme.primary
                else MaterialTheme.colorScheme.onSurface,
            )
            error?.let {
                Spacer(Modifier.height(6.dp))
                Text(
                    stringResource(it),
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall,
                )
            }
            Spacer(Modifier.height(14.dp))
            Button(onClick = { if (!listening) startVoskOrLegacy() }, enabled = !listening) {
                Text(
                    stringResource(
                        when {
                            listening -> R.string.voice_listening
                            voskState is VoskEngine.State.Missing ||
                                voskState is VoskEngine.State.Failed -> R.string.voice_tap_download
                            else -> R.string.voice_start
                        },
                    ),
                )
            }
            if (heard.isNotEmpty() && !listening) {
                Spacer(Modifier.height(6.dp))
                TextButton(onClick = { runCommand(heard) }) {
                    Text(stringResource(R.string.voice_use_text))
                }
            }
        }
    }
}

/** Simple animated waveform while listening. */
@Composable
private fun Waveform() {
    val transition = rememberInfiniteTransition(label = "wave")
    Row(
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        repeat(5) { i ->
            val h by transition.animateFloat(
                initialValue = 0.25f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(tween(360 + i * 110), RepeatMode.Reverse),
                label = "bar$i",
            )
            Spacer(
                Modifier
                    .size(width = 6.dp, height = (26 * h).dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary),
            )
        }
    }
}
