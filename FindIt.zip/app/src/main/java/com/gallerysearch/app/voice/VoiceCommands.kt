package com.gallerysearch.app.voice

/** Result of parsing a voice utterance into an app command. */
sealed class VoiceCommand {
    data class Search(val query: String) : VoiceCommand()
    data object OpenDuplicates : VoiceCommand()
    data object OpenCorrupt : VoiceCommand()
    data object OpenSettings : VoiceCommand()
    data object OpenTrash : VoiceCommand()
    data object StartScan : VoiceCommand()
    data class SetTheme(val dark: Boolean) : VoiceCommand()
    data object Stop : VoiceCommand()
}

/**
 * Offline command parser (Arabic + Egyptian Arabic + English). Pure and
 * unit-testable. Anything that is not a command is treated as a search query.
 */
object VoiceCommands {
    private val searchPrefixes = listOf(
        "search for", "find", "look for", "show me", "search",
        "ابحث عن", "ابحث", "دوّر على", "دور على", "لاقي", "وريني", "ورّيني", "بجد", "جيبلي",
    )
    private val stopWords = listOf(
        "stop", "cancel", "never mind",
        "إلغاء", "بطل", "استنى", "وقف",
    )

    fun parse(utterance: String): VoiceCommand {
        val text = utterance.trim().lowercase()
        if (text.isEmpty()) return VoiceCommand.Search("")

        if (stopWords.any { text == it || text.startsWith("$it ") }) return VoiceCommand.Stop

        for (p in searchPrefixes) {
            if (text.startsWith(p)) {
                val q = text.removePrefix(p).trim().trimStart('ع', 'ل').trim()
                if (q.isNotEmpty()) return VoiceCommand.Search(q)
            }
        }

        return when {
            listOf("duplicate", "duplicates", "تكرار", "تكرارات", "مكرر", "مكررة", "مكررين")
                .any { it in text } -> VoiceCommand.OpenDuplicates
            listOf("corrupt", "damaged", "broken files", "تالف", "تالفة", "بايظ", "باظ")
                .any { it in text } -> VoiceCommand.OpenCorrupt
            listOf("trash", "recycle", "سلة", "زبالة")
                .any { it in text } -> VoiceCommand.OpenTrash
            listOf("setting", "settings", "إعدادات", "الاعدادات", "الإعدادات")
                .any { it in text } -> VoiceCommand.OpenSettings
            listOf("dark mode", "dark", "داكن", "الليل", "ليلي")
                .any { it in text } -> VoiceCommand.SetTheme(dark = true)
            listOf("light mode", "light", "فاتح", "النهار")
                .any { it in text } -> VoiceCommand.SetTheme(dark = false)
            listOf("scan", "clean", "cleanup", "نظف", "نضف", "امسح", "افحص", "نظفه")
                .any { it in text } -> VoiceCommand.StartScan
            else -> VoiceCommand.Search(text)
        }
    }
}
