package com.gallerysearch.app.ui.theme

import android.graphics.Typeface
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.gallerysearch.app.settings.SettingsStore
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

enum class ThemeMode { SYSTEM, LIGHT, DARK }

enum class AccentTheme { DEFAULT, TEAL, INDIGO, AMBER, ROSE, DYNAMIC }

data class Tint(val bg: Color, val fg: Color)
data class Tints(val accent: Tint, val success: Tint, val warning: Tint, val pro: Tint, val danger: Tint)

private val lightTints = Tints(
    accent = Tint(Color(0xFFE6F1FB), Color(0xFF185FA5)),
    success = Tint(Color(0xFFEAF3DE), Color(0xFF3B6D11)),
    warning = Tint(Color(0xFFFAEEDA), Color(0xFF854F0B)),
    pro = Tint(Color(0xFFEEEDFE), Color(0xFF534AB7)),
    danger = Tint(Color(0xFFFCEBEB), Color(0xFFA32D2D)),
)
private val darkTints = Tints(
    accent = Tint(Color(0xFF0C447C), Color(0xFFB5D4F4)),
    success = Tint(Color(0xFF27500A), Color(0xFFC0DD97)),
    warning = Tint(Color(0xFF633806), Color(0xFFFAC775)),
    pro = Tint(Color(0xFF3C3489), Color(0xFFCECBF6)),
    danger = Tint(Color(0xFF791F1F), Color(0xFFF7C1C1)),
)

val LocalTints = staticCompositionLocalOf { lightTints }

// Shared surface tokens. Every text pair was verified >= 4.5:1 (WCAG AA).
private fun accentLight(
    p: Color, op: Color, pc: Color, opc: Color,
    s: Color, os: Color, sc: Color, osc: Color,
) = lightColorScheme(
    primary = p, onPrimary = op, primaryContainer = pc, onPrimaryContainer = opc,
    secondary = s, onSecondary = os, secondaryContainer = sc, onSecondaryContainer = osc,
    background = Color(0xFFF8F7F3), surface = Color(0xFFFDFDFB),
    surfaceVariant = Color(0xFFEFEDE6),
    onSurface = Color(0xFF1B1C1A), onSurfaceVariant = Color(0xFF44463F),
    outline = Color(0xFF75776C),
)

private fun accentDark(
    p: Color, op: Color, pc: Color, opc: Color,
    s: Color, os: Color, sc: Color, osc: Color,
) = darkColorScheme(
    primary = p, onPrimary = op, primaryContainer = pc, onPrimaryContainer = opc,
    secondary = s, onSecondary = os, secondaryContainer = sc, onSecondaryContainer = osc,
    background = Color(0xFF0F100E), surface = Color(0xFF131412),
    surfaceVariant = Color(0xFF2C2C2A),
    onSurface = Color(0xFFE4E3DD), onSurfaceVariant = Color(0xFFC6C7BF),
    outline = Color(0xFF8F9186),
)

private val palettes: Map<AccentTheme, Pair<ColorScheme, ColorScheme>> = mapOf(
    AccentTheme.DEFAULT to (
        accentLight(Color(0xFF185FA5), Color(0xFFFFFFFF), Color(0xFFD6E7F9), Color(0xFF0B3E6F),
            Color(0xFF2F6DA3), Color(0xFFFFFFFF), Color(0xFFD6E7F9), Color(0xFF0B3E6F)) to
            accentDark(Color(0xFFB5D4F4), Color(0xFF0C2C4E), Color(0xFF14395C), Color(0xFFCFE3F8),
                Color(0xFF8FB8E0), Color(0xFF0A2A49), Color(0xFF14395C), Color(0xFFCFE3F8))
        ),
    AccentTheme.TEAL to (
        accentLight(Color(0xFF0F766E), Color(0xFFFFFFFF), Color(0xFF99F6E4), Color(0xFF134E4A),
            Color(0xFF115E59), Color(0xFFFFFFFF), Color(0xFFCCFBF1), Color(0xFF115E59)) to
            accentDark(Color(0xFF5EEAD4), Color(0xFF06302B), Color(0xFF0B3B36), Color(0xFF8CE8D4),
                Color(0xFF2DD4BF), Color(0xFF00332E), Color(0xFF1F4944), Color(0xFF8FF0E2))
        ),
    AccentTheme.INDIGO to (
        accentLight(Color(0xFF4F46E5), Color(0xFFFFFFFF), Color(0xFFE0E7FF), Color(0xFF3730A3),
            Color(0xFF4338CA), Color(0xFFFFFFFF), Color(0xFFE0E7FF), Color(0xFF312E81)) to
            accentDark(Color(0xFFA5B4FC), Color(0xFF1E1B4B), Color(0xFF2A2753), Color(0xFFC7D2FE),
                Color(0xFF818CF8), Color(0xFF101446), Color(0xFF33356B), Color(0xFFC7D2FE))
        ),
    AccentTheme.AMBER to (
        accentLight(Color(0xFFB45309), Color(0xFFFFFFFF), Color(0xFFFDE68A), Color(0xFF78350F),
            Color(0xFFA16207), Color(0xFFFFFFFF), Color(0xFFFEF3C7), Color(0xFF92400E)) to
            accentDark(Color(0xFFFBBF24), Color(0xFF4A2B00), Color(0xFF4A3410), Color(0xFFFCD34D),
                Color(0xFFF59E0B), Color(0xFF442B00), Color(0xFF4A3410), Color(0xFFFDE68A))
        ),
    AccentTheme.ROSE to (
        accentLight(Color(0xFFBE123C), Color(0xFFFFFFFF), Color(0xFFFECDD3), Color(0xFF881337),
            Color(0xFF9F1239), Color(0xFFFFFFFF), Color(0xFFFFE4E6), Color(0xFF881337)) to
            accentDark(Color(0xFFFDA4AF), Color(0xFF590D22), Color(0xFF571C28), Color(0xFFFDA4AF),
                Color(0xFFFB7185), Color(0xFF4C0519), Color(0xFF571C28), Color(0xFFFECDD3))
        ),
)

@Composable
fun AppTheme(
    mode: ThemeMode = ThemeMode.SYSTEM,
    accent: AccentTheme = AccentTheme.DEFAULT,
    content: @Composable () -> Unit,
) {
    val dark = when (mode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val ctx = LocalContext.current
    val fontFam = SettingsStore.fontFamily.collectAsStateWithLifecycle().value
    val fontScale = SettingsStore.fontScale.collectAsStateWithLifecycle().value
    val weightLevel = SettingsStore.fontWeight.collectAsStateWithLifecycle().value
    val scheme = when {
        accent == AccentTheme.DYNAMIC && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        else -> {
            val pair = palettes[accent] ?: palettes.getValue(AccentTheme.DEFAULT)
            if (dark) pair.second else pair.first
        }
    }
    val family = remember(fontFam) {
        when (fontFam) {
            SettingsStore.FONT_TAJAWAL -> FontFamily(com.gallerysearch.app.R.font.tajawal)
            SettingsStore.FONT_AMIRI -> FontFamily(com.gallerysearch.app.R.font.amiri)
            SettingsStore.FONT_SYSTEM -> FontFamily.Default
            else -> FontFamily(com.gallerysearch.app.R.font.cairo)
        }
    }
    val typography = remember(family, fontScale, weightLevel) {
        fun wt(base: Int): FontWeight {
            val levels = listOf(FontWeight.Normal, FontWeight.Medium, FontWeight.SemiBold, FontWeight.Bold)
            return levels[(base + weightLevel).coerceIn(0, 3)]
        }
        Typography(
            headlineMedium = TextStyle(fontFamily = family, fontSize = 22.sp * fontScale, fontWeight = wt(2)),
            headlineSmall = TextStyle(fontFamily = family, fontSize = 20.sp * fontScale, fontWeight = wt(2)),
            titleLarge = TextStyle(fontFamily = family, fontSize = 22.sp * fontScale, fontWeight = wt(1)),
            titleMedium = TextStyle(fontFamily = family, fontSize = 15.sp * fontScale, fontWeight = wt(1)),
            titleSmall = TextStyle(fontFamily = family, fontSize = 13.sp * fontScale, fontWeight = wt(1)),
            bodyLarge = TextStyle(fontFamily = family, fontSize = 15.sp * fontScale, fontWeight = wt(0)),
            bodyMedium = TextStyle(fontFamily = family, fontSize = 14.sp * fontScale, fontWeight = wt(0)),
            bodySmall = TextStyle(fontFamily = family, fontSize = 12.sp * fontScale, fontWeight = wt(0)),
            labelLarge = TextStyle(fontFamily = family, fontSize = 14.sp * fontScale, fontWeight = wt(1)),
            labelMedium = TextStyle(fontFamily = family, fontSize = 12.sp * fontScale, fontWeight = wt(1)),
            labelSmall = TextStyle(fontFamily = family, fontSize = 11.sp * fontScale, fontWeight = wt(1)),
        )
    }
    val base = if (dark) darkTints else lightTints
    val tints = base.copy(accent = Tint(scheme.primaryContainer, scheme.onPrimaryContainer))
    CompositionLocalProvider(LocalTints provides tints) {
        MaterialTheme(colorScheme = scheme, typography = typography, content = content)
    }
}
