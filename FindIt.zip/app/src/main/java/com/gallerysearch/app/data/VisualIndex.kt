package com.gallerysearch.app.data

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONObject

/**
 * On-device visual index: ML Kit labels per image + 64-bit perceptual hashes.
 * Persisted as JSON in app files so it survives restarts. Powers "search car"
 * (label match) and "find similar photos" (hash distance).
 */
object VisualIndex {
    private const val FILE = "visual_index.json"
    private const val SIMILAR_THRESHOLD = 12 // hamming bits out of 64

    @Volatile
    var labels: Map<String, List<String>> = emptyMap()
        private set

    @Volatile
    var hashes: Map<String, Long> = emptyMap()
        private set

    fun load(ctx: Context) = runCatching {
        val f = ctx.getFileStreamPath(FILE) ?: return@runCatching
        if (!f.exists()) return@runCatching
        ctx.openFileInput(FILE).bufferedReader().use { reader ->
            val root = JSONObject(reader.readText())
            labels = root.optJSONObject("labels")?.let { o ->
                o.keys().asSequence().associateWith { k ->
                    o.getJSONArray(k).let { a -> (0 until a.length()).map { a.getString(it) } }
                }
            } ?: emptyMap()
            hashes = root.optJSONObject("hashes")?.let { o ->
                o.keys().asSequence().associateWith { o.getLong(it) }
            } ?: emptyMap()
        }
    }

    @Synchronized
    fun save(ctx: Context) = runCatching {
        val root = JSONObject()
        val l = JSONObject()
        labels.forEach { (k, v) -> l.put(k, org.json.JSONArray(v)) }
        val h = JSONObject()
        hashes.forEach { (k, v) -> h.put(k, v) }
        root.put("labels", l).put("hashes", h)
        ctx.openFileOutput(FILE, Context.MODE_PRIVATE).writer().use { it.write(root.toString()) }
    }

    /** Labels for a media uri (lowercase), used by the search pipeline. */
    fun labelsFor(uri: Uri): List<String> = labels[uri.toString()].orEmpty()

    /** Uris whose labels contain every query token. */
    fun search(queryTokens: List<String>): Set<String> {
        if (queryTokens.isEmpty()) return emptySet()
        return labels.filter { (_, v) ->
            queryTokens.all { token -> v.any { it.contains(token, ignoreCase = true) } }
        }.keys
    }

    /** Visually similar uris for a given perceptual hash. */
    fun similarTo(hash: Long, limit: Int = 60): List<String> =
        hashes.entries
            .filter { Hashes.hamming(it.value, hash) <= SIMILAR_THRESHOLD }
            .sortedBy { Hashes.hamming(it.value, hash) }
            .take(limit)
            .map { it.key }

    // ---------------- indexing ----------------

    suspend fun labelImage(ctx: Context, m: MediaItem): List<String> = withContext(Dispatchers.IO) {
        runCatching {
            ctx.contentResolver.openInputStream(m.uri)?.use { input ->
                val bmp = BitmapFactory.decodeStream(input) ?: return@use null
                val image = InputImage.fromBitmap(bmp, 0)
                ImageLabeling.getClient(
                    ImageLabelerOptions.Builder().setConfidenceThreshold(0.55f).build(),
                ).process(image).await()
                    .map { it.text.lowercase() }
                    .also { bmp.recycle() }
            }
        }.getOrNull().orEmpty()
    }
}
