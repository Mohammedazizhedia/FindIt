package com.gallerysearch.app.data

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONObject

/**
 * On-device visual index: ML Kit labels per image + 64-bit perceptual hashes.
 * Persisted as JSON in app files so it survives restarts. Powers "search car"
 * (label match) and "find similar photos" (hash distance).
 */
object VisualIndex {
    private const val FILE = "visual_index.json"
    private const val SIMILAR_THRESHOLD = 12 // hamming bits out of 64

    @Volatile
    var labels: Map<String, List<String>> = emptyMap()
        private set

    @Volatile
    var hashes: Map<String, Long> = emptyMap()
        private set

    fun load(ctx: Context) = runCatching {
        val f = ctx.getFileStreamPath(FILE) ?: return@runCatching
        if (!f.exists()) return@runCatching
        ctx.openFileInput(FILE).bufferedReader().use { reader ->
            val root = JSONObject(reader.readText())
            labels = root.optJSONObject("labels")?.let { o ->
                o.keys().asSequence().associateWith { k ->
                    o.getJSONArray(k).let { a -> (0 until a.length()).map { a.getString(it) } }
                }
            } ?: emptyMap()
            hashes = root.optJSONObject("hashes")?.let { o ->
                o.keys().asSequence().associateWith { o.getLong(it) }
            } ?: emptyMap()
        }
    }

    @Synchronized
    fun save(ctx: Context) = runCatching {
        val root = JSONObject()
        val l = JSONObject()
        labels.forEach { (k, v) -> l.put(k, org.json.JSONArray(v)) }
        val h = JSONObject()
        hashes.forEach { (k, v) -> h.put(k, v) }
        root.put("labels", l).put("hashes", h)
        ctx.openFileOutput(FILE, Context.MODE_PRIVATE).writer().use { it.write(root.toString()) }
    }

    /** Labels for a media uri (lowercase), used by the search pipeline. */
    fun labelsFor(uri: Uri): List<String> = labels[uri.toString()].orEmpty()

    /** Uris whose labels contain every query token. */
    fun search(queryTokens: List<String>): Set<String> {
        if (queryTokens.isEmpty()) return emptySet()
        return labels.filter { (_, v) ->
            queryTokens.all { token -> v.any { it.contains(token, ignoreCase = true) } }
        }.keys
    }

    /**
     * Each group = alternatives for ONE typed word (Arabic word, English word,
     * related ML Kit labels). A uri matches when EVERY group has at least one
     * alternative among its labels.
     */
    fun searchGroups(groups: List<List<String>>): Set<String> {
        val usable = groups.filter { it.isNotEmpty() }
        if (usable.isEmpty()) return emptySet()
        return labels.filter { (_, v) ->
            usable.all { alts -> alts.any { alt -> v.any { it.contains(alt, ignoreCase = true) } } }
        }.keys
    }

    /** Visually similar uris for a given perceptual hash. */
    fun similarTo(hash: Long, limit: Int = 60): List<String> =
        hashes.entries
            .filter { Hashes.hamming(it.value, hash) <= SIMILAR_THRESHOLD }
            .sortedBy { Hashes.hamming(it.value, hash) }
            .take(limit)
            .map { it.key }

    @Synchronized
    fun addHash(uri: String, hash: Long) {
        val m = hashes as? java.util.concurrent.ConcurrentHashMap<String, Long>
            ?: java.util.concurrent.ConcurrentHashMap(hashes).also { hashes = it }
        m[uri] = hash
    }

    @Synchronized
    fun addLabels(uri: String, value: List<String>) {
        if (value.isEmpty()) return
        val m = labels as? java.util.concurrent.ConcurrentHashMap<String, List<String>>
            ?: java.util.concurrent.ConcurrentHashMap(labels).also { labels = it }
        m[uri] = value
    }

    // ---------------- indexing ----------------

    private val labeler by lazy {
        ImageLabeling.getClient(ImageLabelerOptions.Builder().setConfidenceThreshold(0.5f).build())
    }

    suspend fun labelImage(ctx: Context, m: MediaItem): List<String> = withContext(Dispatchers.IO) {
        runCatching {
            // Decode a downsampled copy (max ~1024 px) so big photos never cause OOM.
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(m.uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / sample > 1024 || bounds.outHeight / sample > 1024) sample *= 2
            val bmp = ctx.contentResolver.openInputStream(m.uri)?.use {
                BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
            } ?: return@runCatching emptyList<String>()
            val found = labeler.process(InputImage.fromBitmap(bmp, 0)).await()
                .map { it.text.lowercase() }
            bmp.recycle()
            found
        }.getOrNull().orEmpty()
    }
}
