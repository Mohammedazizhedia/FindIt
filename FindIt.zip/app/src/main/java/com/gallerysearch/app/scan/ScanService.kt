package com.gallerysearch.app.scan

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.gallerysearch.app.MainActivity
import com.gallerysearch.app.R
import com.gallerysearch.app.data.Analyzer
import com.gallerysearch.app.data.CorruptVerdict
import com.gallerysearch.app.data.CorruptionDetector
import com.gallerysearch.app.data.MediaItem
import com.gallerysearch.app.data.ContentIndex
import com.gallerysearch.app.data.MediaRepository
import com.gallerysearch.app.data.VisualIndex
import com.gallerysearch.app.data.ProgressBus
import com.gallerysearch.app.data.TaskProgress
import com.gallerysearch.app.data.TaskStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.security.MessageDigest

/**
 * Foreground service that runs library scans (corrupt check + duplicate hash) and
 * survives the app being closed. Controlled with [ACTION_START] / [ACTION_PAUSE] /
 * [ACTION_RESUME] / [ACTION_CANCEL]; reports through [ProgressBus] + a notification.
 */
class ScanService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null

    @Volatile
    private var paused = false

    @Volatile
    private var cancelled = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                startForegroundInternal()
                job?.cancel()
                cancelled = false
                paused = false
                job = scope.launch { runScan() }
            }
            ACTION_PAUSE -> if (job?.isActive == true) {
                paused = true
                publish(ProgressBus.progress.value.copy(status = TaskStatus.PAUSED))
            }
            ACTION_RESUME -> if (job?.isActive == true) {
                paused = false
                publish(ProgressBus.progress.value.copy(status = TaskStatus.RUNNING))
            }
            ACTION_CANCEL -> {
                cancelled = true
                job?.cancel()
                ProgressBus.reset()
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    /** Suspends while paused; returns false when the scan must abort. */
    private suspend fun awaitControl(): Boolean {
        while (paused && !cancelled) delay(300)
        return !cancelled
    }

    private suspend fun runScan() {
        val ctx = applicationContext
        val all = MediaRepository.load(ctx)
        val startedAt = System.currentTimeMillis()
        val corrupt = ArrayList<MediaItem>()
        var processed = 0
        var found = 0

        fun emit(stageRes: Int, current: String = "", total: Int = all.size) {
            publish(
                TaskProgress(
                    status = if (paused) TaskStatus.PAUSED else TaskStatus.RUNNING,
                    stageRes = stageRes,
                    processed = processed,
                    total = total,
                    currentName = current,
                    found = found,
                    startedAtMs = startedAt,
                ),
            )
        }

        // Stage 1: multi-method corruption check over every file. Only files
        // confirmed by several independent checks are flagged.
        emit(R.string.stage_scan_corrupt)
        for (m in all) {
            if (cancelled) return
            if (!awaitControl()) return
            val finding = CorruptionDetector.inspect(ctx, m)
            if (finding.verdict == CorruptVerdict.CORRUPT) {
                corrupt.add(m)
                found++
            }
            processed++
            if (processed % 10 == 0) emit(R.string.stage_scan_corrupt, m.name)
        }

        // Stage 1b: extract document content (text/PDF) for content search.
        val docs = all.filter { it.category == com.gallerysearch.app.data.Category.DOCUMENT }
        emit(R.string.stage_scan_content, total = all.size + docs.size)
        for (d in docs) {
            if (cancelled) return
            if (!awaitControl()) return
            ContentIndex.indexDocument(ctx, d)
            processed++
            if (processed % 5 == 0) emit(R.string.stage_scan_content, d.name, all.size + docs.size)
        }
        ContentIndex.save(ctx)

        // Stage 2: hash same-size candidates to confirm true duplicates.
        val badUris = corrupt.map { it.uri }.toSet()
        val groups = Analyzer.sameSizeGroups(all.filter { it.uri !in badUris })
        val dupGroups = ArrayList<List<MediaItem>>()
        val md = MessageDigest.getInstance("SHA-256")
        emit(R.string.stage_scan_dups, total = all.size + groups.size)
        var groupsDone = 0
        for (g in groups) {
            if (cancelled) return
            if (!awaitControl()) return
            if (g.size >= 2) {
                val hashed = g.map { m ->
                    m to runCatching {
                        ctx.contentResolver.openInputStream(m.uri)?.use { input ->
                            md.reset()
                            val buf = ByteArray(64 * 1024)
                            var r = input.read(buf)
                            while (r != -1) {
                                md.update(buf, 0, r)
                                r = input.read(buf)
                            }
                            md.digest().joinToString("") { "%02x".format(it) }
                        }
                    }.getOrNull()
                }
                val byHash = hashed.filter { it.second != null }.groupBy { it.second }
                byHash.values.firstOrNull { it.size > 1 }?.let { dups ->
                    dupGroups.add(dups.map { it.first })
                    found += dups.size - 1
                }
            }
            groupsDone++
            processed = all.size + groupsDone
            if (groupsDone % 3 == 0) emit(R.string.stage_scan_dups, g.first().name, all.size + groups.size)
        }

        // Stage 3: visually similar images (aHash) + on-device ML Kit labels,
        // plus OCR for images that look like documents.
        VisualIndex.load(ctx)
        ContentIndex.load(ctx)
        val images = all.filter { it.category == com.gallerysearch.app.data.Category.IMAGE }
        val buckets = HashMap<Long, MutableList<MediaItem>>()
        emit(R.string.stage_scan_similar, total = all.size + groups.size + images.size)
        var hashCount = 0
        for (im in images) {
            if (cancelled) return
            if (!awaitControl()) return
            val ph = Analyzer.perceptualHash(ctx, im)
            if (ph != null) {
                buckets.getOrPut(ph) { ArrayList() }.add(im)
                VisualIndex.addHash(im.uri.toString(), ph)
                hashCount++
            }
            // Label images to bound ML Kit cost on huge libraries; labels unlock
            // "search car" style visual queries.
            if (images.size <= 400 || hashCount % 4 == 0) {
                val lbl = VisualIndex.labelImage(ctx, im)
                if (lbl.isNotEmpty()) VisualIndex.addLabels(im.uri.toString(), lbl)
                if (lbl.any { it in setOf("document", "text", "receipt", "screenshot") }) {
                    ContentIndex.ocrImage(ctx, im)
                }
            }
            processed++
            if (processed % 10 == 0) emit(R.string.stage_scan_similar, im.name, all.size + groups.size + images.size)
        }
        VisualIndex.save(ctx)
        ContentIndex.save(ctx)
        val similarGroups = buckets.values.filter { it.size > 1 }
        found += similarGroups.sumOf { it.size - 1 }

        publish(
            TaskProgress(
                status = TaskStatus.DONE,
                stageRes = R.string.stage_done,
                processed = processed,
                total = processed,
                found = found,
                startedAtMs = startedAt,
                dupGroups = dupGroups.sortedByDescending { it.first().size * it.size },
                similarGroups = similarGroups.sortedByDescending { it.size },
                corrupt = corrupt,
            ),
        )
        stopSelf()
    }

    private fun publish(p: TaskProgress) {
        ProgressBus.progress.value = p
        notifyProgress(p)
    }

    // ---------------- notification ----------------

    private fun startForegroundInternal() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notif_channel_scan),
                NotificationManager.IMPORTANCE_LOW,
            )
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
        }
        val notif = buildNotification(ProgressBus.progress.value)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ServiceCompat.startForeground(
                this, NOTIF_ID, notif,
                if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC else 0,
            )
        } else {
            ServiceCompat.startForeground(this, NOTIF_ID, notif, 0)
        }
    }

    private fun openAppIntent(): PendingIntent = PendingIntent.getActivity(
        this, 0, Intent(this, MainActivity::class.java),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    private fun buildNotification(p: TaskProgress): android.app.Notification {
        val title = getString(if (p.stageRes != 0) p.stageRes else R.string.task_running)
        val text = getString(R.string.scan_progress, p.processed, p.total)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(title)
            .setContentText(text)
            .setProgress(100, p.percent, p.total <= 0)
            .setOngoing(p.status == TaskStatus.RUNNING || p.status == TaskStatus.PAUSED)
            .setContentIntent(openAppIntent())
            .setOnlyAlertOnce(true)
            .build()
    }

    private fun notifyProgress(p: TaskProgress) {
        runCatching {
            getSystemService(NotificationManager::class.java)?.notify(NOTIF_ID, buildNotification(p))
        }
    }

    companion object {
        const val ACTION_START = "com.gallerysearch.app.scan.START"
        const val ACTION_PAUSE = "com.gallerysearch.app.scan.PAUSE"
        const val ACTION_RESUME = "com.gallerysearch.app.scan.RESUME"
        const val ACTION_CANCEL = "com.gallerysearch.app.scan.CANCEL"
        private const val CHANNEL_ID = "scan"
        private const val NOTIF_ID = 42
    }
}
