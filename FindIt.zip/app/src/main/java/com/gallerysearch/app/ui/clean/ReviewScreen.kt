package com.gallerysearch.app.ui.clean

import android.text.format.Formatter
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.gallerysearch.app.GalleryViewModel
import com.gallerysearch.app.R
import com.gallerysearch.app.data.MediaItem
import com.gallerysearch.app.data.TrashEntry
import com.gallerysearch.app.ui.components.LineIcon
import com.gallerysearch.app.ui.components.LineIconView
import com.gallerysearch.app.ui.theme.LocalTints
import com.gallerysearch.app.ui.theme.Tint
import kotlinx.coroutines.launch

/**
 * Review screen for duplicates (exact + visually similar) and corrupt files.
 * Duplicates: tap a copy to mark it as the one to KEEP; the rest are offered
 * for trash. Nothing is deleted without a confirmation that shows how much of
 * the library will be affected.
 */
@Composable
fun ReviewScreen(vm: GalleryViewModel, duplicates: Boolean, onBack: () -> Unit) {
    val s by vm.scan.collectAsStateWithLifecycle()
    val library by vm.items.collectAsStateWithLifecycle()
    val busy by vm.busy.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    val tints = LocalTints.current
    val scope = rememberCoroutineScope()

    // Restore is now verified per file, so the batch can safely be larger.
    val maxPick = 50
    var chosen by remember { mutableStateOf<Set<String>>(emptySet()) } // corrupt mode, by uri
    val keepMap = rememberSaveable { mutableMapOf<String, String>() }  // group key -> kept uri
    var pending by remember { mutableStateOf<List<TrashEntry>?>(null) }
    var confirmList by remember { mutableStateOf<List<MediaItem>?>(null) }

    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult(),
    ) { res ->
        val p = pending
        if (p != null) {
            if (res.resultCode == android.app.Activity.RESULT_OK) {
                vm.commitTrash(p, p.map { android.net.Uri.parse(it.originalUri) }.toSet())
            } else {
                vm.discardTrash(p)
            }
            pending = null
        }
    }

    val groups = if (duplicates) s.dupGroups + s.similarGroups else emptyList()
    val corrupt = s.corrupt

    fun keptOf(g: List<MediaItem>): String = keepMap[g.first().uri.toString()] ?: g.first().uri.toString()
    val candidates: List<MediaItem> = if (duplicates) {
        groups.filter { it.size > 1 }
            .flatMap { g -> g.filter { it.uri.toString() != keptOf(g) } }
    } else {
        corrupt.filter { it.uri.toString() in chosen }
    }

    suspend fun trashAll(list: List<MediaItem>) {
        val entries = vm.prepareTrash(list) ?: return
        pending = entries
        launcher.launch(IntentSenderRequest.Builder(vm.deleteIntent(entries)).build())
    }

    // Keep map: default every group's first copy.
    LaunchedEffect(s.dupGroups, s.similarGroups) {
        groups.forEach { g -> keepMap.putIfAbsent(g.first().uri.toString(), g.first().uri.toString()) }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(horizontal = 6.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back))
            }
            Text(
                stringResource(if (duplicates) R.string.clean_dup else R.string.clean_corrupt),
                style = MaterialTheme.typography.titleLarge,
            )
        }
        Text(
            stringResource(if (duplicates) R.string.hint_dup else R.string.hint_corrupt),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp),
        )
        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            contentPadding = PaddingValues(14.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            if (duplicates) {
                groups.forEach { g ->
                    val keptUri = keptOf(g)
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        Text(
                            stringResource(R.string.group_label, g.size,
                                Formatter.formatShortFileSize(ctx, g.first().size)),
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    items(g, key = { it.uri.toString() }) { m ->
                        val isKept = m.uri.toString() == keptUri
                        CopyTile(
                            m, isKept = isKept,
                            badgeTint = if (isKept) tints.success else tints.danger,
                            onClick = { keepMap[g.first().uri.toString()] = m.uri.toString() },
                        )
                    }
                }
                if (groups.isEmpty()) {
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        Text(
                            stringResource(R.string.empty_review),
                            modifier = Modifier.fillMaxWidth().padding(24.dp),
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    }
                }
            } else {
                items(corrupt, key = { it.uri.toString() }) { m ->
                    val on = m.uri.toString() in chosen
                    CopyTile(
                        m, isKept = false,
                        badgeTint = tints.danger,
                        selected = on,
                        onClick = {
                            chosen = if (on) chosen - m.uri.toString()
                            else if (chosen.size < maxPick) chosen + m.uri.toString()
                            else chosen
                        },
                    )
                }
                if (corrupt.isNotEmpty()) {
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        TextButton(
                            onClick = {
                                chosen = corrupt.take(maxPick).map { it.uri.toString() }.toSet()
                            },
                            modifier = Modifier.fillMaxWidth(),
                        ) { Text(stringResource(R.string.select_all)) }
                    }
                }
            }
        }
        val list = candidates.take(maxPick)
        val sizeStr = Formatter.formatShortFileSize(ctx, list.sumOf { it.size })
        Button(
            onClick = { confirmList = list },
            enabled = list.isNotEmpty() && !busy,
            modifier = Modifier.fillMaxWidth().padding(14.dp),
        ) {
            Text(stringResource(R.string.trash_n, list.size, sizeStr))
        }
    }

    confirmList?.let { list ->
        val pct = if (library.isNotEmpty()) (list.size * 100 / library.size).coerceIn(0, 100) else 0
        val sizeStr = Formatter.formatShortFileSize(ctx, list.sumOf { it.size })
        AlertDialog(
            onDismissRequest = { confirmList = null },
            title = { Text(stringResource(R.string.confirm_trash_title, list.size)) },
            text = { Text(stringResource(R.string.confirm_trash_body, sizeStr, pct)) },
            confirmButton = {
                TextButton(onClick = {
                    val l = list
                    confirmList = null
                    scope.launch { trashAll(l) }
                }) { Text(stringResource(R.string.confirm_delete)) }
            },
            dismissButton = {
                TextButton(onClick = { confirmList = null }) { Text(stringResource(R.string.cancel)) }
            },
        )
    }

    if (busy) {
        // Preparing safe copies — keep the user informed and block re-taps.
        // (the Clean tab shows the same notice text)
    }
}

@Composable
private fun CopyTile(
    m: MediaItem,
    isKept: Boolean,
    badgeTint: Tint,
    selected: Boolean = false,
    onClick: () -> Unit,
) {
    Box(
        Modifier.fillMaxWidth().aspectRatio(1f)
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        if (m.category == com.gallerysearch.app.data.Category.IMAGE || m.isVideo) {
            AsyncImage(
                model = m.uri,
                contentDescription = m.name,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
        } else {
            Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surfaceVariant)) {
                LineIconView(
                    LineIcon.Broken,
                    MaterialTheme.colorScheme.onSurfaceVariant,
                    32.dp,
                    Modifier.align(Alignment.Center),
                )
            }
        }
        if (selected) {
            Box(
                Modifier.fillMaxSize().background(badgeTint.bg.copy(alpha = 0.65f)),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Outlined.Check, null, tint = badgeTint.fg) }
        }
        if (isKept) {
            Surface(
                color = badgeTint.bg,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.align(Alignment.TopStart).padding(4.dp),
            ) {
                Text(
                    stringResource(R.string.keep),
                    style = MaterialTheme.typography.labelSmall,
                    color = badgeTint.fg,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                )
            }
        }
    }
}
