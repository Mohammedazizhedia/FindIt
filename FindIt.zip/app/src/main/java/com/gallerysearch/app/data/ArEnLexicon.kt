package com.gallerysearch.app.data

/**
 * Offline Arabic -> English lexicon for visual/content search. CLIP-style
 * label indexes are English; this lets queries like "سيارة" match "car".
 */
object ArEnLexicon {
    private val rawDict = mapOf(
        "سيارة" to "car", "سيارات" to "car", "عربية" to "car", "عربيات" to "car", "موتوسيكل" to "motorcycle",
        "ناس" to "people", "شخص" to "person", "شخصيات" to "people", "ولاد" to "children", "بنات" to "children",
        "طفل" to "child", "اطفال" to "children", "رجل" to "man", "ست" to "woman", "رجال" to "men", "ستات" to "women",
        "قطة" to "cat", "قط" to "cat", "قطط" to "cat", "كلب" to "dog", "كلاب" to "dog",
        "عصفور" to "bird", "طيور" to "bird", "حيوان" to "animal", "حيوانات" to "animals",
        "اكل" to "food", "طعام" to "food", "ماكولات" to "food", "غدا" to "food", "عشا" to "food", "فطار" to "food",
        "شاشة" to "screenshot", "لقطة" to "screenshot", "سكرين" to "screenshot", "ديسكتوب" to "screenshot",
        "مستند" to "document", "مستندات" to "document", "ورقة" to "paper", "ورق" to "paper",
        "فاتورة" to "receipt", "فواتير" to "receipt", "عقد" to "document", "فاتوره" to "receipt",
        "بحر" to "beach", "شاطئ" to "beach", "طبيعة" to "nature", "شجر" to "tree", "جبل" to "mountain",
        "ليل" to "night", "نهار" to "day", "غروب" to "sunset", "شمس" to "sun", "سماء" to "sky",
        "مدرسة" to "school", "اجتماع" to "meeting", "شغل" to "work", "مكتب" to "office", "دوم" to "building",
        "قهوة" to "coffee", "قهوه" to "coffee", "شاي" to "tea", "عصير" to "juice",
        "زفاف" to "wedding", "فرح" to "wedding", "سفر" to "travel", "مطار" to "airport", "طيارة" to "airplane",
    )

    /** Arabic spelling variants collapse to one form: أ إ آ -> ا, ى -> ي, ة -> ه, no ال, no diacritics. */
    fun normalize(token: String): String {
        var t = token.trim().lowercase()
        t = t.replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا').replace('ى', 'ي').replace('ة', 'ه')
        t = t.replace(Regex("[\\u064B-\\u0652\\u0640]"), "")
        if (t.startsWith("ال") && t.length > 3) t = t.substring(2)
        return t
    }

    private val dict: Map<String, String> by lazy { rawDict.mapKeys { normalize(it.key) } }

    // The label model uses its own words; map a few common objects to related labels
    // so "car" also finds photos labeled "sports car", "taxi", etc.
    private val related = mapOf(
        "car" to listOf("sports car", "taxi", "motor vehicle", "land vehicle"),
        "motorcycle" to listOf("motorcycle", "motorbike", "scooter"),
        "people" to listOf("person", "crowd", "face", "smile"),
        "person" to listOf("people", "face", "smile"),
        "food" to listOf("dish", "cuisine", "meal", "fast food"),
        "animal" to listOf("pet", "dog", "cat", "bird", "mammal"),
        "animals" to listOf("pet", "dog", "cat", "bird", "mammal"),
    )

    fun toEnglish(token: String): String? = dict[normalize(token)] ?: dict[token]

    /** The typed word, its English translation, and a singular form. Used for text/content search. */
    fun variants(token: String): List<String> {
        val raw = token.trim().lowercase()
        if (raw.isEmpty()) return emptyList()
        val en = toEnglish(raw)
        val singular = if (raw.length > 3 && raw.endsWith("s")) raw.dropLast(1) else null
        return listOfNotNull(raw, en, singular).distinct()
    }

    /** [variants] plus related labels. Used for visual (photo label) search. */
    fun expand(token: String): List<String> {
        val base = variants(token)
        val key = toEnglish(token) ?: base.getOrNull(0).orEmpty()
        val extra = related[key].orEmpty() + (base.mapNotNull { related[it] }.flatten())
        return (base + extra).distinct()
    }
}
