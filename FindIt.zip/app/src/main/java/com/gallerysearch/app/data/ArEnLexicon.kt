package com.gallerysearch.app.data

/**
 * Offline Arabic -> English lexicon for visual/content search. CLIP-style
 * label indexes are English; this lets queries like "سيارة" match "car".
 */
object ArEnLexicon {
    private val dict = mapOf(
        "سيارة" to "car", "سيارات" to "car", "عربية" to "car", "عربيات" to "car", "موتوسيكل" to "motorcycle",
        "ناس" to "people", "شخص" to "person", "شخصيات" to "people", "ولاد" to "children", "بنات" to "children",
        "طفل" to "child", "اطفال" to "children", "رجل" to "man", "ست" to "woman", "رجال" to "men", "ستات" to "women",
        "قطة" to "cat", "قط" to "cat", "قطط" to "cat", "كلب" to "dog", "كلاب" to "dog",
        "عصفور" to "bird", "طيور" to "bird", "حيوان" to "animal", "حيوانات" to "animals",
        "اكل" to "food", "طعام" to "food", "ماكولات" to "food", "غدا" to "food", "عشا" to "food", "فطار" to "food",
        "شاشة" to "screenshot", "لقطة" to "screenshot", "سكرين" to "screenshot", "ديسكتوب" to "screenshot",
        "مستند" to "document", "مستندات" to "document", "ورقة" to "paper", "ورق" to "paper",
        "فاتورة" to "receipt", "فواتير" to "receipt", "عقد" to "document", "فاتوره" to "receipt",
        "بحر" to "beach", "شاطئ" to "beach", "طبيعة" to "nature", "شجر" to "tree", "جبل" to "mountain",
        "ليل" to "night", "نهار" to "day", "غروب" to "sunset", "شمس" to "sun", "سماء" to "sky",
        "مدرسة" to "school", "اجتماع" to "meeting", "شغل" to "work", "مكتب" to "office", "دوم" to "building",
        "قهوة" to "coffee", "قهوه" to "coffee", "شاي" to "tea", "عصير" to "juice",
        "زفاف" to "wedding", "فرح" to "wedding", "سفر" to "travel", "مطار" to "airport", "طيارة" to "airplane",
    )

    fun toEnglish(token: String): String? = dict[token]
}
