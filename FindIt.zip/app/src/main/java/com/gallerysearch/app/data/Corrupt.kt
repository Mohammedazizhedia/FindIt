package com.gallerysearch.app.data

import android.content.Context
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import com.gallerysearch.app.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

enum class CorruptVerdict { HEALTHY, SUSPICIOUS, CORRUPT }

data class CorruptFinding(
    val verdict: CorruptVerdict,
    val failedChecks: List<Int>, // string res ids of failed check names
    val totalChecks: Int,
)

/** Magic-byte signatures for common formats. Pure and unit-testable. */
object MagicBytes {
    private data class Sig(val ext: String, val bytes: List<Int>)

    private val signatures = listOf(
        Sig("jpg", listOf(0xFF, 0xD8, 0xFF)),
        Sig("jpeg", listOf(0xFF, 0xD8, 0xFF)),
        Sig("png", listOf(0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A)),
        Sig("pdf", "%PDF".map { it.code }),
        Sig("zip", listOf(0x50, 0x4B, 0x03, 0x04)),
        Sig("apk", listOf(0x50, 0x4B, 0x03, 0x04)),
        Sig("docx", listOf(0x50, 0x4B, 0x03, 0x04)),
        Sig("xlsx", listOf(0x50, 0x4B, 0x03, 0x04)),
        Sig("pptx", listOf(0x50, 0x4B, 0x03, 0x04)),
        Sig("mp3", listOf(0x49, 0x44, 0x33)), // ID3 tag
        Sig("gif", listOf(0x47, 0x49, 0x46, 0x38)), // "GIF8"
        Sig("webp", listOf(0x52, 0x49, 0x46, 0x46)), // "RIFF"
        Sig("bmp", listOf(0x42, 0x4D)), // "BM"
    )

    fun isKnown(ext: String): Boolean = signatures.any { it.ext.equals(ext, ignoreCase = true) }

    /**
     * True when [head] matches the signature for [ext].
     * Returns null when the extension has no known signature (check skipped).
     */
    fun matches(head: ByteArray, ext: String): Boolean? {
        val sig = signatures.firstOrNull { it.ext.equals(ext, ignoreCase = true) } ?: return null
        if (head.size < sig.bytes.size) return false
        sig.bytes.forEachIndexed { i, b ->
            if ((head[i].toInt() and 0xFF) != b) {
                // mp3 without an ID3 tag: accept an MPEG frame sync (0xFF 0xE*).
                if (sig.ext == "mp3" && i < 2 &&
                    (head[0].toInt() and 0xFF) == 0xFF &&
                    (head[1].toInt() and 0xE0) == 0xE0
                ) return true
                return false
            }
        }
        return true
    }
}

/**
 * Multi-method corruption confirmation. A file is flagged CORRUPT only when at
 * least two independent checks fail — a single failure means SUSPICIOUS and is
 * never offered for deletion.
 */
object CorruptionDetector {
    private const val MAX_SANE_SIZE = 4L * 1024 * 1024 * 1024 // 4GB sanity cap
    private const val VERIFY_HASH_LIMIT = 10L * 1024 * 1024

    suspend fun inspect(ctx: Context, m: MediaItem): CorruptFinding = withContext(Dispatchers.IO) {
        val failed = ArrayList<Int>()
        var checks = 0

        // 1) Size sanity.
        checks++
        if (m.size <= 0L || m.size > MAX_SANE_SIZE) failed += R.string.check_size

        // 2) Magic bytes (skipped for unknown formats).
        val head = ByteArray(16)
        val headLen = runCatching {
            ctx.contentResolver.openInputStream(m.uri)?.use { it.read(head, 0, 16) } ?: 0
        }.getOrDefault(0).coerceAtLeast(0)
        val magic = MagicBytes.matches(head.copyOf(headLen), m.extension)
        if (magic != null) {
            checks++
            if (headLen == 0 || !magic) failed += R.string.check_magic
        }

        // 3) Full read (catches truncated / unreadable files), capped at 20 MB
        // so big videos don't stall the scan.
        val fullRead = runCatching {
            ctx.contentResolver.openInputStream(m.uri)?.use { input ->
                val buf = ByteArray(64 * 1024)
                var r = input.read(buf)
                var total = 0L
                val cap = 20L * 1024 * 1024
                while (r != -1 && total < cap) {
                    total += r
                    r = input.read(buf)
                }
                true // readable within the cap
            } ?: false
        }.getOrDefault(false)
        checks++
        if (!fullRead) failed += R.string.check_read

        // 4) Decoder / metadata probe.
        val needsProbe = m.category == Category.IMAGE ||
            m.category == Category.VIDEO || m.category == Category.AUDIO
        if (needsProbe) {
            checks++
            val decoded = when (m.category) {
                Category.IMAGE -> probeImage(ctx, m)
                else -> probeMedia(ctx, m)
            }
            if (!decoded) failed += R.string.check_decode
        }

        val verdict = when {
            failed.size >= 2 -> CorruptVerdict.CORRUPT
            failed.isEmpty() -> CorruptVerdict.HEALTHY
            else -> CorruptVerdict.SUSPICIOUS
        }
        CorruptFinding(verdict, failed, checks)
    }

    private fun probeImage(ctx: Context, m: MediaItem): Boolean =
        runCatching {
            ctx.contentResolver.openInputStream(m.uri)?.use {
                BitmapFactory.decodeStream(it) != null
            } == true
        }.getOrDefault(false)

    private fun probeMedia(ctx: Context, m: MediaItem): Boolean = runCatching {
        val mmr = MediaMetadataRetriever()
        try {
            mmr.setDataSource(ctx, m.uri)
            mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION) != null
        } finally {
            mmr.release()
        }
    }.getOrDefault(false)
}
