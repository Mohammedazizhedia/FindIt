package com.gallerysearch.app.data

import android.content.ContentUris
import android.content.Context
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.security.MessageDigest
import java.util.Locale

/** Broad file categories used across search, home tiles and cleanup tools. */
enum class Category { IMAGE, VIDEO, AUDIO, DOCUMENT, ARCHIVE, APP, OTHER }

object MediaKind {
    fun classify(mime: String, name: String): Category = when {
        mime.startsWith("image/") -> Category.IMAGE
        mime.startsWith("video/") -> Category.VIDEO
        mime.startsWith("audio/") -> Category.AUDIO
        mime == "application/vnd.android.package-archive" || name.endsWith(".apk", true) -> Category.APP
        mime == "application/zip" || mime == "application/x-zip-compressed" ||
            mime == "application/x-rar-compressed" || mime == "application/vnd.rar" ||
            mime == "application/x-7z-compressed" || mime == "application/gzip" ||
            mime == "application/x-gzip" || mime == "application/x-tar" ||
            mime == "application/x-bzip2" || mime == "application/x-xz" -> Category.ARCHIVE
        mime == "application/pdf" || mime.startsWith("text/") ||
            mime.contains("word") || mime.contains("excel") || mime.contains("sheet") ||
            mime.contains("powerpoint") || mime.contains("presentation") ||
            mime == "application/rtf" || mime == "application/json" ||
            mime == "application/xml" || mime == "application/csv" ||
            (mime == "application/octet-stream" && hasDocExt(name)) -> Category.DOCUMENT
        else -> Category.OTHER
    }

    private fun hasDocExt(name: String): Boolean =
        listOf(".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".txt", ".csv", ".md", ".log")
            .any { name.endsWith(it, true) }
}

data class MediaItem(
    val id: Long,
    val uri: Uri,
    val isVideo: Boolean,
    val name: String,
    val size: Long,
    val dateAdded: Long,
    val mime: String = "",
    val relPath: String = "",
    val dateTaken: Long = 0L,
    val category: Category = Category.OTHER,
    val extension: String = "",
    val folder: String = "",
)

object MediaRepository {
    /**
     * Loads every media-backed file on shared storage: photos, videos, audio,
     * documents, archives, APKs and more. Runs on the IO dispatcher, streams rows
     * from the cursor, and never touches the main thread.
     */
    suspend fun load(ctx: Context): List<MediaItem> = withContext(Dispatchers.IO) {
        val out = ArrayList<MediaItem>(8192)
        val projection = arrayOf(
            MediaStore.MediaColumns._ID,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.DATE_ADDED,
            MediaStore.MediaColumns.MIME_TYPE,
            MediaStore.MediaColumns.RELATIVE_PATH,
        )
        val base = MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL)
        runCatching {
            ctx.contentResolver.query(
                base, projection, null, null,
                "${MediaStore.MediaColumns.DATE_ADDED} DESC",
            )?.use { c ->
                val iId = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val iName = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                val iSize = c.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
                val iDate = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED)
                val iMime = c.getColumnIndexOrThrow(MediaStore.MediaColumns.MIME_TYPE)
                val iRel = c.getColumnIndexOrThrow(MediaStore.MediaColumns.RELATIVE_PATH)
                while (c.moveToNext()) {
                    val name = c.getString(iName) ?: continue
                    val mime = c.getString(iMime) ?: ""
                    val rel = c.getString(iRel) ?: ""
                    val category = MediaKind.classify(mime, name)
                    val id = c.getLong(iId)
                    out += MediaItem(
                        id = id,
                        uri = ContentUris.withAppendedId(base, id),
                        isVideo = category == Category.VIDEO,
                        name = name,
                        size = c.getLong(iSize),
                        dateAdded = c.getLong(iDate),
                        mime = mime,
                        relPath = rel,
                        category = category,
                        extension = name.substringAfterLast('.', "").lowercase(Locale.ROOT),
                        folder = rel.trimEnd('/').substringAfterLast('/'),
                    )
                }
            }
        }

        // On API 33+ the Files collection hides non-media files; the Downloads
        // collection exposes documents/archives saved in Download/.
        val seen = out.map { it.uri }.toHashSet()
        if (android.os.Build.VERSION.SDK_INT >= 29) runCatching {
            val dl = MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL)
            ctx.contentResolver.query(
                dl, projection, null, null,
                "${MediaStore.MediaColumns.DATE_ADDED} DESC",
            )?.use { c ->
                val iId = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val iName = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                val iSize = c.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
                val iDate = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED)
                val iMime = c.getColumnIndexOrThrow(MediaStore.MediaColumns.MIME_TYPE)
                val iRel = c.getColumnIndexOrThrow(MediaStore.MediaColumns.RELATIVE_PATH)
                while (c.moveToNext()) {
                    val name = c.getString(iName) ?: continue
                    val mime = c.getString(iMime) ?: ""
                    val rel = c.getString(iRel) ?: ""
                    val category = MediaKind.classify(mime, name)
                    val id = c.getLong(iId)
                    val uri = ContentUris.withAppendedId(dl, id)
                    if (uri in seen) continue
                    seen.add(uri)
                    out += MediaItem(
                        id = id,
                        uri = uri,
                        isVideo = category == Category.VIDEO,
                        name = name,
                        size = c.getLong(iSize),
                        dateAdded = c.getLong(iDate),
                        mime = mime,
                        relPath = rel,
                        category = category,
                        extension = name.substringAfterLast('.', "").lowercase(Locale.ROOT),
                        folder = rel.trimEnd('/').substringAfterLast('/'),
                    )
                }
            }
        }
        // User-granted folders (SAF document trees): archives, docs, anything.
        for (tree in com.gallerysearch.app.settings.SettingsStore.safFolders.value) {
            runCatching {
                val treeUri = Uri.parse(tree)
                val rootId = DocumentsContract.getTreeDocumentId(treeUri)
                val rootChildren = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, rootId)
                walkTree(ctx, rootChildren, tree, 0, seen, out)
            }
        }
        out
    }

    private fun walkTree(
        ctx: Context,
        nodeUri: Uri,
        tree: String,
        depth: Int,
        seen: MutableSet<Uri>,
        out: MutableList<MediaItem>,
    ) {
        if (depth > 3) return
        val cols = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_SIZE,
            DocumentsContract.Document.COLUMN_LAST_MODIFIED,
        )
        runCatching {
            ctx.contentResolver.query(nodeUri, cols, null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getString(0) ?: continue
                    val name = c.getString(1) ?: continue
                    val mime = c.getString(2) ?: ""
                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                        walkTree(
                            ctx,
                            DocumentsContract.buildChildDocumentsUriUsingTree(Uri.parse(tree), id),
                            tree, depth + 1, seen, out,
                        )
                    } else {
                        val docUri = DocumentsContract.buildDocumentUriUsingTree(Uri.parse(tree), id)
                        if (docUri in seen) continue
                        seen.add(docUri)
                        val category = MediaKind.classify(mime, name)
                        out += MediaItem(
                            id = id.hashCode().toLong(),
                            uri = docUri,
                            isVideo = category == Category.VIDEO,
                            name = name,
                            size = c.getLong(3),
                            dateAdded = c.getLong(4) / 1000,
                            mime = mime,
                            relPath = "",
                            category = category,
                            extension = name.substringAfterLast('.', "").lowercase(Locale.ROOT),
                            folder = "Files",
                        )
                    }
                }
            }
        }
    }
}

object Analyzer {
    suspend fun isCorrupt(ctx: Context, m: MediaItem): Boolean = withContext(Dispatchers.IO) {
        try {
            when {
                m.isVideo -> {
                    val mmr = MediaMetadataRetriever()
                    try {
                        mmr.setDataSource(ctx, m.uri)
                        mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION) == null
                    } finally {
                        mmr.release()
                    }
                }
                m.name.substringAfterLast('.', "bin").lowercase(Locale.ROOT) in
                    setOf("jpg", "jpeg", "png", "webp", "heic", "heif", "gif", "bmp") -> {
                    ctx.contentResolver.openInputStream(m.uri)?.use { input ->
                        BitmapFactory.decodeStream(input) == null
                    } ?: true
                }
                else -> false
            }
        } catch (_: Exception) {
            false
        }
    }

    fun sameSizeGroups(items: List<MediaItem>): List<List<MediaItem>> =
        items.filter { it.size > 0 }.groupBy { it.size }.values.filter { it.size > 1 }

    suspend fun findDuplicates(
        ctx: Context,
        groups: List<List<MediaItem>>,
        onProgress: suspend (Int) -> Unit = {},
    ): List<List<MediaItem>> = withContext(Dispatchers.IO) {
        val md = MessageDigest.getInstance("SHA-256")
        groups.mapNotNull { same ->
            if (same.size < 2) return@mapNotNull null
            val hashed = same.map { m ->
                m to runCatching {
                    ctx.contentResolver.openInputStream(m.uri)?.use { input ->
                        md.reset()
                        val buf = ByteArray(64 * 1024)
                        var read = input.read(buf)
                        while (read != -1) {
                            md.update(buf, 0, read)
                            read = input.read(buf)
                        }
                        md.digest().joinToString("") { "%02x".format(it) }
                    }
                }.getOrNull()
            }
            onProgress(same.size)
            val byHash = hashed.filter { it.second != null }.groupBy { it.second }
            byHash.values.firstOrNull { it.size > 1 }?.map { it.first }
        }
    }

    /** 64-bit average perceptual hash (aHash) of an image, or null when undecodable. */
    suspend fun perceptualHash(ctx: Context, m: MediaItem): Long? = withContext(Dispatchers.IO) {
        runCatching {
            ctx.contentResolver.openInputStream(m.uri)?.use { input ->
                val opts = BitmapFactory.Options().apply { inSampleSize = 16 }
                val src = BitmapFactory.decodeStream(input, null, opts) ?: return@runCatching null
                val bmp = android.graphics.Bitmap.createScaledBitmap(src, 8, 8, true)
                val gray = IntArray(64)
                for (y in 0 until 8) {
                    for (x in 0 until 8) {
                        val px = bmp.getPixel(x, y)
                        gray[y * 8 + x] = ((android.graphics.Color.red(px) * 299 +
                            android.graphics.Color.green(px) * 587 +
                            android.graphics.Color.blue(px) * 114) / 1000)
                    }
                }
                src.recycle()
                bmp.recycle()
                Hashes.aHash(gray)
            }
        }.getOrNull()
    }
}