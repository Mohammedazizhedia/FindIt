package com.gallerysearch.app.settings

import android.content.Context
import android.content.SharedPreferences
import androidx.core.content.edit
import com.gallerysearch.app.ui.theme.AccentTheme
import com.gallerysearch.app.ui.theme.ThemeMode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * App preferences backed by SharedPreferences and exposed as StateFlows so the UI
 * reacts instantly. Initialized once from [com.gallerysearch.app.GalleryApp].
 */
object SettingsStore {
    const val LANG_AUTO = ""
    const val LANG_AR = "ar"
    const val LANG_EN = "en"

    private const val PREFS = "app_settings"
    private const val KEY_THEME = "theme_mode"
    private const val KEY_ACCENT = "accent"
    private const val KEY_LANG = "language"
    private const val KEY_TRASH_DAYS = "trash_retention_days"
    private const val KEY_PREMIUM = "is_premium"
    private const val KEY_AI_PRIVACY = "ai_privacy_accepted"

    private lateinit var prefs: SharedPreferences

    private val _themeMode = MutableStateFlow(ThemeMode.SYSTEM)
    private val _accent = MutableStateFlow(AccentTheme.DEFAULT)
    private val _language = MutableStateFlow(LANG_AUTO)
    private val _trashRetentionDays = MutableStateFlow(30)
    private val _isPremium = MutableStateFlow(false)
    private val _aiPrivacyAccepted = MutableStateFlow(false)

    val themeMode: StateFlow<ThemeMode> = _themeMode.asStateFlow()
    val accent: StateFlow<AccentTheme> = _accent.asStateFlow()
    val language: StateFlow<String> = _language.asStateFlow()
    val trashRetentionDays: StateFlow<Int> = _trashRetentionDays.asStateFlow()
    val isPremium: StateFlow<Boolean> = _isPremium.asStateFlow()
    val aiPrivacyAccepted: StateFlow<Boolean> = _aiPrivacyAccepted.asStateFlow()

    @Synchronized
    fun init(context: Context) {
        val p = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs = p
        _themeMode.value = p.getString(KEY_THEME, null)
            ?.let { runCatching { ThemeMode.valueOf(it) }.getOrNull() } ?: ThemeMode.SYSTEM
        _accent.value = p.getString(KEY_ACCENT, null)
            ?.let { runCatching { AccentTheme.valueOf(it) }.getOrNull() } ?: AccentTheme.DEFAULT
        _language.value = p.getString(KEY_LANG, LANG_AUTO) ?: LANG_AUTO
        _trashRetentionDays.value = p.getInt(KEY_TRASH_DAYS, 30)
        _isPremium.value = p.getBoolean(KEY_PREMIUM, false)
        _aiPrivacyAccepted.value = p.getBoolean(KEY_AI_PRIVACY, false)
    }

    fun setThemeMode(mode: ThemeMode) {
        _themeMode.value = mode
        prefs.edit { putString(KEY_THEME, mode.name) }
    }

    fun setAccent(value: AccentTheme) {
        _accent.value = value
        prefs.edit { putString(KEY_ACCENT, value.name) }
    }

    fun setLanguage(lang: String) {
        if (lang !in setOf(LANG_AUTO, LANG_AR, LANG_EN)) return
        _language.value = lang
        prefs.edit { putString(KEY_LANG, lang) }
    }

    fun setPremium(value: Boolean) {
        _isPremium.value = value
        prefs.edit { putBoolean(KEY_PREMIUM, value) }
    }

    fun setAiPrivacyAccepted(value: Boolean) {
        _aiPrivacyAccepted.value = value
        prefs.edit { putBoolean(KEY_AI_PRIVACY, value) }
    }

    fun setTrashRetentionDays(days: Int) {
        val d = days.coerceIn(1, 365)
        _trashRetentionDays.value = d
        prefs.edit { putInt(KEY_TRASH_DAYS, d) }
    }

    /** Synchronous read for non-Compose paths (e.g. Activity.attachBaseContext). */
    @Synchronized
    fun persistedLanguage(context: Context): String {
        if (!::prefs.isInitialized) init(context)
        return prefs.getString(KEY_LANG, LANG_AUTO) ?: LANG_AUTO
    }
}
