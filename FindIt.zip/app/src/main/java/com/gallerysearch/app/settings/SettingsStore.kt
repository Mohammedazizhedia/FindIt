package com.gallerysearch.app.settings

import android.content.Context
import android.content.SharedPreferences
import androidx.core.content.edit
import com.gallerysearch.app.ui.theme.AccentTheme
import com.gallerysearch.app.ui.theme.ThemeMode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * App preferences backed by SharedPreferences and exposed as StateFlows so the UI
 * reacts instantly. Initialized once from [com.gallerysearch.app.GalleryApp].
 */
object SettingsStore {
    const val LANG_AUTO = ""
    const val LANG_AR = "ar"
    const val LANG_EN = "en"

    private const val PREFS = "app_settings"
    private const val KEY_THEME = "theme_mode"
    private const val KEY_ACCENT = "accent"
    private const val KEY_LANG = "language"
    private const val KEY_TRASH_DAYS = "trash_retention_days"
    private const val KEY_PREMIUM = "is_premium"
    private const val KEY_AI_PRIVACY = "ai_privacy_accepted"
    private const val KEY_FONT_FAMILY = "font_family"
    private const val KEY_FONT_SCALE = "font_scale"
    private const val KEY_FONT_WEIGHT = "font_weight"

    const val FONT_CAIRO = 0
    const val FONT_TAJAWAL = 1
    const val FONT_AMIRI = 2
    const val FONT_SYSTEM = 3

    private lateinit var prefs: SharedPreferences

    private val _themeMode = MutableStateFlow(ThemeMode.SYSTEM)
    private val _accent = MutableStateFlow(AccentTheme.DEFAULT)
    private val _language = MutableStateFlow(LANG_AUTO)
    private val _trashRetentionDays = MutableStateFlow(30)
    private val _isPremium = MutableStateFlow(false)
    private val _aiPrivacyAccepted = MutableStateFlow(false)
    private val _fontFamily = MutableStateFlow(FONT_CAIRO)
    private val _fontScale = MutableStateFlow(1.0f)
    private val _fontWeight = MutableStateFlow(1)

    val themeMode: StateFlow<ThemeMode> = _themeMode.asStateFlow()
    val accent: StateFlow<AccentTheme> = _accent.asStateFlow()
    val language: StateFlow<String> = _language.asStateFlow()
    val trashRetentionDays: StateFlow<Int> = _trashRetentionDays.asStateFlow()
    val isPremium: StateFlow<Boolean> = _isPremium.asStateFlow()
    val aiPrivacyAccepted: StateFlow<Boolean> = _aiPrivacyAccepted.asStateFlow()
    val fontFamily: StateFlow<Int> = _fontFamily.asStateFlow()
    val fontScale: StateFlow<Float> = _fontScale.asStateFlow()
    val fontWeight: StateFlow<Int> = _fontWeight.asStateFlow()

    @Synchronized
    fun init(context: Context) {
        val p = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs = p
        _themeMode.value = p.getString(KEY_THEME, null)
            ?.let { runCatching { ThemeMode.valueOf(it) }.getOrNull() } ?: ThemeMode.SYSTEM
        _accent.value = p.getString(KEY_ACCENT, null)
            ?.let { runCatching { AccentTheme.valueOf(it) }.getOrNull() } ?: AccentTheme.DEFAULT
        _language.value = p.getString(KEY_LANG, LANG_AUTO) ?: LANG_AUTO
        _trashRetentionDays.value = p.getInt(KEY_TRASH_DAYS, 30)
        _isPremium.value = p.getBoolean(KEY_PREMIUM, false)
        _aiPrivacyAccepted.value = p.getBoolean(KEY_AI_PRIVACY, false)
        _fontFamily.value = p.getInt(KEY_FONT_FAMILY, FONT_CAIRO)
        _fontScale.value = p.getFloat(KEY_FONT_SCALE, 1.0f)
        _fontWeight.value = p.getInt(KEY_FONT_WEIGHT, 1)
    }

    fun setThemeMode(mode: ThemeMode) {
        _themeMode.value = mode
        prefs.edit { putString(KEY_THEME, mode.name) }
    }

    fun setAccent(value: AccentTheme) {
        _accent.value = value
        prefs.edit { putString(KEY_ACCENT, value.name) }
    }

    fun setLanguage(lang: String) {
        if (lang !in setOf(LANG_AUTO, LANG_AR, LANG_EN)) return
        _language.value = lang
        prefs.edit { putString(KEY_LANG, lang) }
    }

    fun setPremium(value: Boolean) {
        _isPremium.value = value
        prefs.edit { putBoolean(KEY_PREMIUM, value) }
    }

    fun setFontFamily(value: Int) {
        val v = value.coerceIn(FONT_CAIRO, FONT_SYSTEM)
        _fontFamily.value = v
        prefs.edit { putInt(KEY_FONT_FAMILY, v) }
    }

    fun setFontScale(value: Float) {
        val v = value.coerceIn(0.85f, 1.3f)
        _fontScale.value = v
        prefs.edit { putFloat(KEY_FONT_SCALE, v) }
    }

    fun setFontWeightLevel(value: Int) {
        val v = value.coerceIn(0, 2)
        _fontWeight.value = v
        prefs.edit { putInt(KEY_FONT_WEIGHT, v) }
    }

    fun setAiPrivacyAccepted(value: Boolean) {
        _aiPrivacyAccepted.value = value
        prefs.edit { putBoolean(KEY_AI_PRIVACY, value) }
    }

    fun setTrashRetentionDays(days: Int) {
        val d = days.coerceIn(1, 365)
        _trashRetentionDays.value = d
        prefs.edit { putInt(KEY_TRASH_DAYS, d) }
    }

    /** Synchronous read for non-Compose paths (e.g. Activity.attachBaseContext). */
    @Synchronized
    fun persistedLanguage(context: Context): String {
        if (!::prefs.isInitialized) init(context)
        return prefs.getString(KEY_LANG, LANG_AUTO) ?: LANG_AUTO
    }
}
