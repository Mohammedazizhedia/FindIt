package com.gallerysearch.app.ui.ai

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import android.content.Intent
import android.net.Uri
import com.gallerysearch.app.GalleryViewModel
import com.gallerysearch.app.R
import com.gallerysearch.app.ai.AiOrchestrator
import com.gallerysearch.app.ai.ChatMessage
import com.gallerysearch.app.ai.ChatRepo
import com.gallerysearch.app.ai.KeystoreVault
import com.gallerysearch.app.ai.UsageStore
import com.gallerysearch.app.settings.SettingsStore
import com.gallerysearch.app.voice.VoiceCommands
import kotlinx.coroutines.launch

/**
 * Online AI chat. Everything before the network call is local; a clear privacy
 * notice is shown once before anything leaves the device. Providers are picked
 * automatically (free first) with transparent fallback.
 */
@Composable
fun AiScreen(vm: GalleryViewModel) {
    val ctx = LocalContext.current
    val privacyAccepted by SettingsStore.aiPrivacyAccepted.collectAsStateWithLifecycle()
    val premium by SettingsStore.isPremium.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    val orch = remember { AiOrchestrator(ctx) }

    var input by remember { mutableStateOf("") }
    var history by remember { mutableStateOf(ChatRepo.history()) }
    var thinking by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }
    var showKeyDialog by remember { mutableStateOf(false) }
    var showModelMenu by remember { mutableStateOf(false) }
    var showHelp by remember { mutableStateOf(false) }
    var attachFiles by remember { mutableStateOf(false) }
    var keyProvider by remember { mutableStateOf("") }
    var keyText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(Unit) {
        ChatRepo.load(ctx)
        UsageStore.load(ctx)
        history = ChatRepo.history()
    }
    LaunchedEffect(history.size) {
        if (history.isNotEmpty()) listState.animateScrollToItem(history.size - 1)
    }

    fun send(text: String) {
        val t = text.trim()
        if (t.isEmpty() || thinking) return
        thinking = true
        status = null
        scope.launch {
            try {
                val reply = orch.ask(t, if (attachFiles) buildFilesSummary(vm) else null)
                history = ChatRepo.history()
                status = ctx.getString(R.string.ai_via, reply.providerId) +
                    if (reply.carriedContext) " · " + ctx.getString(R.string.ai_context_carried) else ""
            } catch (e: Exception) {
                status = e.message ?: ctx.getString(R.string.ai_error)
            } finally {
                thinking = false
            }
        }
    }

    if (!privacyAccepted) {
        AlertDialog(
            onDismissRequest = { },
            title = { Text(stringResource(R.string.ai_privacy_title)) },
            text = { Text(stringResource(R.string.ai_privacy_body)) },
            confirmButton = {
                TextButton(onClick = { SettingsStore.setAiPrivacyAccepted(true) }) {
                    Text(stringResource(R.string.ai_privacy_accept))
                }
            },
            dismissButton = {
                TextButton(onClick = { SettingsStore.setAiPrivacyAccepted(false) }) {
                    Text(stringResource(R.string.cancel))
                }
            },
        )
        return
    }

    Column(Modifier.fillMaxSize().padding(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                stringResource(if (premium) R.string.ai_premium_on else R.string.ai_free_mode),
                style = MaterialTheme.typography.titleMedium,
                color = if (premium) MaterialTheme.colorScheme.primary
                else MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.weight(1f))
            TextButton(onClick = {
                ChatRepo.clear(ctx)
                history = emptyList()
            }) { Text(stringResource(R.string.ai_clear)) }
        }
        // Provider keys
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            orch.available().forEach { p ->
                val has = p.hasKey(ctx)
                val remaining = if (p.freeTier) {
                    UsageStore.remaining(p, UsageStore.usedToday(ctx, p.id))
                } else Int.MAX_VALUE
                FilledTonalButton(onClick = {
                    keyProvider = p.id
                    keyText = KeystoreVault.get(ctx, p.id) ?: ""
                    showKeyDialog = true
                }) {
                    Text(
                        p.label +
                            if (p.freeTier) " ($remaining)" else if (!has) " 🔑" else "",
                        style = MaterialTheme.typography.labelSmall,
                    )
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { attachFiles = !attachFiles }) {
                Text(
                    stringResource(R.string.ai_attach) + if (attachFiles) " ✓" else "",
                    color = if (attachFiles) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            if (orch.available().none { it.hasKey(ctx) }) {
                TextButton(onClick = {
                    runCatching {
                        ctx.startActivity(
                            Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com")),
                        )
                    }
                }) { Text(stringResource(R.string.ai_get_key)) }
            }
        }
        // Model picker for the first provider that has a key.
        orch.available().firstOrNull { it.hasKey(ctx) }?.let { primary ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    stringResource(R.string.ai_model_label),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                TextButton(onClick = { showModelMenu = true }) {
                    Text(orch.modelFor(primary))
                }
                DropdownMenu(expanded = showModelMenu, onDismissRequest = { showModelMenu = false }) {
                    primary.models.forEach { mdl ->
                        DropdownMenuItem(
                            text = { Text(mdl) },
                            onClick = {
                                orch.setModel(primary.id, mdl)
                                showModelMenu = false
                            },
                        )
                    }
                }
                TextButton(onClick = { showHelp = true }) { Text("ⓘ") }
            }
        }
        status?.let {
            Text(it, style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Box(Modifier.weight(1f).padding(vertical = 8.dp)) {
            if (history.isEmpty()) {
                Text(
                    stringResource(R.string.ai_empty),
                    modifier = Modifier.align(Alignment.Center),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            LazyColumn(state = listState, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(history, key = { it.at.toString() + it.role }) { m ->
                    val mine = m.role == "user"
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
                        Surface(
                            color = if (mine) MaterialTheme.colorScheme.primaryContainer
                            else MaterialTheme.colorScheme.surfaceVariant,
                            shape = MaterialTheme.shapes.medium,
                            modifier = Modifier.fillMaxWidth(0.85f),
                        ) {
                            Text(
                                m.text,
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.padding(10.dp),
                            )
                        }
                    }
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text(stringResource(R.string.ai_hint)) },
                maxLines = 4,
            )
            IconButton(onClick = { val t = input; input = ""; send(t) }, enabled = !thinking) {
                Icon(Icons.AutoMirrored.Filled.Send, stringResource(R.string.ai_send))
            }
        }
    }

    if (showHelp) {
        AlertDialog(
            onDismissRequest = { showHelp = false },
            title = { Text(stringResource(R.string.ai_help_title)) },
            text = { Text(stringResource(R.string.ai_help_body)) },
            confirmButton = {
                TextButton(onClick = { showHelp = false }) { Text(stringResource(R.string.ai_privacy_accept)) }
            },
        )
    }

    if (showKeyDialog) {
        AlertDialog(
            onDismissRequest = { showKeyDialog = false },
            title = { Text(stringResource(R.string.ai_key_title, keyProvider)) },
            text = {
                Column {
                    Text(stringResource(R.string.ai_key_hint))
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = keyText,
                        onValueChange = { keyText = it },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (keyText.isBlank()) KeystoreVault.clear(ctx, keyProvider)
                    else KeystoreVault.put(ctx, keyProvider, keyText.trim())
                    showKeyDialog = false
                }) { Text(stringResource(R.string.ai_key_save)) }
            },
            dismissButton = {
                TextButton(onClick = { showKeyDialog = false }) { Text(stringResource(R.string.cancel)) }
            },
        )
    }
}


private fun buildFilesSummary(vm: GalleryViewModel): String {
    val items = vm.items.value
    if (items.isEmpty()) return "The user has not granted file access yet."
    val cats = vm.categoryCounts.value.entries
        .sortedByDescending { it.value }
        .joinToString(", ") { "${it.key.name.lowercase()}: ${it.value}" }
    val folders = vm.folderCounts.value.entries
        .sortedByDescending { it.value }
        .take(6)
        .joinToString(", ") { it.key }
    val recent = items.sortedByDescending { it.dateAdded }
        .take(10)
        .joinToString(", ") { it.name }
    return "User's phone library: ${items.size} files ($cats). " +
        "Top folders: $folders. Recent files: $recent."
}
