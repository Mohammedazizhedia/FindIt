package com.gallerysearch.app.ui.ai

import android.content.Intent
import android.provider.OpenableColumns
import android.util.Base64
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.outlined.AttachFile
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.gallerysearch.app.GalleryViewModel
import com.gallerysearch.app.R
import com.gallerysearch.app.debug.AppLog
import androidx.compose.material3.Surface as M3Surface
import com.gallerysearch.app.ai.AiOrchestrator
import com.gallerysearch.app.ai.AttachedFile
import com.gallerysearch.app.ai.ChatRepo
import com.gallerysearch.app.ai.KeystoreVault
import com.gallerysearch.app.ai.OAuthBus
import com.gallerysearch.app.ai.OpenRouterOAuth
import com.gallerysearch.app.ai.UsageStore
import com.gallerysearch.app.settings.SettingsStore
import kotlinx.coroutines.launch

/**
 * Online AI chat. Works immediately after the user pastes one free key (a short
 * guided setup shows exactly how). Two-pane layout on tablets/landscape:
 * a side rail with providers, quota, model picker and tools; chat beside it.
 * Everything before the network call stays on the device.
 */
@Composable
fun AiScreen(vm: GalleryViewModel) {
    val ctx = LocalContext.current
    val privacyAccepted by SettingsStore.aiPrivacyAccepted.collectAsStateWithLifecycle()
    val premium by SettingsStore.isPremium.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    val orch = remember { AiOrchestrator(ctx) }

    var input by remember { mutableStateOf("") }
    var history by remember { mutableStateOf(ChatRepo.history()) }
    var thinking by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }
    var showKeyDialog by remember { mutableStateOf(false) }
    var showModelMenu by remember { mutableStateOf(false) }
    var showHelp by remember { mutableStateOf(false) }
    var attachFiles by remember { mutableStateOf(false) }
    var attachment by remember { mutableStateOf<AttachedFile?>(null) }
    var oauthVerifier by remember { mutableStateOf(OpenRouterOAuth.newVerifier()) }
    var keyVersion by remember { mutableIntStateOf(0) }
    var keyProvider by remember { mutableStateOf("") }
    var keyText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val wide = LocalConfiguration.current.screenWidthDp >= 600

    val hasAnyKey = remember(keyVersion) { orch.available().any { it.hasKey(ctx) } }

    LaunchedEffect(Unit) {
        ChatRepo.load(ctx)
        UsageStore.load(ctx)
        history = ChatRepo.history()
    }

    // Browser OAuth redirect: exchange the code for an OpenRouter key.
    LaunchedEffect(Unit) {
        OAuthBus.codes.collect { code ->
            status = ctx.getString(R.string.oauth_exchanging)
            val key = OpenRouterOAuth.exchange(code, oauthVerifier)
            if (key != null) {
                KeystoreVault.put(ctx, "openrouter", key)
                refreshKeys()
                status = ctx.getString(R.string.oauth_ok)
                AppLog.i("AI", "OpenRouter sign-in succeeded")
            } else {
                status = ctx.getString(R.string.oauth_fail)
                oauthVerifier = OpenRouterOAuth.newVerifier()
            }
        }
    }

    fun startAccountLogin() {
        oauthVerifier = OpenRouterOAuth.newVerifier()
        runCatching {
            ctx.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse(OpenRouterOAuth.authUrl(oauthVerifier))),
            )
        }
    }
    LaunchedEffect(history.size) {
        if (history.isNotEmpty()) listState.animateScrollToItem(history.size - 1)
    }

    fun refreshKeys() {
        keyVersion++
    }

    fun send(text: String) {
        val t = text.trim()
        if (t.isEmpty() || thinking) return
        thinking = true
        status = null
        scope.launch {
            try {
                val reply = orch.ask(
                    t,
                    if (attachFiles) buildFilesSummary(vm) else null,
                    attachment,
                )
                attachment = null
                history = ChatRepo.history()
                status = ctx.getString(R.string.ai_via, reply.providerId) +
                    if (reply.carriedContext) " · " + ctx.getString(R.string.ai_context_carried) else ""
            } catch (e: Exception) {
                status = e.message ?: ctx.getString(R.string.ai_error)
            } finally {
                thinking = false
            }
        }
    }

    if (!privacyAccepted) {
        AlertDialog(
            onDismissRequest = { },
            title = { Text(stringResource(R.string.ai_privacy_title)) },
            text = { Text(stringResource(R.string.ai_privacy_body)) },
            confirmButton = {
                TextButton(onClick = { SettingsStore.setAiPrivacyAccepted(true) }) {
                    Text(stringResource(R.string.ai_privacy_accept))
                }
            },
            dismissButton = {
                TextButton(onClick = { SettingsStore.setAiPrivacyAccepted(false) }) {
                    Text(stringResource(R.string.cancel))
                }
            },
        )
        return
    }

    if (!hasAnyKey) {
        GuidedSetup(
            orch = orch,
            onSaved = { refreshKeys() },
            onOpenHelp = { showHelp = true },
        )
        if (showHelp) {
            AlertDialog(
                onDismissRequest = { showHelp = false },
                title = { Text(stringResource(R.string.ai_help_title)) },
                text = { Text(stringResource(R.string.ai_help_body)) },
                confirmButton = {
                    TextButton(onClick = { showHelp = false }) { Text(stringResource(R.string.ai_privacy_accept)) }
                },
            )
        }
        return
    }

    Row(Modifier.fillMaxSize()) {
        if (wide) {
            Column(
                Modifier
                    .width(300.dp)
                    .fillMaxHeight()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
            ) {
                ProvidersRail(
                    orch = orch,
                    premium = premium,
                    keyVersion = keyVersion,
                    attachFiles = attachFiles,
                    onToggleAttach = { attachFiles = !attachFiles },
                    onPickKey = { p ->
                        keyProvider = p.id
                        keyText = KeystoreVault.get(ctx, p.id) ?: ""
                        showKeyDialog = true
                    },
                    onPickModel = { showModelMenu = true },
                    showModelMenu = showModelMenu,
                    onDismissModelMenu = { showModelMenu = false },
                    onSetModel = { p, m -> orch.setModel(p.id, m) },
                    onOpenHelp = { showHelp = true },
                    onClear = {
                        ChatRepo.clear(ctx)
                        history = emptyList()
                    },
                    onAccountLogin = { startAccountLogin() },
                )
            }
        }
        Column(
            Modifier
                .weight(1f)
                .fillMaxHeight()
                .padding(if (wide) PaddingValues(0.dp) else PaddingValues(14.dp)),
        ) {
            if (!wide) {
                CompactTopBar(
                    orch = orch,
                    premium = premium,
                    keyVersion = keyVersion,
                    attachFiles = attachFiles,
                    onToggleAttach = { attachFiles = !attachFiles },
                    onPickKey = { p ->
                        keyProvider = p.id
                        keyText = KeystoreVault.get(ctx, p.id) ?: ""
                        showKeyDialog = true
                    },
                    onOpenHelp = { showHelp = true },
                    onClear = {
                        ChatRepo.clear(ctx)
                        history = emptyList()
                    },
                    onAccountLogin = { startAccountLogin() },
                )
            }
            if (status != null && !wide) {
                Text(
                    status!!,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Box(Modifier.weight(1f).padding(vertical = 8.dp)) {
                if (history.isEmpty()) {
                    Text(
                        stringResource(R.string.ai_empty),
                        modifier = Modifier.align(Alignment.Center),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                LazyColumn(state = listState, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(history, key = { it.at.toString() + it.role }) { m ->
                        val mine = m.role == "user"
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start,
                        ) {
                            Surface(
                                color = if (mine) MaterialTheme.colorScheme.primaryContainer
                                else MaterialTheme.colorScheme.surfaceVariant,
                                shape = MaterialTheme.shapes.medium,
                                modifier = Modifier.fillMaxWidth(0.85f),
                            ) {
                                Text(
                                    m.text,
                                    style = MaterialTheme.typography.bodyMedium,
                                    modifier = Modifier.padding(10.dp),
                                )
                            }
                        }
                    }
                }
            }
            if (status != null && wide) {
                Text(
                    status!!,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            val fileLauncher = rememberLauncherForActivityResult(
                ActivityResultContracts.OpenDocument(),
            ) { uri ->
                if (uri == null) return@rememberLauncherForActivityResult
                scope.launch {
                    runCatching {
                        var name = "file"
                        var size = 0L
                        ctx.contentResolver.query(
                            uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE),
                            null, null, null,
                        )?.use { c ->
                            if (c.moveToFirst()) {
                                name = c.getString(0) ?: name
                                size = c.getLong(1)
                            }
                        }
                        if (size > 15L * 1024 * 1024) {
                            status = ctx.getString(R.string.attach_too_big)
                            return@launch
                        }
                        val mime = ctx.contentResolver.getType(uri) ?: "application/octet-stream"
                        val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                            ?: return@launch
                        attachment = AttachedFile(
                            name = name,
                            mime = mime,
                            base64 = Base64.encodeToString(bytes, Base64.NO_WRAP),
                        )
                        status = null
                    }.onFailure {
                        status = it.message ?: ctx.getString(R.string.ai_error)
                    }
                }
            }
            attachment?.let { file ->
                M3Surface(
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    shape = MaterialTheme.shapes.small,
                    modifier = Modifier.padding(bottom = 6.dp),
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                    ) {
                        Text(
                            stringResource(R.string.file_attached, file.name),
                            style = MaterialTheme.typography.labelSmall,
                        )
                        TextButton(onClick = { attachment = null }) { Text("✕") }
                    }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { fileLauncher.launch(arrayOf("*/*")) }) {
                    Icon(Icons.Outlined.AttachFile, stringResource(R.string.attach_file))
                }
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text(stringResource(R.string.ai_hint)) },
                    maxLines = 4,
                )
                IconButton(onClick = { val t = input; input = ""; send(t) }, enabled = !thinking) {
                    Icon(Icons.AutoMirrored.Filled.Send, stringResource(R.string.ai_send))
                }
            }
        }
    }

    if (showHelp) {
        AlertDialog(
            onDismissRequest = { showHelp = false },
            title = { Text(stringResource(R.string.ai_help_title)) },
            text = { Text(stringResource(R.string.ai_help_body)) },
            confirmButton = {
                TextButton(onClick = { showHelp = false }) { Text(stringResource(R.string.ai_privacy_accept)) }
            },
        )
    }

    if (showKeyDialog) {
        AlertDialog(
            onDismissRequest = { showKeyDialog = false },
            title = { Text(stringResource(R.string.ai_key_title, keyProvider)) },
            text = {
                Column {
                    Text(stringResource(R.string.ai_key_hint))
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = keyText,
                        onValueChange = { keyText = it },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (keyText.isBlank()) KeystoreVault.clear(ctx, keyProvider)
                    else KeystoreVault.put(ctx, keyProvider, keyText.trim())
                    refreshKeys()
                    showKeyDialog = false
                }) { Text(stringResource(R.string.ai_key_save)) }
            },
            dismissButton = {
                TextButton(onClick = { showKeyDialog = false }) { Text(stringResource(R.string.cancel)) }
            },
        )
    }
}

/** Full-screen guided setup shown until at least one provider key exists. */
@Composable
private fun GuidedSetup(
    orch: AiOrchestrator,
    onSaved: () -> Unit,
    onOpenHelp: () -> Unit,
) {
    val ctx = LocalContext.current
    var providerId by remember { mutableStateOf("gemini") }
    var key by remember { mutableStateOf("") }
    var saved by remember { mutableStateOf(false) }
    val provider = orch.available().first { it.id == providerId }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.height(24.dp))
        Text(
            stringResource(R.string.ai_setup_title),
            style = MaterialTheme.typography.headlineSmall,
        )
        Spacer(Modifier.height(8.dp))
        Text(
            stringResource(R.string.ai_setup_body),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(20.dp))
        Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = MaterialTheme.shapes.medium) {
            Column(Modifier.padding(14.dp)) {
                Text(stringResource(R.string.ai_step1), style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(4.dp))
                Text(stringResource(R.string.ai_step2), style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(4.dp))
                Text(stringResource(R.string.ai_step3), style = MaterialTheme.typography.bodyMedium)
            }
        }
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            orch.available().forEach { p ->
                FilledTonalButton(onClick = { providerId = p.id }) {
                    Text(
                        p.label,
                        color = if (p.id == providerId) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        Button(onClick = {
            runCatching {
                ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com")))
            }
        }) { Text(stringResource(R.string.ai_get_key)) }
        Spacer(Modifier.height(8.dp))
        FilledTonalButton(onClick = { startAccountLogin() }) {
            Text(stringResource(R.string.oauth_openrouter))
        }
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = key,
            onValueChange = { key = it; saved = false },
            label = { Text(stringResource(R.string.ai_key_title, provider.label)) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = {
                if (key.isBlank()) KeystoreVault.clear(ctx, providerId)
                else KeystoreVault.put(ctx, providerId, key.trim())
                saved = true
                onSaved()
            },
            enabled = key.isNotBlank(),
        ) { Text(stringResource(R.string.ai_setup_save)) }
        if (saved) {
            Spacer(Modifier.height(4.dp))
            Text(
                stringResource(R.string.ai_setup_hint),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.primary,
            )
        }
        Spacer(Modifier.height(8.dp))
        TextButton(onClick = onOpenHelp) { Text(stringResource(R.string.ai_help_title)) }
    }
}

@Composable
private fun ProvidersRail(
    orch: AiOrchestrator,
    premium: Boolean,
    keyVersion: Int,
    attachFiles: Boolean,
    onToggleAttach: () -> Unit,
    onPickKey: (com.gallerysearch.app.ai.AiProvider) -> Unit,
    onPickModel: () -> Unit,
    showModelMenu: Boolean,
    onDismissModelMenu: () -> Unit,
    onSetModel: (com.gallerysearch.app.ai.AiProvider, String) -> Unit,
    onOpenHelp: () -> Unit,
    onClear: () -> Unit,
    onAccountLogin: () -> Unit,
) {
    val ctx = LocalContext.current
    Text(
        stringResource(if (premium) R.string.ai_premium_on else R.string.ai_free_mode),
        style = MaterialTheme.typography.titleMedium,
        color = if (premium) MaterialTheme.colorScheme.primary
        else MaterialTheme.colorScheme.onSurfaceVariant,
    )
    Spacer(Modifier.height(10.dp))
    orch.available().forEach { p ->
        val has = remember(keyVersion) { p.hasKey(ctx) }
        val remaining = if (p.freeTier) {
            UsageStore.remaining(p, UsageStore.usedToday(ctx, p.id))
        } else Int.MAX_VALUE
        FilledTonalButton(
            onClick = { onPickKey(p) },
            modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
        ) {
            Text(
                p.label + if (p.freeTier) " ($remaining)" else if (!has) " ?" else "",
            )
        }
    }
    Spacer(Modifier.height(10.dp))
    orch.available().firstOrNull { it.hasKey(ctx) }?.let { primary ->
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                stringResource(R.string.ai_model_label),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            TextButton(onClick = onPickModel) { Text(orch.modelFor(primary)) }
            DropdownMenu(expanded = showModelMenu, onDismissRequest = onDismissModelMenu) {
                primary.models.forEach { mdl ->
                    DropdownMenuItem(
                        text = { Text(mdl) },
                        onClick = { onSetModel(primary, mdl); onDismissModelMenu() },
                    )
                }
            }
        }
    }
    TextButton(onClick = onToggleAttach) {
        Text(
            stringResource(R.string.ai_attach) + if (attachFiles) " ✓" else "",
            color = if (attachFiles) MaterialTheme.colorScheme.primary
            else MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
    if (!orch.available().first { it.id == "openrouter" }.hasKey(ctx)) {
        TextButton(onClick = onAccountLogin) {
            Text(stringResource(R.string.oauth_openrouter))
        }
    }
    TextButton(onClick = onOpenHelp) { Text("ⓘ " + stringResource(R.string.ai_help_title)) }
    TextButton(onClick = onClear) { Text(stringResource(R.string.ai_clear)) }
}

@Composable
private fun CompactTopBar(
    orch: AiOrchestrator,
    premium: Boolean,
    keyVersion: Int,
    attachFiles: Boolean,
    onToggleAttach: () -> Unit,
    onPickKey: (com.gallerysearch.app.ai.AiProvider) -> Unit,
    onOpenHelp: () -> Unit,
    onClear: () -> Unit,
) {
    val ctx = LocalContext.current
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
            stringResource(if (premium) R.string.ai_premium_on else R.string.ai_free_mode),
            style = MaterialTheme.typography.titleMedium,
            color = if (premium) MaterialTheme.colorScheme.primary
            else MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.weight(1f),
        )
        TextButton(onClick = onClear) { Text(stringResource(R.string.ai_clear)) }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        orch.available().forEach { p ->
            val has = remember(keyVersion) { p.hasKey(ctx) }
            val remaining = if (p.freeTier) {
                UsageStore.remaining(p, UsageStore.usedToday(ctx, p.id))
            } else Int.MAX_VALUE
            FilledTonalButton(onClick = { onPickKey(p) }) {
                Text(
                    p.label + if (p.freeTier) " ($remaining)" else if (!has) " ?" else "",
                    style = MaterialTheme.typography.labelSmall,
                )
            }
        }
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        TextButton(onClick = onToggleAttach) {
            Text(
                stringResource(R.string.ai_attach) + if (attachFiles) " ✓" else "",
                color = if (attachFiles) MaterialTheme.colorScheme.primary
                else MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        TextButton(onClick = onOpenHelp) { Text("ⓘ") }
    }
}

private fun buildFilesSummary(vm: GalleryViewModel): String {
    val items = vm.items.value
    if (items.isEmpty()) return "The user has not granted file access yet."
    val cats = vm.categoryCounts.value.entries
        .sortedByDescending { it.value }
        .joinToString(", ") { "${it.key.name.lowercase()}: ${it.value}" }
    val folders = vm.folderCounts.value.entries
        .sortedByDescending { it.value }
        .take(6)
        .joinToString(", ") { it.key }
    val recent = items.sortedByDescending { it.dateAdded }
        .take(10)
        .joinToString(", ") { it.name }
    return "User's phone library: ${items.size} files ($cats). " +
        "Top folders: $folders. Recent files: $recent."
}
