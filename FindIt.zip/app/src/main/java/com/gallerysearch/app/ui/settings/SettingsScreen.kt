package com.gallerysearch.app.ui.settings

import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import android.app.Activity
import com.android.billingclient.api.ProductDetails
import com.gallerysearch.app.R
import com.gallerysearch.app.billing.BillingController
import com.gallerysearch.app.settings.SettingsStore
import com.gallerysearch.app.ui.theme.AccentTheme
import com.gallerysearch.app.ui.theme.ThemeMode

@Composable
fun SettingsScreen(onLanguageChanged: () -> Unit) {
    val themeMode by SettingsStore.themeMode.collectAsStateWithLifecycle()
    val accent by SettingsStore.accent.collectAsStateWithLifecycle()
    val language by SettingsStore.language.collectAsStateWithLifecycle()
    val trashDays by SettingsStore.trashRetentionDays.collectAsStateWithLifecycle()
    val premium by SettingsStore.isPremium.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    val activity = ctx as? Activity
    val scope = rememberCoroutineScope()
    val billing = remember { BillingController(ctx) }
    var offers by remember { mutableStateOf<List<ProductDetails>>(emptyList()) }
    var billingFailed by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { offers = billing.loadOffers() }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
    ) {
        Text(stringResource(R.string.settings_title), style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(20.dp))

        SectionHeader(R.string.section_appearance)
        ChoiceRow(R.string.theme_system, themeMode == ThemeMode.SYSTEM) {
            SettingsStore.setThemeMode(ThemeMode.SYSTEM)
        }
        ChoiceRow(R.string.theme_light, themeMode == ThemeMode.LIGHT) {
            SettingsStore.setThemeMode(ThemeMode.LIGHT)
        }
        ChoiceRow(R.string.theme_dark, themeMode == ThemeMode.DARK) {
            SettingsStore.setThemeMode(ThemeMode.DARK)
        }

        Spacer(Modifier.height(16.dp))
        Text(stringResource(R.string.accent_color), style = MaterialTheme.typography.labelLarge)
        Spacer(Modifier.height(8.dp))
        AccentPicker(accent) { SettingsStore.setAccent(it) }

        Spacer(Modifier.height(24.dp))
        SectionHeader(R.string.section_trash)
        Text(stringResource(R.string.trash_keep_label), style = MaterialTheme.typography.labelLarge)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(7, 30, 90).forEach { d ->
                FilterChip(
                    selected = trashDays == d,
                    onClick = { SettingsStore.setTrashRetentionDays(d) },
                    label = { Text(stringResource(dayRes(d))) },
                )
            }
        }

        Spacer(Modifier.height(24.dp))
        SectionHeader(R.string.section_premium)
        Text(
            stringResource(if (premium) R.string.premium_on else R.string.premium_benefit),
            style = MaterialTheme.typography.bodyMedium,
            color = if (premium) MaterialTheme.colorScheme.primary
            else MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(8.dp))
        if (!premium) {
            if (offers.isEmpty() && billingFailed) {
                Text(stringResource(R.string.billing_unavailable), style = MaterialTheme.typography.bodySmall)
            }
            offers.forEach { od ->
                val price = od.subscriptionOfferDetails?.firstOrNull()
                    ?.pricingPhases?.pricingPhaseList?.firstOrNull()?.formattedPrice ?: ""
                val label = if (od.productId == BillingController.MONTHLY) {
                    stringResource(R.string.plan_monthly, price)
                } else {
                    stringResource(R.string.plan_yearly, price)
                }
                ChoiceRowLabel(label) { activity?.let { billing.launch(it, od) } }
            }
            TextButton(onClick = {
                scope.launch { billingFailed = !billing.restore() && offers.isEmpty() }
            }) { Text(stringResource(R.string.restore_purchases)) }
        }

        Spacer(Modifier.height(24.dp))
        SectionHeader(R.string.section_language)
        ChoiceRow(R.string.language_auto, language == SettingsStore.LANG_AUTO) {
            pickLanguage(SettingsStore.LANG_AUTO, language, onLanguageChanged)
        }
        ChoiceRow(R.string.language_arabic, language == SettingsStore.LANG_AR) {
            pickLanguage(SettingsStore.LANG_AR, language, onLanguageChanged)
        }
        ChoiceRow(R.string.language_english, language == SettingsStore.LANG_EN) {
            pickLanguage(SettingsStore.LANG_EN, language, onLanguageChanged)
        }
        Spacer(Modifier.height(4.dp))
        Text(
            stringResource(R.string.restart_note),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

private fun dayRes(d: Int): Int = when (d) {
    7 -> R.string.trash_7
    90 -> R.string.trash_90
    else -> R.string.trash_30
}

private fun pickLanguage(lang: String, current: String, onChanged: () -> Unit) {
    if (lang == current) return
    SettingsStore.setLanguage(lang)
    onChanged()
}

@Composable
private fun ChoiceRowLabel(label: String, onClick: () -> Unit) {
    Text(
        label,
        style = MaterialTheme.typography.bodyLarge,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.medium)
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp),
    )
}

@Composable
private fun SectionHeader(res: Int) {
    Text(
        stringResource(res),
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.primary,
    )
    Spacer(Modifier.height(4.dp))
}

@Composable
private fun ChoiceRow(labelRes: Int, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.medium)
            .clickable(onClick = onClick)
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected = selected, onClick = null)
        Spacer(Modifier.size(12.dp))
        Text(stringResource(labelRes), style = MaterialTheme.typography.bodyLarge)
    }
}

@Composable
private fun AccentPicker(selected: AccentTheme, onSelect: (AccentTheme) -> Unit) {
    val options = buildList {
        add(AccentTheme.DEFAULT)
        add(AccentTheme.TEAL)
        add(AccentTheme.INDIGO)
        add(AccentTheme.AMBER)
        add(AccentTheme.ROSE)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) add(AccentTheme.DYNAMIC)
    }
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        options.forEach { a ->
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                val dynamic = a == AccentTheme.DYNAMIC
                Box(
                    Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .then(
                            if (dynamic) {
                                Modifier.background(
                                    Brush.linearGradient(
                                        listOf(Color(0xFF4F46E5), Color(0xFF0F766E), Color(0xFFB45309)),
                                    ),
                                )
                            } else {
                                Modifier.background(previewColor(a))
                            },
                        )
                        .then(
                            if (selected == a) {
                                Modifier.border(2.dp, MaterialTheme.colorScheme.onSurface, CircleShape)
                            } else {
                                Modifier.border(1.dp, MaterialTheme.colorScheme.outline, CircleShape)
                            },
                        )
                        .clickable { onSelect(a) },
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = accentLabel(a),
                    style = MaterialTheme.typography.labelSmall,
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun accentLabel(a: AccentTheme): String = when (a) {
    AccentTheme.DEFAULT -> stringResource(R.string.accent_default)
    AccentTheme.TEAL -> stringResource(R.string.accent_teal)
    AccentTheme.INDIGO -> stringResource(R.string.accent_indigo)
    AccentTheme.AMBER -> stringResource(R.string.accent_amber)
    AccentTheme.ROSE -> stringResource(R.string.accent_rose)
    AccentTheme.DYNAMIC -> stringResource(R.string.accent_dynamic)
}

private fun previewColor(a: AccentTheme): Color = when (a) {
    AccentTheme.DEFAULT -> Color(0xFF185FA5)
    AccentTheme.TEAL -> Color(0xFF0F766E)
    AccentTheme.INDIGO -> Color(0xFF4F46E5)
    AccentTheme.AMBER -> Color(0xFFB45309)
    AccentTheme.ROSE -> Color(0xFFBE123C)
    AccentTheme.DYNAMIC -> Color(0xFF4F46E5)
}
