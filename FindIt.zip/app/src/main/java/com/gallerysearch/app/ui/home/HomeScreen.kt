package com.gallerysearch.app.ui.home

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.FilterList
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.gallerysearch.app.GalleryViewModel
import com.gallerysearch.app.R
import com.gallerysearch.app.data.Category
import com.gallerysearch.app.data.DatePresets
import com.gallerysearch.app.data.MediaItem
import com.gallerysearch.app.data.SearchFilters
import com.gallerysearch.app.ui.components.LineIcon
import com.gallerysearch.app.ui.components.LineIconView
import com.gallerysearch.app.ui.theme.LocalTints
import com.gallerysearch.app.debug.AppLog
import com.gallerysearch.app.settings.SettingsStore
import com.gallerysearch.app.ui.theme.Tint
import com.gallerysearch.app.voice.VoiceSearchSheet

private val COMMON_EXTENSIONS = listOf("jpg", "png", "mp4", "mp3", "pdf", "docx", "zip", "apk")

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomeScreen(vm: GalleryViewModel) {
    val ctx = LocalContext.current
    val results by vm.results.collectAsStateWithLifecycle()
    val total by vm.resultCount.collectAsStateWithLifecycle()
    val q by vm.query.collectAsStateWithLifecycle()
    val counts by vm.categoryCounts.collectAsStateWithLifecycle()
    val safCount = SettingsStore.safFolders.collectAsStateWithLifecycle().value.size
    val indexStats by vm.indexStats.collectAsStateWithLifecycle()
    val filters by vm.filters.collectAsStateWithLifecycle()
    val tints = LocalTints.current

    var showFilters by rememberSaveable { mutableStateOf(false) }
    var showVoice by rememberSaveable { mutableStateOf(false) }
    val folderLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree(),
    ) { uri -> uri?.let { vm.addSafFolder(it) } }

    // Auto-grow the paged window when the user scrolls near the end.
    val gridState = rememberLazyGridState()
    val shouldLoadMore = remember {
        derivedStateOf {
            val last = gridState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            results.isNotEmpty() && last >= results.size - 24
        }
    }
    LaunchedEffect(gridState) {
        snapshotFlow { shouldLoadMore.value }.collect { if (it) vm.loadMore() }
    }

    Column(Modifier.fillMaxSize()) {
        TextField(
            value = q,
            onValueChange = { vm.setQuery(it) },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp).padding(top = 8.dp),
            singleLine = true,
            shape = RoundedCornerShape(22.dp),
            placeholder = { Text(stringResource(R.string.search_hint)) },
            leadingIcon = { Icon(Icons.Outlined.Search, null) },
            trailingIcon = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { showFilters = true }) {
                        Icon(
                            Icons.Outlined.FilterList,
                            stringResource(R.string.filters_title),
                            tint = if (filters == SearchFilters.DEFAULT) {
                                MaterialTheme.colorScheme.onSurfaceVariant
                            } else {
                                tints.accent.fg
                            },
                        )
                    }
                    IconButton(onClick = { showVoice = true }) {
                        Icon(Icons.Outlined.Mic, stringResource(R.string.voice), tint = tints.accent.fg)
                    }
                }
            },
            colors = TextFieldDefaults.colors(
                focusedIndicatorColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent,
            ),
        )
        TextButton(
            onClick = { folderLauncher.launch(null) },
            modifier = Modifier.padding(horizontal = 10.dp),
        ) {
            Text(stringResource(R.string.add_folder))
        }
        LazyVerticalGrid(
            state = gridState,
            columns = GridCells.Fixed(3),
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(14.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Column {
                Text(stringResource(R.string.home_sub), style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(stringResource(R.string.home_title), style = MaterialTheme.typography.headlineMedium)

                Text(stringResource(R.string.smart_cats), style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(10.dp))

                val photos = counts[Category.IMAGE] ?: 0
                val videos = counts[Category.VIDEO] ?: 0
                val audio = counts[Category.AUDIO] ?: 0
                val docs = counts[Category.DOCUMENT] ?: 0
                val archives = (counts[Category.ARCHIVE] ?: 0) + (counts[Category.APP] ?: 0)

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    CategoryTile(
                        Modifier.weight(1f), LineIcon.Scenery,
                        stringResource(R.string.cat_photos),
                        stringResource(R.string.files_count, photos), tints.accent,
                    ) { vm.setFilters(SearchFilters(category = Category.IMAGE)) }
                    CategoryTile(
                        Modifier.weight(1f), LineIcon.Video,
                        stringResource(R.string.cat_videos),
                        stringResource(R.string.videos_count, videos), tints.danger,
                    ) { vm.setFilters(SearchFilters(category = Category.VIDEO)) }
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    CategoryTile(
                        Modifier.weight(1f), LineIcon.Audio,
                        stringResource(R.string.cat_audio),
                        stringResource(R.string.files_count, audio), tints.success,
                    ) { vm.setFilters(SearchFilters(category = Category.AUDIO)) }
                    CategoryTile(
                        Modifier.weight(1f), LineIcon.Receipt,
                        stringResource(R.string.cat_docs),
                        stringResource(R.string.files_count, docs), tints.warning,
                    ) { vm.setFilters(SearchFilters(category = Category.DOCUMENT)) }
                }
                Spacer(Modifier.height(10.dp))
                CategoryTile(
                    Modifier.fillMaxWidth(), LineIcon.Box,
                    stringResource(R.string.cat_archives),
                    stringResource(R.string.files_count, archives), tints.pro,
                ) { vm.setFilters(SearchFilters(category = Category.ARCHIVE)) }
                if (filters.category != null) {
                    Spacer(Modifier.height(6.dp))
                    TextButton(onClick = { vm.setFilters(SearchFilters.DEFAULT) }) {
                        Text(stringResource(R.string.show_all))
                    }
                }
                Spacer(Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        stringResource(R.string.index_status, indexStats.first, indexStats.second),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.weight(1f),
                    )
                    TextButton(onClick = { vm.startScan() }) {
                        Text(stringResource(R.string.reindex))
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        stringResource(R.string.recent),
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.weight(1f),
                    )
                    Text(
                        stringResource(R.string.results_showing, results.size, total),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                if (q.isNotBlank() && results.isEmpty()) {
                    Text(
                        stringResource(R.string.search_no_results, q),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                    )
                }
                Spacer(Modifier.height(6.dp))
            }
        }
        items(results, key = { it.uri.toString() }) { m ->
            if (m.category == Category.IMAGE || m.category == Category.VIDEO) {
                AsyncImage(
                    model = m.uri,
                    contentDescription = m.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .aspectRatio(1f)
                        .clip(RoundedCornerShape(6.dp))
                        .combinedClickable(
                            onClick = { openFile(ctx, m) },
                            onLongClick = { if (m.category == Category.IMAGE) vm.searchSimilarTo(m) },
                        ),
                )
            } else {
                FileTile(m, onClick = { openFile(ctx, m) })
            }
        }
        }
    }

    if (showVoice) {
        VoiceSearchSheet(
            initialQuery = q,
            onSearch = { vm.query.value = it; showVoice = false },
            onDismiss = { showVoice = false },
        )
    }

    if (showFilters) {
        FiltersSheet(
            current = filters,
            folderCounts = vm.folderCounts.collectAsStateWithLifecycle().value,
            onApply = { vm.setFilters(it); showFilters = false },
            onDismiss = { showFilters = false },
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun FiltersSheet(
    current: SearchFilters,
    folderCounts: Map<String, Int>,
    onApply: (SearchFilters) -> Unit,
    onDismiss: () -> Unit,
) {
    val mb = 1024L * 1024
    var extensions by remember { mutableStateOf(current.extensions) }
    var minMb by remember {
        mutableStateOf(if (current.minBytes > 0) (current.minBytes / mb).toString() else "")
    }
    var maxMb by remember {
        mutableStateOf(if (current.maxBytes < Long.MAX_VALUE) (current.maxBytes / mb).toString() else "")
    }
    var datePreset by remember { mutableIntStateOf(DatePresets.ALL) }
    var folders by remember { mutableStateOf(current.folders) }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
        ) {
            Text(stringResource(R.string.filters_title), style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(16.dp))

            Text(stringResource(R.string.filter_extensions), style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(6.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                COMMON_EXTENSIONS.forEach { ext ->
                    FilterChip(
                        selected = ext in extensions,
                        onClick = {
                            extensions = if (ext in extensions) extensions - ext else extensions + ext
                        },
                        label = { Text(ext) },
                    )
                }
            }
            Spacer(Modifier.height(16.dp))

            Text(stringResource(R.string.filter_size), style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = minMb,
                    onValueChange = { minMb = it.filter(Char::isDigit).take(6) },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    label = { Text(stringResource(R.string.filter_from)) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                )
                OutlinedTextField(
                    value = maxMb,
                    onValueChange = { maxMb = it.filter(Char::isDigit).take(6) },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    label = { Text(stringResource(R.string.filter_to)) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                )
            }
            Spacer(Modifier.height(16.dp))

            Text(stringResource(R.string.filter_date), style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(6.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(
                    DatePresets.ALL to R.string.date_all,
                    DatePresets.TODAY to R.string.date_today,
                    DatePresets.WEEK to R.string.date_week,
                    DatePresets.MONTH to R.string.date_month,
                    DatePresets.YEAR to R.string.date_year,
                ).forEach { (id, labelRes) ->
                    FilterChip(
                        selected = datePreset == id,
                        onClick = { datePreset = id },
                        label = { Text(stringResource(labelRes)) },
                    )
                }
            }
            Spacer(Modifier.height(16.dp))

            Text(stringResource(R.string.filter_folder), style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(6.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                folderCounts.entries.sortedByDescending { it.value }.take(12).forEach { (folder, count) ->
                    FilterChip(
                        selected = folder in folders,
                        onClick = {
                            folders = if (folder in folders) folders - folder else folders + folder
                        },
                        label = { Text("$folder · $count") },
                    )
                }
            }
            if (folderCounts.isEmpty()) {
                Text(
                    stringResource(R.string.filters_no_folders),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Spacer(Modifier.height(20.dp))

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                TextButton(
                    onClick = {
                        extensions = emptySet()
                        minMb = ""
                        maxMb = ""
                        datePreset = DatePresets.ALL
                        folders = emptySet()
                    },
                    modifier = Modifier.weight(1f),
                ) { Text(stringResource(R.string.filter_reset)) }
                Button(
                    onClick = {
                        val (from, to) = DatePresets.range(datePreset)
                        onApply(
                            SearchFilters(
                                extensions = extensions,
                                minBytes = minMb.toLongOrNull()?.let { it * mb } ?: 0L,
                                maxBytes = maxMb.toLongOrNull()?.let { it * mb } ?: Long.MAX_VALUE,
                                dateFromSec = from,
                                dateToSec = to,
                                folders = folders,
                            ),
                        )
                    },
                    modifier = Modifier.weight(2f),
                ) { Text(stringResource(R.string.filter_apply)) }
            }
        }
    }
}

@Composable
private fun CategoryTile(
    modifier: Modifier,
    icon: LineIcon,
    title: String,
    subtitle: String,
    tint: Tint,
    onClick: () -> Unit,
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .background(tint.bg)
            .clickable(onClick = onClick)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        LineIconView(icon, tint.fg)
        Text(title, style = MaterialTheme.typography.titleMedium, color = tint.fg)
        Text(subtitle, style = MaterialTheme.typography.bodySmall, color = tint.fg)
    }
}

/** Placeholder tile for files that cannot be previewed as images (docs, audio, archives). */
@Composable
private fun FileTile(m: MediaItem, onClick: () -> Unit) {
    val icon = when (m.category) {
        Category.AUDIO -> LineIcon.Audio
        Category.DOCUMENT -> LineIcon.Receipt
        Category.ARCHIVE, Category.APP -> LineIcon.Box
        else -> LineIcon.Receipt
    }
    Column(
        Modifier
            .aspectRatio(1f)
            .clip(RoundedCornerShape(6.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable(onClick = onClick),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        LineIconView(icon, MaterialTheme.colorScheme.onSurfaceVariant, 30.dp)
        Spacer(Modifier.height(4.dp))
        Text(
            m.extension.uppercase(),
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}


/** Open a file with the system's viewer app. */
private fun openFile(ctx: android.content.Context, m: MediaItem) {
    runCatching {
        val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
            setDataAndType(m.uri, m.mime.ifEmpty { "*/*" })
            addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(intent)
    }.onFailure {
        AppLog.e("Files", "open failed: ${'$'}{m.name} (${'$'}{m.mime})", it)
    }
}
