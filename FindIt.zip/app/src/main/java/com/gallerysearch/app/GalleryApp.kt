package com.gallerysearch.app

import android.app.Application
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.decode.VideoFrameDecoder
import com.gallerysearch.app.settings.SettingsStore

class GalleryApp : Application(), ImageLoaderFactory {
    override fun onCreate() {
        super.onCreate()
        SettingsStore.init(this)
        ensureFonts()
    }

    /** Font(File, weight) needs real files; copy the bundled assets once. */
    private fun ensureFonts() {
        val dir = java.io.File(filesDir, "fonts")
        dir.mkdirs()
        listOf(
            "cairo_regular.ttf", "cairo_medium.ttf", "cairo_semibold.ttf", "cairo_bold.ttf",
            "tajawal_regular.ttf", "tajawal_medium.ttf", "tajawal_bold.ttf",
            "amiri_regular.ttf", "amiri_bold.ttf",
        ).forEach { name ->
            val out = java.io.File(dir, name)
            if (!out.exists()) {
                runCatching {
                    assets.open("fonts/$name").use { i ->
                        out.outputStream().use { o -> i.copyTo(o) }
                    }
                }.onFailure { out.delete() }
            }
        }
    }

    override fun newImageLoader(): ImageLoader =
        ImageLoader.Builder(this)
            .components { add(VideoFrameDecoder.Factory()) }
            .build()
}
