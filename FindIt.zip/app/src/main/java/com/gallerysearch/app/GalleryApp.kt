package com.gallerysearch.app

import android.app.Application
import android.content.Intent
import android.util.Log
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.decode.VideoFrameDecoder
import com.gallerysearch.app.debug.AppLog
import com.gallerysearch.app.settings.SettingsStore

class GalleryApp : Application(), ImageLoaderFactory {
    override fun onCreate() {
        super.onCreate()
        SettingsStore.init(this)
        AppLog.init(this)
        AppLog.i("App", "Find It started")
        // Debug builds: surface fatal crashes on screen so they can be reported.
        Thread.setDefaultUncaughtExceptionHandler { _, throwable ->
            AppLog.e("Crash", "uncaught exception", throwable)
            runCatching {
                val intent = Intent(this, CrashActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    .putExtra("trace", Log.getStackTraceString(throwable))
                startActivity(intent)
            }
            android.os.Process.killProcess(android.os.Process.myPid())
        }
    }

    override fun newImageLoader(): ImageLoader =
        ImageLoader.Builder(this)
            .components { add(VideoFrameDecoder.Factory()) }
            .build()
}
