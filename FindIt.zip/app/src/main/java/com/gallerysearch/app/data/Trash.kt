package com.gallerysearch.app.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.net.Uri
import android.provider.MediaStore
import com.gallerysearch.app.R
import com.gallerysearch.app.settings.SettingsStore
import java.io.File
import java.io.IOException
import java.security.MessageDigest
import java.util.UUID

data class TrashEntry(
    val id: String,
    val originalUri: String,
    val name: String,
    val mime: String,
    val relPath: String,
    val isVideo: Boolean,
    val size: Long,
    val dateTaken: Long,
    val dateAdded: Long,
    val trashedAt: Long,
    val hash: String,
    val file: String,
    val pending: Boolean,
)

data class RestoreResult(
    val entry: TrashEntry,
    val success: Boolean,
    val reasonRes: Int,
)

data class RestoreReport(val results: List<RestoreResult>) {
    val restoredCount: Int get() = results.count { it.success }
    val failedCount: Int get() = results.size - restoredCount
}

/** Conflict-free display name generator — pure and unit-testable. */
object TrashNames {
    fun unique(name: String, taken: Collection<String>): String {
        if (name !in taken) return name
        val dot = name.lastIndexOf('.')
        val stem = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        var i = 1
        while ("$stem ($i)$ext" in taken) i++
        return "$stem ($i)$ext"
    }
}

private class TrashDb(ctx: Context) : SQLiteOpenHelper(ctx, "trash.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """CREATE TABLE entries(
                id TEXT PRIMARY KEY,
                originalUri TEXT NOT NULL,
                name TEXT NOT NULL,
                mime TEXT NOT NULL,
                relPath TEXT NOT NULL,
                isVideo INTEGER NOT NULL,
                size INTEGER NOT NULL,
                dateTaken INTEGER NOT NULL,
                dateAdded INTEGER NOT NULL,
                trashedAt INTEGER NOT NULL,
                hash TEXT NOT NULL,
                file TEXT NOT NULL,
                pending INTEGER NOT NULL)""",
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit
}

/**
 * The app's own trash. Every original is copied into app-private storage and its
 * SHA-256 recorded BEFORE the system deletes it. Restore writes back through
 * MediaStore to the original folder, handles name conflicts and missing folders,
 * verifies the restored file (size always, hash up to 10 MB), and reports a
 * per-file success/failure with a reason.
 */
class TrashRepository(private val ctx: Context) {
    private val dir = File(ctx.filesDir, "trash").apply { mkdirs() }
    private val db = TrashDb(ctx)
    private val lock = Any()

    private val retentionMs: Long
        get() = SettingsStore.trashRetentionDays.coerceAtLeast(1).toLong() * 24 * 60 * 60 * 1000

    fun list(): List<TrashEntry> = synchronized(lock) { query("pending = 0") }

    /** Copies originals into the trash and records them (pending) in the database. */
    fun copyIn(items: List<MediaItem>): Pair<List<TrashEntry>, Int> = synchronized(lock) {
        val made = ArrayList<TrashEntry>()
        var failed = 0
        val md = MessageDigest.getInstance("SHA-256")
        for (m in items) {
            val ext = m.name.substringAfterLast('.', "bin")
            val dest = File(dir, "${UUID.randomUUID()}.$ext")
            val hash = runCatching {
                val input = ctx.contentResolver.openInputStream(m.uri) ?: return@runCatching null
                input.use { i ->
                    dest.outputStream().use { o ->
                        md.reset()
                        val buf = ByteArray(64 * 1024)
                        var r = i.read(buf)
                        while (r != -1) {
                            md.update(buf, 0, r)
                            o.write(buf, 0, r)
                            r = i.read(buf)
                        }
                    }
                }
                if (dest.length() != m.size) return@runCatching null
                md.digest().joinToString("") { "%02x".format(it) }
            }.getOrNull()
            if (hash != null) {
                val e = TrashEntry(
                    id = UUID.randomUUID().toString(),
                    originalUri = m.uri.toString(),
                    name = m.name,
                    mime = m.mime,
                    relPath = m.relPath,
                    isVideo = m.isVideo,
                    size = m.size,
                    dateTaken = m.dateTaken,
                    dateAdded = m.dateAdded,
                    trashedAt = System.currentTimeMillis(),
                    hash = hash,
                    file = dest.absolutePath,
                    pending = true,
                )
                insert(e)
                made += e
            } else {
                dest.delete()
                failed++
            }
        }
        made to failed
    }

    fun commit(ids: Set<String>) = synchronized(lock) {
        val v = ContentValues().apply {
            put("pending", 0)
            put("trashedAt", System.currentTimeMillis())
        }
        ids.forEach { db.writableDatabase.update("entries", v, "id = ?", arrayOf(it)) }
    }

    fun discard(entries: List<TrashEntry>) = remove(entries)

    fun purge(entries: List<TrashEntry>) = remove(entries)

    private fun remove(entries: List<TrashEntry>) = synchronized(lock) {
        entries.forEach {
            File(it.file).delete()
            db.writableDatabase.delete("entries", "id = ?", arrayOf(it.id))
        }
    }

    /** Restores each entry; failures stay in the trash with a per-file reason. */
    fun restore(entries: List<TrashEntry>): RestoreReport = synchronized(lock) {
        val results = ArrayList<RestoreResult>()
        val takenNames = HashSet<String>()
        for (e in entries) {
            val r = restoreOne(e, takenNames)
            results += r
            if (r.success) {
                File(e.file).delete()
                db.writableDatabase.delete("entries", "id = ?", arrayOf(e.id))
            }
        }
        RestoreReport(results)
    }

    private fun restoreOne(e: TrashEntry, takenNames: MutableSet<String>): RestoreResult {
        val src = File(e.file)
        if (!src.exists()) {
            return RestoreResult(e, false, R.string.restore_reason_missing)
        }
        return try {
            val name = TrashNames.unique(e.name, takenNames)
            takenNames += name
            val base = MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL)
            val rel = when {
                e.relPath.isBlank() -> "Restored/"
                e.relPath.endsWith("/") -> e.relPath
                else -> e.relPath + "/"
            }
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                if (e.mime.isNotBlank()) put(MediaStore.MediaColumns.MIME_TYPE, e.mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, rel)
                if (e.dateTaken > 0) put(MediaStore.MediaColumns.DATE_TAKEN, e.dateTaken)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val uri = ctx.contentResolver.insert(base, values)
                ?: return RestoreResult(e, false, R.string.restore_reason_insert)
            try {
                ctx.contentResolver.openOutputStream(uri)?.use { o ->
                    src.inputStream().use { it.copyTo(o) }
                } ?: throw IOException("no output stream")
                val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                ctx.contentResolver.update(uri, done, null, null)
                if (!verifyRestored(uri, e)) {
                    ctx.contentResolver.delete(uri, null, null)
                    return RestoreResult(e, false, R.string.restore_reason_verify)
                }
                RestoreResult(e, true, R.string.restore_reason_ok)
            } catch (_: Exception) {
                runCatching { ctx.contentResolver.delete(uri, null, null) }
                RestoreResult(e, false, R.string.restore_reason_write)
            }
        } catch (_: Exception) {
            RestoreResult(e, false, R.string.restore_reason_write)
        }
    }

    /** Size check for every file; SHA-256 re-check for files up to 10 MB. */
    private fun verifyRestored(uri: Uri, e: TrashEntry): Boolean = runCatching {
        val restoredSize = ctx.contentResolver.query(
            uri, arrayOf(MediaStore.MediaColumns.SIZE), null, null, null,
        )?.use { c -> if (c.moveToFirst()) c.getLong(0) else -1L } ?: return false
        if (restoredSize != e.size) return false
        if (e.size <= VERIFY_HASH_LIMIT && e.hash.isNotBlank()) {
            val md = MessageDigest.getInstance("SHA-256")
            ctx.contentResolver.openInputStream(uri)?.use { input ->
                md.reset()
                val buf = ByteArray(64 * 1024)
                var r = input.read(buf)
                while (r != -1) {
                    md.update(buf, 0, r)
                    r = input.read(buf)
                }
            } ?: return false
            md.digest().joinToString("") { "%02x".format(it) } == e.hash
        } else {
            true
        }
    }.getOrDefault(false)

    /** Settles interrupted deletions and purges entries past the retention period. */
    fun maintenance() = synchronized(lock) {
        val now = System.currentTimeMillis()
        for (e in query("pending = 1")) {
            if (originalExists(e)) {
                File(e.file).delete()
                db.writableDatabase.delete("entries", "id = ?", arrayOf(e.id))
            } else {
                val v = ContentValues().apply {
                    put("pending", 0)
                    put("trashedAt", now)
                }
                db.writableDatabase.update("entries", v, "id = ?", arrayOf(e.id))
            }
        }
        for (e in query("pending = 0")) {
            if (now - e.trashedAt > retentionMs) {
                File(e.file).delete()
                db.writableDatabase.delete("entries", "id = ?", arrayOf(e.id))
            }
        }
    }

    private fun originalExists(e: TrashEntry): Boolean = runCatching {
        ctx.contentResolver.query(
            Uri.parse(e.originalUri), arrayOf(MediaStore.MediaColumns._ID), null, null, null,
        )?.use { it.count > 0 } ?: false
    }.getOrDefault(false)

    private fun insert(e: TrashEntry) {
        val v = ContentValues().apply {
            put("id", e.id)
            put("originalUri", e.originalUri)
            put("name", e.name)
            put("mime", e.mime)
            put("relPath", e.relPath)
            put("isVideo", if (e.isVideo) 1 else 0)
            put("size", e.size)
            put("dateTaken", e.dateTaken)
            put("dateAdded", e.dateAdded)
            put("trashedAt", e.trashedAt)
            put("hash", e.hash)
            put("file", e.file)
            put("pending", if (e.pending) 1 else 0)
        }
        db.writableDatabase.insertWithOnConflict("entries", null, v, SQLiteDatabase.CONFLICT_REPLACE)
    }

    private fun query(where: String): List<TrashEntry> {
        val out = ArrayList<TrashEntry>()
        db.readableDatabase.query(
            "entries", null, where, null, null, null, "trashedAt DESC",
        ).use { c ->
            while (c.moveToNext()) {
                out += TrashEntry(
                    id = c.getString(0),
                    originalUri = c.getString(1),
                    name = c.getString(2),
                    mime = c.getString(3),
                    relPath = c.getString(4),
                    isVideo = c.getInt(5) == 1,
                    size = c.getLong(6),
                    dateTaken = c.getLong(7),
                    dateAdded = c.getLong(8),
                    trashedAt = c.getLong(9),
                    hash = c.getString(10),
                    file = c.getString(11),
                    pending = c.getInt(12) == 1,
                )
            }
        }
        return out
    }

    companion object {
        private const val VERIFY_HASH_LIMIT = 10L * 1024 * 1024
    }
}
