package com.gallerysearch.app.ai

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TokenCounterTest {
    @Test
    fun approxFourCharsPerToken() {
        assertEquals(1, TokenCounter.count("a"))
        assertEquals(1, TokenCounter.count("abcd"))
        assertEquals(2, TokenCounter.count("abcdefgh"))
        assertEquals(3, TokenCounter.count("a".repeat(11)))
    }

    @Test
    fun emptyCountsAsOne() {
        assertEquals(1, TokenCounter.count(""))
    }

    @Test
    fun fits() {
        assertTrue(TokenCounter.fits("abcd", 1))
        assertFalse(TokenCounter.fits("abcdefgh", 1))
    }
}
