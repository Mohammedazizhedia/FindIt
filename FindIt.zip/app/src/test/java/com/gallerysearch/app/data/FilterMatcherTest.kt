package com.gallerysearch.app.data

import android.net.Uri
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class FilterMatcherTest {
    private fun item(
        name: String,
        size: Long = 1_000,
        dateAdded: Long = 1_000,
        ext: String = "jpg",
        folder: String = "Camera",
        category: Category = Category.IMAGE,
    ) = MediaItem(
        id = 1, uri = Uri.EMPTY, isVideo = category == Category.VIDEO,
        name = name, size = size, dateAdded = dateAdded,
        category = category, extension = ext, folder = folder,
    )

    @Test
    fun emptyFiltersMatchEverything() {
        assertTrue(FilterMatcher.matches(item("IMG_0001.jpg"), SearchFilters.DEFAULT))
    }

    @Test
    fun queryMatchesNameCaseInsensitively() {
        assertTrue(FilterMatcher.matches(item("IMG_0001.JPG"), SearchFilters.DEFAULT, query = "img"))
        assertFalse(FilterMatcher.matches(item("IMG_0001.JPG"), SearchFilters.DEFAULT, query = "png"))
    }

    @Test
    fun allQueryTokensMustMatch() {
        assertTrue(FilterMatcher.matches(item("beach_sunset_01.jpg"), SearchFilters.DEFAULT, query = "beach sunset"))
        assertFalse(FilterMatcher.matches(item("beach_sunset_01.jpg"), SearchFilters.DEFAULT, query = "beach car"))
    }

    @Test
    fun blankQueryIsIgnored() {
        assertTrue(FilterMatcher.matches(item("a.jpg"), SearchFilters.DEFAULT, query = "   "))
    }

    @Test
    fun extensionFilterIsCaseInsensitive() {
        val f = SearchFilters(extensions = setOf("PDF"))
        assertTrue(FilterMatcher.matches(item("report.PDF", ext = "pdf"), f))
        assertFalse(FilterMatcher.matches(item("song.mp3", ext = "mp3", category = Category.AUDIO), f))
    }

    @Test
    fun sizeBoundsAreInclusive() {
        val f = SearchFilters(minBytes = 500, maxBytes = 1_500)
        assertTrue(FilterMatcher.matches(item("a.jpg", size = 500), f))
        assertTrue(FilterMatcher.matches(item("a.jpg", size = 1_500), f))
        assertFalse(FilterMatcher.matches(item("a.jpg", size = 499), f))
        assertFalse(FilterMatcher.matches(item("a.jpg", size = 1_501), f))
    }

    @Test
    fun dateBoundsAreInclusive() {
        val f = SearchFilters(dateFromSec = 100, dateToSec = 200)
        assertTrue(FilterMatcher.matches(item("a.jpg", dateAdded = 100), f))
        assertTrue(FilterMatcher.matches(item("a.jpg", dateAdded = 200), f))
        assertFalse(FilterMatcher.matches(item("a.jpg", dateAdded = 99), f))
        assertFalse(FilterMatcher.matches(item("a.jpg", dateAdded = 201), f))
    }

    @Test
    fun folderFilter() {
        val f = SearchFilters(folders = setOf("Camera"))
        assertTrue(FilterMatcher.matches(item("a.jpg", folder = "Camera"), f))
        assertFalse(FilterMatcher.matches(item("a.jpg", folder = "Screenshots"), f))
    }

    @Test
    fun applyPreservesOrder() {
        val items = listOf(item("b.jpg"), item("a.jpg"), item("c.jpg"))
        val out = FilterMatcher.apply(items, SearchFilters.DEFAULT, query = "jpg")
        assertEquals(listOf("b.jpg", "a.jpg", "c.jpg"), out.map { it.name })
    }
}
