package com.gallerysearch.app.data

import org.junit.Assert.assertEquals
import org.junit.Test

class TrashNamesTest {
    @Test
    fun noConflictReturnsSame() {
        assertEquals("photo.jpg", TrashNames.unique("photo.jpg", emptyList()))
    }

    @Test
    fun appendsCounterBeforeExtension() {
        assertEquals("photo (1).jpg", TrashNames.unique("photo.jpg", listOf("photo.jpg")))
    }

    @Test
    fun incrementsUntilFree() {
        val taken = listOf("a.png", "a (1).png", "a (2).png")
        assertEquals("a (3).png", TrashNames.unique("a.png", taken))
    }

    @Test
    fun dotlessNameHandled() {
        assertEquals("README (1)", TrashNames.unique("README", listOf("README")))
    }

    @Test
    fun leadingDotIsNotExtension() {
        assertEquals(".hidden (1)", TrashNames.unique(".hidden", listOf(".hidden")))
    }
}
