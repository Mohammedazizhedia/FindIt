package com.gallerysearch.app.voice

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class VoiceCommandsTest {
    @Test
    fun englishSearchPrefix() {
        val c = VoiceCommands.parse("search for my car photos")
        assertTrue(c is VoiceCommand.Search)
        assertEquals("my car photos", (c as VoiceCommand.Search).query)
    }

    @Test
    fun arabicSearchPrefix() {
        val c = VoiceCommands.parse("ابحث عن عربيتي")
        assertTrue(c is VoiceCommand.Search)
        assertEquals("عربيتي", (c as VoiceCommand.Search).query)
    }

    @Test
    fun egyptianSearchPrefix() {
        assertEquals("العربية", (VoiceCommands.parse("دور على العربية") as VoiceCommand.Search).query)
    }

    @Test
    fun commands() {
        assertEquals(VoiceCommand.OpenDuplicates, VoiceCommands.parse("show duplicates"))
        assertEquals(VoiceCommand.OpenCorrupt, VoiceCommands.parse("الملفات التالفة"))
        assertEquals(VoiceCommand.OpenSettings, VoiceCommands.parse("افتح الإعدادات"))
        assertEquals(VoiceCommand.SetTheme(true), VoiceCommands.parse("الوضع الداكن"))
        assertEquals(VoiceCommand.SetTheme(false), VoiceCommands.parse("light mode"))
        assertEquals(VoiceCommand.StartScan, VoiceCommands.parse("نظف الموبايل"))
        assertEquals(VoiceCommand.Stop, VoiceCommands.parse("إلغاء"))
    }

    @Test
    fun plainTextBecomesSearch() {
        assertEquals("beautiful sunset", (VoiceCommands.parse("beautiful sunset") as VoiceCommand.Search).query)
    }
}
