package com.gallerysearch.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DatePresetsTest {
    @Test
    fun allCoversEverything() {
        val (from, to) = DatePresets.range(DatePresets.ALL, nowSec = 1_000_000L)
        assertEquals(0L, from)
        assertEquals(Long.MAX_VALUE, to)
    }

    @Test
    fun presetsAreOrderedOldestFirst() {
        val now = 2_000_000_000L
        val today = DatePresets.range(DatePresets.TODAY, now).first
        val week = DatePresets.range(DatePresets.WEEK, now).first
        val month = DatePresets.range(DatePresets.MONTH, now).first
        val year = DatePresets.range(DatePresets.YEAR, now).first
        assertTrue(today <= now)
        assertTrue(week <= today)
        assertTrue(month <= week)
        assertTrue(year <= month)
    }

    @Test
    fun todayStartsWithinLastDay() {
        val now = 2_000_000_000L
        val (from, to) = DatePresets.range(DatePresets.TODAY, now)
        assertTrue(from in (now - 86400)..now)
        assertEquals(Long.MAX_VALUE, to)
    }

    @Test
    fun weekIsSevenDays() {
        val now = 2_000_000_000L
        val (from, _) = DatePresets.range(DatePresets.WEEK, now)
        assertEquals(now - 7L * 24 * 60 * 60, from)
    }
}
