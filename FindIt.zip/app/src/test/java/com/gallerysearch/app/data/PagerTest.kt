package com.gallerysearch.app.data

import org.junit.Assert.assertEquals
import org.junit.Test

class PagerTest {
    @Test
    fun pageCountMath() {
        assertEquals(0, Pager.pageCount(0, 120))
        assertEquals(0, Pager.pageCount(10, 0))
        assertEquals(1, Pager.pageCount(1, 120))
        assertEquals(1, Pager.pageCount(120, 120))
        assertEquals(2, Pager.pageCount(121, 120))
        assertEquals(2, Pager.pageCount(240, 120))
        assertEquals(3, Pager.pageCount(241, 120))
    }

    @Test
    fun pageSlicesWithinBounds() {
        val list = (1..250).toList()
        assertEquals((1..120).toList(), Pager.page(list, 0, 120))
        assertEquals((121..240).toList(), Pager.page(list, 1, 120))
        assertEquals((241..250).toList(), Pager.page(list, 2, 120))
    }

    @Test
    fun pageOutOfRangeReturnsEmpty() {
        val list = (1..10).toList()
        assertEquals(emptyList<Int>(), Pager.page(list, 1, 120))
        assertEquals(emptyList<Int>(), Pager.page(list, -1, 120))
        assertEquals(emptyList<Int>(), Pager.page(list, 0, 0))
    }
}
