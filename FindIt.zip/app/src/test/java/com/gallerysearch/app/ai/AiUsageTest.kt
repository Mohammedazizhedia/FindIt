package com.gallerysearch.app.ai

import android.content.Context
import org.junit.Assert.assertEquals
import org.junit.Test

class AiUsageTest {
    private val free = object : AiProvider {
        override val id = "x"; override val label = "X"
        override val freeTier = true; override val freeDailyLimit = 100
        override val models = listOf("m")
        override fun hasKey(ctx: Context) = true
        override suspend fun chat(ctx: Context, model: String, messages: List<ChatMessage>) = ""
    }

    @Test
    fun remainingMath() {
        assertEquals(100, UsageStore.remaining(free, 0))
        assertEquals(40, UsageStore.remaining(free, 60))
        assertEquals(0, UsageStore.remaining(free, 150))
    }
}
