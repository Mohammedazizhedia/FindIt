package com.gallerysearch.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ProgressEngineTest {
    @Test
    fun percentNeverExceedsBounds() {
        assertEquals(0, ProgressEngine.percent(0, 0))
        assertEquals(0, ProgressEngine.percent(0, 100))
        assertEquals(0, ProgressEngine.percent(-5, 100))
        assertEquals(50, ProgressEngine.percent(1, 2))
        assertEquals(99, ProgressEngine.percent(2, 3).let { if (it > 100) 101 else it })
        assertEquals(100, ProgressEngine.percent(100, 100))
        assertEquals(100, ProgressEngine.percent(150, 100))
        // Long math must not overflow on huge inputs.
        assertEquals(100, ProgressEngine.percent(Int.MAX_VALUE, 1))
    }

    @Test
    fun percentIsMonotonicAndClamped() {
        var prev = -1
        for (p in 0..130 step 7) {
            val v = ProgressEngine.percent(p, 100)
            assert(v in 0..100) { "percent out of bounds: $v" }
            assert(v >= prev) { "percent went backwards" }
            prev = v
        }
    }

    @Test
    fun etaMath() {
        assertNull(ProgressEngine.etaSeconds(0, 100, 10))
        assertNull(ProgressEngine.etaSeconds(100, 100, 50))
        assertNull(ProgressEngine.etaSeconds(0, 0, 50))
        assertEquals(10L, ProgressEngine.etaSeconds(50, 100, 10))
        assertEquals(0L, ProgressEngine.etaSeconds(1, 2, 0))
        assertEquals(90L, ProgressEngine.etaSeconds(10, 100, 10))
    }

    @Test
    fun elapsedIsFlooredAtZero() {
        assertEquals(0L, ProgressEngine.elapsedSeconds(500, 400))
        assertEquals(0L, ProgressEngine.elapsedSeconds(400, 400))
        assertEquals(5L, ProgressEngine.elapsedSeconds(0, 5000))
    }
}
