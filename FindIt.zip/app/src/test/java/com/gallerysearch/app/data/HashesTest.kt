package com.gallerysearch.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class HashesTest {
    @Test
    fun hammingDistance() {
        assertEquals(0, Hashes.hamming(0L, 0L))
        assertEquals(1, Hashes.hamming(1L, 0L))
        assertEquals(64, Hashes.hamming(-1L, 0L))
        assertEquals(2, Hashes.hamming(0b101L, 0b010L))
    }

    @Test
    fun aHashRejectsWrongSize() {
        assertNull(Hashes.aHash(IntArray(63)))
    }

    @Test
    fun aHashUniformImageIsAllOnes() {
        val gray = IntArray(64) { 128 }
        assertEquals(-1L, Hashes.aHash(gray)) // all bits >= avg
    }

    @Test
    fun aHashSplitHalfHalf() {
        val gray = IntArray(64) { if (it < 32) 0 else 255 }
        val h = Hashes.aHash(gray)!!
        assertEquals(32, Hashes.hamming(h, 0L)) // exactly half the bits set
    }
}
