package com.gallerysearch.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class MagicBytesTest {
    private fun bytes(vararg v: Int) = v.map { it.toByte() }.toByteArray()

    @Test
    fun jpgMatches() {
        assertTrue(MagicBytes.matches(bytes(0xFF, 0xD8, 0xFF, 0xE0, 0x00), "jpg")!!)
        assertTrue(MagicBytes.matches(bytes(0xFF, 0xD8, 0xFF), "JPEG")!!) // case-insensitive ext
    }

    @Test
    fun wrongSignatureFails() {
        assertFalse(MagicBytes.matches(bytes(0x89, 0x50, 0x4E, 0x47), "jpg")!!)
    }

    @Test
    fun shortHeadFails() {
        assertFalse(MagicBytes.matches(bytes(0xFF, 0xD8), "jpg")!!)
    }

    @Test
    fun unknownExtensionReturnsNull() {
        assertNull(MagicBytes.matches(bytes(0x01, 0x02), "xyz"))
    }

    @Test
    fun mp3FrameSyncAcceptedWithoutId3() {
        // 0xFF 0xFB = MPEG frame sync
        assertTrue(MagicBytes.matches(bytes(0xFF, 0xFB, 0x90, 0x00), "mp3")!!)
        // "ID3" also accepted
        assertTrue(MagicBytes.matches(bytes(0x49, 0x44, 0x33, 0x00), "mp3")!!)
    }

    @Test
    fun pdfAndZip() {
        assertTrue(MagicBytes.matches("%PDF-1.7".map { it.code.toByte() }.toByteArray(), "pdf")!!)
        assertTrue(MagicBytes.matches(bytes(0x50, 0x4B, 0x03, 0x04, 0x14), "zip")!!)
        assertEquals(true, MagicBytes.isKnown("docx"))
        assertEquals(false, MagicBytes.isKnown("xyz"))
    }
}
