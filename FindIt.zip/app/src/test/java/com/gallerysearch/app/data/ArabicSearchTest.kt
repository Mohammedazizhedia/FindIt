package com.gallerysearch.app.data

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ArabicSearchTest {
    @Test
    fun arabicCarMapsToEnglishCar() {
        assertTrue("car" in ArEnLexicon.expand("سيارة"))
        assertTrue("car" in ArEnLexicon.expand("السيارات"))
        assertTrue("car" in ArEnLexicon.expand("عربية"))
    }

    @Test
    fun englishPluralFindsSingularLabel() {
        assertTrue("car" in ArEnLexicon.expand("cars"))
    }

    @Test
    fun arabicQueryMatchesEnglishLabels() {
        VisualIndex.addLabels("content://img/1", listOf("car", "wheel"))
        VisualIndex.addLabels("content://img/2", listOf("sports car"))
        VisualIndex.addLabels("content://img/3", listOf("cat"))
        val hits = VisualIndex.searchGroups(listOf(ArEnLexicon.expand("سيارة")))
        assertTrue("content://img/1" in hits)
        assertTrue("content://img/2" in hits)
        assertFalse("content://img/3" in hits)
    }

    @Test
    fun everyTypedWordMustMatch() {
        VisualIndex.addLabels("content://img/4", listOf("car", "night"))
        VisualIndex.addLabels("content://img/5", listOf("car", "beach"))
        val hits = VisualIndex.searchGroups(
            listOf(ArEnLexicon.expand("سيارة"), ArEnLexicon.expand("ليل")),
        )
        assertTrue("content://img/4" in hits)
        assertFalse("content://img/5" in hits)
    }
}
